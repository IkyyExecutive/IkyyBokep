/**
 * Dashboard JavaScript
 * Handles sidebar toggle, mobile responsiveness, and navigation
 */

const Dashboard = {
    // Initialize dashboard functionality
    init: function() {
        this.setupSidebarToggle();
        this.setupMobileMenu();
        this.setupResponsiveDesign();
        this.handleActiveNavigation();
    },

    // Setup sidebar toggle functionality
    setupSidebarToggle: function() {
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        
        if (sidebarToggle && sidebar) {
            sidebarToggle.addEventListener('click', () => {
                this.toggleSidebar();
            });
        }

        if (overlay) {
            overlay.addEventListener('click', () => {
                this.closeSidebar();
            });
        }

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (window.innerWidth < 1024) { // lg breakpoint
                if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                    this.closeSidebar();
                }
            }
        });
    },

    // Setup mobile menu functionality
    setupMobileMenu: function() {
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileMenu = document.getElementById('mobileMenu');
        
        if (mobileMenuToggle && mobileMenu) {
            mobileMenuToggle.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
            });
        }
    },

    // Setup responsive design handlers
    setupResponsiveDesign: function() {
        window.addEventListener('resize', () => {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            if (window.innerWidth >= 1024) { // lg breakpoint
                // Desktop: show sidebar, hide overlay
                if (sidebar) {
                    sidebar.classList.remove('-translate-x-full');
                }
                if (overlay) {
                    overlay.classList.add('hidden');
                }
            } else {
                // Mobile: hide sidebar by default
                if (sidebar && !sidebar.classList.contains('sidebar-open')) {
                    sidebar.classList.add('-translate-x-full');
                }
            }
        });
    },

    // Handle active navigation highlighting
    handleActiveNavigation: function() {
        const currentPath = window.location.pathname;
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === currentPath || (currentPath === '/app/' && href === '/')) {
                link.classList.add('bg-blue-700', 'text-white');
                link.classList.remove('text-blue-100', 'hover:bg-blue-700');
            }
        });
    },

    // Toggle sidebar open/close
    toggleSidebar: function() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        
        if (sidebar.classList.contains('-translate-x-full')) {
            this.openSidebar();
        } else {
            this.closeSidebar();
        }
    },

    // Open sidebar
    openSidebar: function() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        
        if (sidebar) {
            sidebar.classList.remove('-translate-x-full');
            sidebar.classList.add('sidebar-open');
        }
        
        if (overlay && window.innerWidth < 1024) {
            overlay.classList.remove('hidden');
        }
    },

    // Close sidebar
    closeSidebar: function() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        
        if (window.innerWidth < 1024) {
            if (sidebar) {
                sidebar.classList.add('-translate-x-full');
                sidebar.classList.remove('sidebar-open');
            }
        }
        
        if (overlay) {
            overlay.classList.add('hidden');
        }
    },

    // Show notification
    showNotification: function(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm transition-all duration-300 transform translate-x-full`;
        
        const colors = {
            'success': 'bg-green-500 text-white',
            'error': 'bg-red-500 text-white',
            'warning': 'bg-yellow-500 text-white',
            'info': 'bg-blue-500 text-white'
        };
        
        notification.className += ` ${colors[type] || colors.info}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.classList.remove('translate-x-full');
        }, 100);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.classList.add('translate-x-full');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
};

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    Dashboard.init();
});
