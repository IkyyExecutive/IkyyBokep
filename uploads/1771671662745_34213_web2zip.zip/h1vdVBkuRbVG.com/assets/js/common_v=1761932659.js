/**
 * Common JavaScript functions for the application
 * Shared utilities, dialog management, form validation, etc.
 * Updated: 2024-09-19 21:41 - Fixed username input to allow numbers
 */

// Dialog Management
const DialogManager = {
    showError: function(message) {
        const msgEl = document.getElementById('errorDialogMessage');
        const dlgEl = document.getElementById('errorDialog');
        if (msgEl) {
            msgEl.textContent = message;
            msgEl.style.color = '#000';
            msgEl.style.webkitTextFillColor = '#000';
        }
        if (dlgEl) {
            dlgEl.style.color = '#000';
            dlgEl.classList.remove('hidden');
        }
    },

    showSuccess: function(message, redirectUrl = null) {
        const msgEl = document.getElementById('successDialogMessage');
        const dlgEl = document.getElementById('successDialog');
        if (msgEl) {
            msgEl.textContent = message;
            msgEl.style.color = '#000';
            msgEl.style.webkitTextFillColor = '#000';
        }
        if (dlgEl) {
            dlgEl.style.color = '#000';
            dlgEl.classList.remove('hidden');
        }
        
        // Store redirect URL for later use
        if (redirectUrl) {
            document.getElementById('successDialog').setAttribute('data-redirect', redirectUrl);
        }
    },

    showWarning: function(message) {
        // Use error dialog with warning style (since we don't have a separate warning dialog)
        console.warn('⚠️ WARNING:', message);
        document.getElementById('errorDialogMessage').textContent = message;
        document.getElementById('errorDialog').classList.remove('hidden');
    },

    closeError: function() {
        document.getElementById('errorDialog').classList.add('hidden');
    },

    closeSuccess: function() {
        const successDialog = document.getElementById('successDialog');
        successDialog.classList.add('hidden');
        
        // Check if there's a redirect URL
        const redirectUrl = successDialog.getAttribute('data-redirect');
        if (redirectUrl) {
            successDialog.removeAttribute('data-redirect');
            window.location.href = redirectUrl;
        }
    },

    init: function() {
        // Close dialog when clicking outside
        const errorDialog = document.getElementById('errorDialog');
        const successDialog = document.getElementById('successDialog');
        
        if (errorDialog) {
            errorDialog.addEventListener('click', function(e) {
                if (e.target === this) {
                    DialogManager.closeError();
                }
            });
        }
        
        if (successDialog) {
            successDialog.addEventListener('click', function(e) {
                if (e.target === this) {
                    DialogManager.closeSuccess();
                }
            });
        }
    }
};

// Form Utilities
const FormUtils = {
    // Username validation and formatting
    formatUsername: function(input) {
        input.addEventListener('input', function(e) {
            let value = e.target.value.toLowerCase().replace(/[^a-z0-9]/g, '');
            if (value.length > 20) {
                value = value.substring(0, 20);
            }
            e.target.value = value;
        });
    },

    // Phone number validation and formatting (for future use)
    formatPhone: function(input) {
        input.addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^0-9]/g, '');
            if (value.length > 0 && !value.startsWith('0')) {
                value = '0' + value;
            }
            if (value.length > 13) {
                value = value.substring(0, 13);
            }
            e.target.value = value;
        });
    },

    // Validate username
    validateUsername: function(username) {
        if (!/^[a-z0-9]+$/.test(username)) {
            return 'Username hanya boleh menggunakan huruf kecil (a-z) dan angka, tanpa karakter khusus';
        }
        
        if (username.length < 3 || username.length > 20) {
            return 'Username harus antara 3-20 karakter';
        }
        
        return null; // No error
    },

    // Validate password match
    validatePasswordMatch: function(password, confirmPassword) {
        if (password !== confirmPassword) {
            return 'Kata sandi dan konfirmasi tidak cocok';
        }
        return null; // No error
    },

    // Set loading state for form button
    setButtonLoading: function(button, isLoading, loadingText = 'Memproses...', originalText = null) {
        if (isLoading) {
            button.disabled = true;
            if (!button.getAttribute('data-original-text')) {
                button.setAttribute('data-original-text', button.textContent);
            }
            button.textContent = loadingText;
            button.classList.add('opacity-75', 'cursor-not-allowed');
        } else {
            button.disabled = false;
            button.textContent = originalText || button.getAttribute('data-original-text') || button.textContent;
            button.classList.remove('opacity-75', 'cursor-not-allowed');
            button.removeAttribute('data-original-text');
        }
    }
};

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('Common.js loaded successfully - username input should allow numbers!');
    DialogManager.init();
});

// Legacy function names for backward compatibility (will be removed later)
function showErrorDialog(message) {
    DialogManager.showError(message);
}

function showSuccessDialog(message) {
    DialogManager.showSuccess(message, '/login');
}

function closeErrorDialog() {
    DialogManager.closeError();
}

function closeSuccessDialog() {
    DialogManager.closeSuccess();
}
