// Deteksi mode gelap
if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
  document.documentElement.classList.add('dark');
}
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', event => {
  if (event.matches) {
    document.documentElement.classList.add('dark');
  } else {
    document.documentElement.classList.remove('dark');
  }
});

// State
const state = {
  items: [],
  selectedId: null,
  gridColumns: 4,
  gridRows: 4,
  gridGap: 12,
  canvasWidth: 600,
  canvasHeight: 400,
  showGrid: true,
  snapToGrid: true,
  itemCounter: 0,
  responsiveCSS: true
};

// Undo/Redo History
const history = [];
let historyIndex = -1;
const MAX_HISTORY = 50;

function getSnapshot() {
  return {
    items: JSON.parse(JSON.stringify(state.items)),
    gridColumns: state.gridColumns,
    gridRows: state.gridRows,
    gridGap: state.gridGap,
    canvasWidth: state.canvasWidth,
    canvasHeight: state.canvasHeight,
    itemCounter: state.itemCounter
  };
}

function saveSnapshot() {
  // Truncate any future states
  history.length = historyIndex + 1;
  history.push(getSnapshot());
  if (history.length > MAX_HISTORY) {
    history.shift();
  } else {
    historyIndex++;
  }
  updateUndoRedoButtons();
}

function undo() {
  if (historyIndex <= 0) return;
  historyIndex--;
  restoreSnapshot(history[historyIndex]);
}

function redo() {
  if (historyIndex >= history.length - 1) return;
  historyIndex++;
  restoreSnapshot(history[historyIndex]);
}

function restoreSnapshot(snapshot) {
  state.items = JSON.parse(JSON.stringify(snapshot.items));
  state.gridColumns = snapshot.gridColumns;
  state.gridRows = snapshot.gridRows;
  state.gridGap = snapshot.gridGap;
  state.canvasWidth = snapshot.canvasWidth;
  state.canvasHeight = snapshot.canvasHeight;
  state.itemCounter = snapshot.itemCounter;

  // Sync UI inputs
  document.getElementById('gridColumns').value = state.gridColumns;
  document.getElementById('gridRows').value = state.gridRows;
  document.getElementById('gridGap').value = state.gridGap;
  document.getElementById('canvasWidth').value = state.canvasWidth;
  document.getElementById('canvasHeight').value = state.canvasHeight;

  // Re-apply canvas size
  const gridCanvas = document.getElementById('gridCanvas');
  gridCanvas.style.width = state.canvasWidth + 'px';
  gridCanvas.style.height = state.canvasHeight + 'px';

  const cellWidth = (state.canvasWidth - (state.gridColumns - 1) * state.gridGap) / state.gridColumns;
  const cellHeight = (state.canvasHeight - (state.gridRows - 1) * state.gridGap) / state.gridRows;
  gridCanvas.style.setProperty('--cell-width', cellWidth + state.gridGap + 'px');
  gridCanvas.style.setProperty('--cell-height', cellHeight + state.gridGap + 'px');
  gridCanvas.style.gridTemplateColumns = `repeat(${state.gridColumns}, 1fr)`;
  gridCanvas.style.gridTemplateRows = `repeat(${state.gridRows}, 1fr)`;
  gridCanvas.style.gap = state.gridGap + 'px';
  gridCanvas.style.padding = state.gridGap + 'px';

  // Check if selected item still exists
  if (state.selectedId && !state.items.find(i => i.id === state.selectedId)) {
    state.selectedId = null;
  }

  renderItems();
  updatePropertiesPanel();
  generateCode();
  updateUndoRedoButtons();
}

function updateUndoRedoButtons() {
  const undoBtn = document.getElementById('undoBtn');
  const redoBtn = document.getElementById('redoBtn');
  if (undoBtn) undoBtn.disabled = historyIndex <= 0;
  if (redoBtn) redoBtn.disabled = historyIndex >= history.length - 1;
}

// Elemen DOM
const gridCanvas = document.getElementById('gridCanvas');
const dropHighlight = document.getElementById('dropHighlight');
const htmlCodeEl = document.querySelector('#htmlCode code');
const cssCodeEl = document.querySelector('#cssCode code');
const previewFrame = document.getElementById('previewFrame');

// Inisialisasi
function init() {
  updateCanvasSize();
  updateGridSettings();
  bindEvents();
  generateCode();
  saveSnapshot(); // Initial state
}

// Canvas dan Grid
function updateCanvasSize() {
  const width = parseInt(document.getElementById('canvasWidth').value) || 600;
  const height = parseInt(document.getElementById('canvasHeight').value) || 400;
  state.canvasWidth = width;
  state.canvasHeight = height;
  gridCanvas.style.width = width + 'px';
  gridCanvas.style.height = height + 'px';
  updateGridSettings();
}

function updateGridSettings() {
  state.gridColumns = parseInt(document.getElementById('gridColumns').value) || 4;
  state.gridRows = parseInt(document.getElementById('gridRows').value) || 4;
  state.gridGap = parseInt(document.getElementById('gridGap').value) || 12;

  const cellWidth = (state.canvasWidth - (state.gridColumns - 1) * state.gridGap) / state.gridColumns;
  const cellHeight = (state.canvasHeight - (state.gridRows - 1) * state.gridGap) / state.gridRows;

  gridCanvas.style.setProperty('--cell-width',
    cellWidth + state.gridGap + 'px');
  gridCanvas.style.setProperty('--cell-height',
    cellHeight + state.gridGap + 'px');
  gridCanvas.style.gridTemplateColumns = `repeat(${state.gridColumns}, 1fr)`;
  gridCanvas.style.gridTemplateRows = `repeat(${state.gridRows}, 1fr)`;
  gridCanvas.style.gap = state.gridGap + 'px';
  gridCanvas.style.padding = state.gridGap + 'px';

  renderItems();
  generateCode();
}

// Items Manajemen
function addItem() {
  state.itemCounter++;
  const id = 'item-' + state.itemCounter;
  const colors = ['#6366f1', '#ec4899', '#10b981', '#f59e0b', '#3b82f6'];
  const color = colors[state.itemCounter % colors.length];

  const newItem = {
    id,
    label: 'Item ' + state.itemCounter,
    colStart: 1,
    colEnd: 2,
    rowStart: 1,
    rowEnd: 2,
    justifySelf: 'stretch',
    alignSelf: 'stretch',
    color
  };

  // Temukan sel kosong
  for (let r = 1; r <= state.gridRows; r++) {
    for (let c = 1; c <= state.gridColumns; c++) {
      if (!isOccupied(c, r, c + 1, r + 1)) {
        newItem.colStart = c;
        newItem.colEnd = c + 1;
        newItem.rowStart = r;
        newItem.rowEnd = r + 1;
        break;
      }
    }
    if (newItem.colStart > 1 || newItem.rowStart > 1) break;
  }

  state.items.push(newItem);
  renderItems();
  selectItem(id);
  generateCode();
  saveSnapshot();
}

function isOccupied(colStart, rowStart, colEnd, rowEnd, excludeId = null) {
  return state.items.some(item => {
    if (item.id === excludeId) return false;
    return !(colEnd <= item.colStart || colStart >= item.colEnd ||
      rowEnd <= item.rowStart || rowStart >= item.rowEnd);
  });
}

function deleteItem(id) {
  state.items = state.items.filter(item => item.id !== id);
  if (state.selectedId === id) {
    state.selectedId = null;
    updatePropertiesPanel();
  }
  renderItems();
  generateCode();
  saveSnapshot();
}

function clearAllItems() {
  state.items = [];
  state.selectedId = null;
  state.itemCounter = 0;
  updatePropertiesPanel();
  renderItems();
  generateCode();
  saveSnapshot();
}

function selectItem(id) {
  state.selectedId = id;
  document.querySelectorAll('.grid-item').forEach(el => {
    el.classList.toggle('selected', el.dataset.id === id);
  });
  updatePropertiesPanel();
}

function getSelectedItem() {
  return state.items.find(item => item.id === state.selectedId);
}

// Render Items
function renderItems() {
  // Hapus item lama
  gridCanvas.querySelectorAll('.grid-item').forEach(el => el.remove());

  state.items.forEach(item => {
    const el = document.createElement('div');
    el.className = 'grid-item' + (item.id === state.selectedId ? ' selected': '');
    el.dataset.id = item.id;
    el.style.gridColumn = `${item.colStart} / ${item.colEnd}`;
    el.style.gridRow = `${item.rowStart} / ${item.rowEnd}`;
    el.style.justifySelf = item.justifySelf;
    el.style.alignSelf = item.alignSelf;
    el.style.borderColor = item.color;
    el.style.color = item.color;
    el.style.background = `linear-gradient(135deg, ${item.color}15, transparent)`;

    el.innerHTML = `
    <i class="fas fa-grip-vertical" style="opacity:0.5;"></i>
    <span class="item-label">${item.label}</span>
    <button class="item-delete"><i class="fas fa-times"></i></button>
    <div class="resize-handle corner nw"></div>
    <div class="resize-handle corner ne"></div>
    <div class="resize-handle corner sw"></div>
    <div class="resize-handle corner se"></div>
    <div class="resize-handle edge n"></div>
    <div class="resize-handle edge s"></div>
    <div class="resize-handle edge w"></div>
    <div class="resize-handle edge e"></div>
    `;

    // Hapus handler
    el.querySelector('.item-delete').addEventListener('click', (e) => {
      e.stopPropagation();
      deleteItem(item.id);
    });

    // Pilih handler
    el.addEventListener('mousedown', (e) => {
      if (e.target.classList.contains('item-delete') || e.target.closest('.item-delete')) return;
      selectItem(item.id);

      // Mulai seret atau ubah ukuran
      const handle = e.target.closest('.resize-handle');
      if (handle) {
        startResize(e, item, handle);
      } else {
        startDrag(e, item);
      }
    });

    gridCanvas.appendChild(el);
  });
}

// Drag dan Drop
let dragState = null;

function startDrag(e, item) {
  e.preventDefault();
  const el = document.querySelector(`[data-id="${item.id}"]`);
  el.classList.add('dragging');

  const rect = gridCanvas.getBoundingClientRect();
  const itemRect = el.getBoundingClientRect();

  dragState = {
    type: 'drag',
    item,
    startX: e.clientX,
    startY: e.clientY,
    offsetX: e.clientX - itemRect.left,
    offsetY: e.clientY - itemRect.top,
    canvasRect: rect
  };

  document.addEventListener('mousemove', onDrag);
  document.addEventListener('mouseup', endDrag);
}

function onDrag(e) {
  if (!dragState || dragState.type !== 'drag') return;

  const {
    item,
    canvasRect
  } = dragState;
  const gap = state.gridGap;
  const cellWidth = (state.canvasWidth - (state.gridColumns + 1) * gap) / state.gridColumns;
  const cellHeight = (state.canvasHeight - (state.gridRows + 1) * gap) / state.gridRows;

  const x = e.clientX - canvasRect.left - gap;
  const y = e.clientY - canvasRect.top - gap;

  const colSpan = item.colEnd - item.colStart;
  const rowSpan = item.rowEnd - item.rowStart;

  let col = Math.round(x / (cellWidth + gap)) + 1;
  let row = Math.round(y / (cellHeight + gap)) + 1;

  col = Math.max(1, Math.min(col, state.gridColumns - colSpan + 1));
  row = Math.max(1, Math.min(row, state.gridRows - rowSpan + 1));

  if (state.snapToGrid) {
    const hlX = gap + (col - 1) * (cellWidth + gap);
    const hlY = gap + (row - 1) * (cellHeight + gap);
    const hlW = colSpan * cellWidth + (colSpan - 1) * gap;
    const hlH = rowSpan * cellHeight + (rowSpan - 1) * gap;

    dropHighlight.style.display = 'block';
    dropHighlight.style.left = hlX + 'px';
    dropHighlight.style.top = hlY + 'px';
    dropHighlight.style.width = hlW + 'px';
    dropHighlight.style.height = hlH + 'px';
  }

  // Posisi pratinjau
  gridCanvas.classList.add('show-strong-grid');
}

function endDrag(e) {
  if (!dragState || dragState.type !== 'drag') return;

  const {
    item,
    canvasRect
  } = dragState;
  const el = document.querySelector(`[data-id="${item.id}"]`);
  el.classList.remove('dragging');
  dropHighlight.style.display = 'none';
  gridCanvas.classList.remove('show-strong-grid');

  if (state.snapToGrid) {
    const gap = state.gridGap;
    const cellWidth = (state.canvasWidth - (state.gridColumns + 1) * gap) / state.gridColumns;
    const cellHeight = (state.canvasHeight - (state.gridRows + 1) * gap) / state.gridRows;

    const x = e.clientX - canvasRect.left - gap;
    const y = e.clientY - canvasRect.top - gap;

    const colSpan = item.colEnd - item.colStart;
    const rowSpan = item.rowEnd - item.rowStart;

    let col = Math.round(x / (cellWidth + gap)) + 1;
    let row = Math.round(y / (cellHeight + gap)) + 1;

    col = Math.max(1, Math.min(col, state.gridColumns - colSpan + 1));
    row = Math.max(1, Math.min(row, state.gridRows - rowSpan + 1));

    // Update item
    item.colStart = col;
    item.colEnd = col + colSpan;
    item.rowStart = row;
    item.rowEnd = row + rowSpan;

    renderItems();
    updatePropertiesPanel();
    generateCode();
    saveSnapshot();
  }

  dragState = null;
  document.removeEventListener('mousemove', onDrag);
  document.removeEventListener('mouseup', endDrag);
}

// Resize
function startResize(e, item, handle) {
  e.preventDefault();
  e.stopPropagation();

  const rect = gridCanvas.getBoundingClientRect();
  const direction = [...handle.classList].find(c => ['nw', 'ne', 'sw', 'se', 'n', 's', 'w', 'e'].includes(c));

  dragState = {
    type: 'resize',
    item,
    direction,
    startX: e.clientX,
    startY: e.clientY,
    canvasRect: rect,
    originalColStart: item.colStart,
    originalColEnd: item.colEnd,
    originalRowStart: item.rowStart,
    originalRowEnd: item.rowEnd
  };

  document.addEventListener('mousemove', onResize);
  document.addEventListener('mouseup', endResize);
}

function onResize(e) {
  if (!dragState || dragState.type !== 'resize') return;

  const {
    item,
    direction,
    canvasRect,
    originalColStart,
    originalColEnd,
    originalRowStart,
    originalRowEnd
  } = dragState;
  const gap = state.gridGap;
  const cellWidth = (state.canvasWidth - (state.gridColumns + 1) * gap) / state.gridColumns;
  const cellHeight = (state.canvasHeight - (state.gridRows + 1) * gap) / state.gridRows;

  const x = e.clientX - canvasRect.left - gap;
  const y = e.clientY - canvasRect.top - gap;

  let newCol = Math.round(x / (cellWidth + gap)) + 1;
  let newRow = Math.round(y / (cellHeight + gap)) + 1;

  newCol = Math.max(1, Math.min(newCol, state.gridColumns + 1));
  newRow = Math.max(1, Math.min(newRow, state.gridRows + 1));

  // Sesuaikan berdasarkan arah
  if (direction.includes('w')) {
    item.colStart = Math.min(newCol, originalColEnd - 1);
  }
  if (direction.includes('e')) {
    item.colEnd = Math.max(newCol + 1, originalColStart + 1);
  }
  if (direction.includes('n')) {
    item.rowStart = Math.min(newRow, originalRowEnd - 1);
  }
  if (direction.includes('s')) {
    item.rowEnd = Math.max(newRow + 1, originalRowStart + 1);
  }

  item.colStart = Math.max(1, item.colStart);
  item.colEnd = Math.min(state.gridColumns + 1, item.colEnd);
  item.rowStart = Math.max(1, item.rowStart);
  item.rowEnd = Math.min(state.gridRows + 1, item.rowEnd);

  renderItems();
  gridCanvas.classList.add('show-strong-grid');
}

function endResize() {
  if (!dragState || dragState.type !== 'resize') return;

  gridCanvas.classList.remove('show-strong-grid');
  updatePropertiesPanel();
  generateCode();
  saveSnapshot();

  dragState = null;
  document.removeEventListener('mousemove', onResize);
  document.removeEventListener('mouseup', endResize);
}

// Panel Properti
function updatePropertiesPanel() {
  const item = getSelectedItem();
  const emptyEl = document.getElementById('emptyProperties');
  const propsEl = document.getElementById('itemProperties');

  if (!item) {
    emptyEl.style.display = 'block';
    propsEl.style.display = 'none';
    return;
  }

  emptyEl.style.display = 'none';
  propsEl.style.display = 'block';

  document.getElementById('propColStart').value = item.colStart;
  document.getElementById('propColEnd').value = item.colEnd;
  document.getElementById('propRowStart').value = item.rowStart;
  document.getElementById('propRowEnd').value = item.rowEnd;
  document.getElementById('propJustify').value = item.justifySelf;
  document.getElementById('propAlign').value = item.alignSelf;
  document.getElementById('propLabel').value = item.label;

  // Update color palette
  document.querySelectorAll('.color-swatch').forEach(swatch => {
    swatch.classList.toggle('active', swatch.dataset.color === item.color);
  });
}

// Responsive breakpoint helpers
function getResponsiveBreakpoints() {
  const cols = state.gridColumns;
  return [
    {
      maxWidth: 1024,
      label: 'Tablet',
      columns: Math.max(2, Math.floor(cols / 2)),
      resetItems: false
    },
    {
      maxWidth: 768,
      label: 'Mobile Landscape',
      columns: Math.min(2, cols),
      resetItems: false
    },
    {
      maxWidth: 480,
      label: 'Mobile',
      columns: 1,
      resetItems: true
    }
  ];
}

// Generate code
function generateCode() {
  // HTML
  let html = `<span class="comment">&lt;!-- Grid Container --&gt;</span>\n`;
  html += `<span class="tag">&lt;div</span> <span class="attr">class</span>=<span class="string">"grid-container"</span><span class="tag">&gt;</span>\n`;

  state.items.forEach(item => {
    const className = item.label.toLowerCase().replace(/\s+/g, '-');
    html += `  <span class="tag">&lt;div</span> <span class="attr">class</span>=<span class="string">"grid-item ${className}"</span><span class="tag">&gt;</span>${item.label}<span class="tag">&lt;/div&gt;</span>\n`;
  });

  html += `<span class="tag">&lt;/div&gt;</span>`;
  htmlCodeEl.innerHTML = html;

  // CSS
  let css = `<span class="comment">/* Grid Container */</span>\n`;
  css += `<span class="selector">.grid-container</span> {\n`;
  css += `  <span class="property">display</span>: <span class="value">grid</span>;\n`;
  css += `  <span class="property">grid-template-columns</span>: <span class="value">repeat(${state.gridColumns}, 1fr)</span>;\n`;
  css += `  <span class="property">grid-template-rows</span>: <span class="value">repeat(${state.gridRows}, 1fr)</span>;\n`;
  css += `  <span class="property">gap</span>: <span class="value">${state.gridGap}px</span>;\n`;
  css += `  <span class="property">width</span>: <span class="value">${state.canvasWidth}px</span>;\n`;
  css += `  <span class="property">max-width</span>: <span class="value">100%</span>;\n`;
  css += `  <span class="property">height</span>: <span class="value">${state.canvasHeight}px</span>;\n`;
  css += `}\n\n`;

  css += `<span class="comment">/* Grid Items */</span>\n`;
  state.items.forEach(item => {
    const className = item.label.toLowerCase().replace(/\s+/g, '-');
    css += `<span class="selector">.${className}</span> {\n`;
    css += `  <span class="property">grid-column</span>: <span class="value">${item.colStart} / ${item.colEnd}</span>;\n`;
    css += `  <span class="property">grid-row</span>: <span class="value">${item.rowStart} / ${item.rowEnd}</span>;\n`;
    if (item.justifySelf !== 'stretch') {
      css += `  <span class="property">justify-self</span>: <span class="value">${item.justifySelf}</span>;\n`;
    }
    if (item.alignSelf !== 'stretch') {
      css += `  <span class="property">align-self</span>: <span class="value">${item.alignSelf}</span>;\n`;
    }
    css += `  <span class="property">background</span>: <span class="value">${item.color}</span>;\n`;
    css += `}\n\n`;
  });

  // Responsive media queries
  if (state.responsiveCSS && state.items.length > 0) {
    const breakpoints = getResponsiveBreakpoints();
    breakpoints.forEach(bp => {
      css += `<span class="comment">/* ${bp.label} — max-width: ${bp.maxWidth}px */</span>\n`;
      css += `<span class="media-keyword">@media</span> <span class="value">(max-width: ${bp.maxWidth}px)</span> {\n`;
      css += `  <span class="selector">.grid-container</span> {\n`;
      css += `    <span class="property">grid-template-columns</span>: <span class="value">repeat(${bp.columns}, 1fr)</span>;\n`;
      css += `    <span class="property">width</span>: <span class="value">100%</span>;\n`;
      if (bp.resetItems) {
        css += `    <span class="property">grid-template-rows</span>: <span class="value">auto</span>;\n`;
        css += `    <span class="property">height</span>: <span class="value">auto</span>;\n`;
      }
      css += `  }\n`;
      if (bp.resetItems) {
        css += `  <span class="selector">.grid-container > *</span> {\n`;
        css += `    <span class="property">grid-column</span>: <span class="value">auto</span>;\n`;
        css += `    <span class="property">grid-row</span>: <span class="value">auto</span>;\n`;
        css += `  }\n`;
      }
      css += `}\n\n`;
    });
  }

  cssCodeEl.innerHTML = css;

  // Preview
  updatePreview();
}

function updatePreview() {
  let previewCSS = `
  body { margin: 0; padding: 20px; font-family: Inter, sans-serif; background: #f8fafc; }
  .grid-container {
    display: grid;
    grid-template-columns: repeat(${state.gridColumns}, 1fr);
    grid-template-rows: repeat(${state.gridRows}, 1fr);
    gap: ${state.gridGap}px;
    width: ${state.canvasWidth}px;
    max-width: 100%;
    height: ${state.canvasHeight}px;
    margin: 0 auto;
  }
  .grid-item {
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    font-weight: 500;
    color: white;
    font-size: 14px;
    min-height: 40px;
  }
  `;

  state.items.forEach(item => {
    const className = item.label.toLowerCase().replace(/\s+/g, '-');
    previewCSS += `
    .${className} {
      grid-column: ${item.colStart} / ${item.colEnd};
      grid-row: ${item.rowStart} / ${item.rowEnd};
      ${item.justifySelf !== 'stretch' ? `justify-self: ${item.justifySelf};` : ''}
      ${item.alignSelf !== 'stretch' ? `align-self: ${item.alignSelf};` : ''}
      background: ${item.color};
    }
    `;
  });

  // Add responsive media queries to preview
  if (state.responsiveCSS && state.items.length > 0) {
    const breakpoints = getResponsiveBreakpoints();
    breakpoints.forEach(bp => {
      previewCSS += `
      @media (max-width: ${bp.maxWidth}px) {
        .grid-container {
          grid-template-columns: repeat(${bp.columns}, 1fr);
          width: 100%;
          ${bp.resetItems ? 'grid-template-rows: auto; height: auto;' : ''}
        }
        ${bp.resetItems ? '.grid-container > * { grid-column: auto; grid-row: auto; }' : ''}
      }
      `;
    });
  }

  let previewHTML = `
  <!DOCTYPE html>
  <html>
  <head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>${previewCSS}</style>
  </head>
  <body>
  <div class="grid-container">
  `;

  state.items.forEach(item => {
    const className = item.label.toLowerCase().replace(/\s+/g, '-');
    previewHTML += `<div class="grid-item ${className}">${item.label}</div>`;
  });

  previewHTML += `
  </div>
  </body>
  </html>
  `;

  previewFrame.srcdoc = previewHTML;
}

function getRawHTML() {
  let html = `<!-- Grid Container -->\n<div class="grid-container">\n`;
  state.items.forEach(item => {
    const className = item.label.toLowerCase().replace(/\s+/g, '-');
    html += `  <div class="grid-item ${className}">${item.label}</div>\n`;
  });
  html += `</div>`;
  return html;
}

function getRawCSS() {
  let css = `/* Grid Container */\n.grid-container {\n`;
  css += `  display: grid;\n`;
  css += `  grid-template-columns: repeat(${state.gridColumns}, 1fr);\n`;
  css += `  grid-template-rows: repeat(${state.gridRows}, 1fr);\n`;
  css += `  gap: ${state.gridGap}px;\n`;
  css += `  width: ${state.canvasWidth}px;\n`;
  css += `  max-width: 100%;\n`;
  css += `  height: ${state.canvasHeight}px;\n`;
  css += `}\n\n/* Grid Items */\n`;

  state.items.forEach(item => {
    const className = item.label.toLowerCase().replace(/\s+/g, '-');
    css += `.${className} {\n`;
    css += `  grid-column: ${item.colStart} / ${item.colEnd};\n`;
    css += `  grid-row: ${item.rowStart} / ${item.rowEnd};\n`;
    if (item.justifySelf !== 'stretch') css += `  justify-self: ${item.justifySelf};\n`;
    if (item.alignSelf !== 'stretch') css += `  align-self: ${item.alignSelf};\n`;
    css += `  background: ${item.color};\n`;
    css += `}\n\n`;
  });

  // Responsive media queries
  if (state.responsiveCSS && state.items.length > 0) {
    const breakpoints = getResponsiveBreakpoints();
    breakpoints.forEach(bp => {
      css += `/* ${bp.label} — max-width: ${bp.maxWidth}px */\n`;
      css += `@media (max-width: ${bp.maxWidth}px) {\n`;
      css += `  .grid-container {\n`;
      css += `    grid-template-columns: repeat(${bp.columns}, 1fr);\n`;
      css += `    width: 100%;\n`;
      if (bp.resetItems) {
        css += `    grid-template-rows: auto;\n`;
        css += `    height: auto;\n`;
      }
      css += `  }\n`;
      if (bp.resetItems) {
        css += `  .grid-container > * {\n`;
        css += `    grid-column: auto;\n`;
        css += `    grid-row: auto;\n`;
        css += `  }\n`;
      }
      css += `}\n\n`;
    });
  }

  return css;
}

// Toast
function showToast(message) {
  const toast = document.getElementById('toast');
  document.getElementById('toastMessage').textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'),
    2500);
}

// Copy dan Download
function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    showToast('Disalin ke papan klip!');
  });
}

function downloadFile(content, filename, type) {
  const blob = new Blob([content],
    {
      type
    });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// Event Bindings
function bindEvents() {
  // Tambah item
  document.getElementById('addItemBtn').addEventListener('click',
    addItem);

  // Hapus semua
  document.getElementById('clearAllBtn').addEventListener('click',
    () => {
      if (state.items.length === 0) return;
      document.getElementById('confirmModal').classList.add('show');
    });

  document.getElementById('modalCancel').addEventListener('click',
    () => {
      document.getElementById('confirmModal').classList.remove('show');
    });

  document.getElementById('modalConfirm').addEventListener('click',
    () => {
      document.getElementById('confirmModal').classList.remove('show');
      clearAllItems();
      showToast('Semua item dibersihkan');
    });

  // Button tema
  document.getElementById('themeToggle').addEventListener('click',
    () => {
      document.documentElement.classList.toggle('dark');
      const icon = document.querySelector('#themeToggle i');
      icon.classList.toggle('fa-moon');
      icon.classList.toggle('fa-sun');
    });

  // Pengaturan grid
  ['gridColumns', 'gridRows', 'gridGap', 'canvasWidth', 'canvasHeight'].forEach(id => {
    document.getElementById(id).addEventListener('input', () => {
      if (id === 'canvasWidth' || id === 'canvasHeight') {
        updateCanvasSize();
      } else {
        updateGridSettings();
      }
    });
    document.getElementById(id).addEventListener('change', () => {
      saveSnapshot();
    });
  });

  document.getElementById('showGridToggle').addEventListener('click', function() {
    this.classList.toggle('active');
    state.showGrid = this.classList.contains('active');
    gridCanvas.style.backgroundImage = state.showGrid ? '': 'none';
  });

  document.getElementById('snapGridToggle').addEventListener('click', function() {
    this.classList.toggle('active');
    state.snapToGrid = this.classList.contains('active');
  });

  ['propColStart', 'propColEnd', 'propRowStart', 'propRowEnd'].forEach(id => {
    document.getElementById(id).addEventListener('change',
      function() {
        const item = getSelectedItem();
        if (!item) return;

        const prop = id.replace('prop', '').replace('Col', 'col').replace('Row', 'row');
        item[prop] = parseInt(this.value) || 1;
        renderItems();
        generateCode();
        saveSnapshot();
      });
  });

  document.getElementById('propJustify').addEventListener('change', function() {
    const item = getSelectedItem();
    if (item) {
      item.justifySelf = this.value;
      renderItems();
      generateCode();
      saveSnapshot();
    }
  });

  document.getElementById('propAlign').addEventListener('change',
    function() {
      const item = getSelectedItem();
      if (item) {
        item.alignSelf = this.value;
        renderItems();
        generateCode();
        saveSnapshot();
      }
    });

  document.getElementById('propLabel').addEventListener('change',
    function() {
      const item = getSelectedItem();
      if (item) {
        item.label = this.value || 'Item';
        renderItems();
        generateCode();
        saveSnapshot();
      }
    });

  document.getElementById('propLabel').addEventListener('input',
    function() {
      const item = getSelectedItem();
      if (item) {
        item.label = this.value || 'Item';
        renderItems();
        generateCode();
      }
    });

  // Color palette
  document.getElementById('colorPalette').addEventListener('click',
    (e) => {
      const swatch = e.target.closest('.color-swatch');
      if (!swatch) return;

      const item = getSelectedItem();
      if (item) {
        item.color = swatch.dataset.color;
        document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
        swatch.classList.add('active');
        renderItems();
        generateCode();
        saveSnapshot();
      }
    });

  // Tab code
  const appContainer = document.querySelector('.app-container');
  const codeTabs = document.querySelectorAll('.code-tab');
  const codeBlocks = document.querySelectorAll('.code-block');

  codeTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // aktifkan tab
      codeTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      // tampilkan konten sesuai tab
      codeBlocks.forEach(b => b.classList.remove('active'));
      document.getElementById(tab.dataset.tab + 'Code')?.classList.add('active');
    });
  });

  // Toggle code panel
  document.getElementById('toggleCodePanel').addEventListener('click',
    () => {
      const panel = document.getElementById('codePanel');
      const icon = document.querySelector('#toggleCodePanel i');
      panel.classList.toggle('collapsed');
      icon.classList.toggle('fa-chevron-down');
      icon.classList.toggle('fa-chevron-up');
    });

  // Copy code
  document.getElementById('copyCodeBtn').addEventListener('click',
    () => {
      const activeTab = document.querySelector('.code-tab.active').dataset.tab;
      if (activeTab === 'html') {
        copyToClipboard(getRawHTML());
      } else if (activeTab === 'css') {
        copyToClipboard(getRawCSS());
      } else {
        copyToClipboard(getRawHTML() + '\n\n' + '<style>\n' + getRawCSS() + '</style>');
      }
    });

  // Download
  document.getElementById('downloadBtn').addEventListener('click',
    () => {
      const fullHTML = `<!DOCTYPE html>
      <html lang="en">
      <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Grid Layout</title>
      <style>
      ${getRawCSS()}
      </style>
      </head>
      <body>
      ${getRawHTML()}
      </body>
      </html>`;
      downloadFile(fullHTML, 'grid-layout.html', 'text/html');
      showToast('Mengunduh grid-layout.html');
    });


  const fullscreenBtn = document.getElementById('fullscreenToggle');
  const fullscreenIcon = fullscreenBtn.querySelector('i');

  fullscreenBtn.addEventListener('click',
    () => {
      const isFullscreen = appContainer.classList.toggle('fullscreen-code');

      // icon
      fullscreenIcon.className = `fas ${
      isFullscreen ? 'fa-times': 'fa-expand'
      }`;

      fullscreenBtn.setAttribute(
        'data-tooltip',
        isFullscreen ? 'Exit Fullscreen': 'Fullscreen'
      );
    });

  gridCanvas.addEventListener('click',
    (e) => {
      if (e.target === gridCanvas) {
        state.selectedId = null;
        document.querySelectorAll('.grid-item').forEach(el => el.classList.remove('selected'));
        updatePropertiesPanel();
      }
    });

  // Undo/Redo buttons
  document.getElementById('undoBtn').addEventListener('click', undo);
  document.getElementById('redoBtn').addEventListener('click', redo);

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
      e.preventDefault();
      undo();
    }
    if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) {
      e.preventDefault();
      redo();
    }
  });

  // Responsive CSS toggle
  document.getElementById('responsiveToggle').addEventListener('click', function() {
    this.classList.toggle('active');
    state.responsiveCSS = this.classList.contains('active');
    generateCode();
  });
}
init();
