SELAMAT DATANG DI SCRIPT BOT CPANEL V1 RESELLER GAMING NO ENC 100% DAN BISA DIPAKAI SAMA SIAPA AJA 😊🙏

💸 Donate
https://donate.resellergaming.my.id

Channel Info Developer ( WhatsApp )
https://whatsapp.com/channel/0029VbAt2GM7j6g6d13Xx01X

Channel Info Developer ( Telegram )
https://t.me/InfoResellerGamingDEV

👨‍💻 kontak Developer
https://t.me/ResellerGamingoffcial

📑 TUTORIAL 
( siapkan 2 Panel )
1. Run terlebih dulu SC CPANEL nya dan kaitkan dengan bot telegram 
2. Run SC bukti TF, jika ingin sama 1 bot silakan sama isi token Bot dan jika ingin beda bot silahkan isi beda token
3. dan terimakasih semoga bermanfaat 

jangan lupa bantu donate 😊🙏 biar tambah semangat 😭
💸 Donate
https://donate.resellergaming.my.id

© Reseller Gaming Programer 