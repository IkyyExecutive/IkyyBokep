let selectedFile = null;
let resultBlob = null;
let resultUrl = null;

const fileInput = document.getElementById('fileInput');
const uploadArea = document.getElementById('uploadArea');
const generateBtn = document.getElementById('generateBtn');
const previewContainer = document.getElementById('previewContainer');
const originalPreview = document.getElementById('originalPreview');
const resultSection = document.getElementById('resultSection');
const resultImage = document.getElementById('resultImage');
const downloadBtn = document.getElementById('downloadBtn');
const shareBtn = document.getElementById('shareBtn');
const newBtn = document.getElementById('newBtn');
const loadingOverlay = document.getElementById('loadingOverlay');
const emptyState = document.getElementById('emptyState');
const notification = document.getElementById('notification');

// Event Listeners
uploadArea.addEventListener('click', () => {
    fileInput.click();
});

uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.style.background = 'rgba(183, 28, 28, 0.15)';
    uploadArea.style.borderColor = 'var(--light-pink)';
});

uploadArea.addEventListener('dragleave', (e) => {
    e.preventDefault();
    uploadArea.style.background = 'rgba(255,255,255,0.06)';
    uploadArea.style.borderColor = 'var(--primary-pink)';
});

uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.style.background = 'rgba(255,255,255,0.06)';
    uploadArea.style.borderColor = 'var(--primary-pink)';
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        handleFile(files[0]);
    }
});

fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    handleFile(file);
});

generateBtn.addEventListener('click', async () => {
    if (!selectedFile) {
        showNotification('Pilih foto terlebih dahulu!', 'error');
        return;
    }
    
    await processImage();
});

downloadBtn.addEventListener('click', () => {
    if (!resultBlob || !resultUrl) {
        showNotification('Tidak ada foto untuk di-download!', 'error');
        return;
    }
    
    const link = document.createElement('a');
    link.href = resultUrl;
    link.download = 'edited-photo-' + Date.now() + '.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showNotification('Foto berhasil di-download!', 'success');
});

shareBtn.addEventListener('click', async () => {
    if (!resultBlob || !resultUrl) {
        showNotification('Tidak ada foto untuk dibagikan!', 'error');
        return;
    }
    
    try {
        if (navigator.share) {
            const file = new File([resultBlob], 'edited-photo.png', { type: 'image/png' });
            
            await navigator.share({
                title: 'Hasil Edit Foto',
                text: 'Lihat hasil edit fotoku dengan AI Photo Editor!',
                files: [file]
            });
            
            showNotification('Berhasil dibagikan!', 'success');
        } else {
            await navigator.clipboard.writeText(resultUrl);
            showNotification('Link foto disalin!', 'info');
        }
    } catch (error) {
        console.error('Error sharing:', error);
        window.open(resultUrl, '_blank');
        showNotification('Foto dibuka di tab baru', 'info');
    }
});

newBtn.addEventListener('click', () => {
    selectedFile = null;
    fileInput.value = '';
    previewContainer.style.display = 'none';
    resultSection.style.display = 'none';
    emptyState.style.display = 'block';
    generateBtn.disabled = true;
    
    if (resultUrl) {
        URL.revokeObjectURL(resultUrl);
        resultUrl = null;
    }
    resultBlob = null;
    
    showNotification('Siap edit foto baru!', 'info');
});

// Functions
function handleFile(file) {
    if (!file) return;
    
    if (!file.type.startsWith('image/')) {
        showNotification('Harap pilih photo!', 'error');
        return;
    }
    
    if (file.size > 10 * 1024 * 1024) {
        showNotification('Ukuran file maksimal 10MB!', 'error');
        return;
    }
    
    selectedFile = file;
    
    const reader = new FileReader();
    reader.onload = (e) => {
        originalPreview.src = e.target.result;
        previewContainer.style.display = 'block';
        emptyState.style.display = 'none';
        generateBtn.disabled = false;
    };
    reader.readAsDataURL(file);
    
    resultSection.style.display = 'none';
    if (resultUrl) {
        URL.revokeObjectURL(resultUrl);
        resultUrl = null;
    }
    resultBlob = null;
}

async function processImage() {
    try {
        loadingOverlay.style.display = 'flex';
        
        const formData = new FormData();
        formData.append('image', selectedFile);
        
        const apiUrl = 'https://next-api-v1.vercel.app/tools/removeclothes';
        
        const response = await fetch(apiUrl, {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        resultBlob = await response.blob();
        
        if (resultUrl) {
            URL.revokeObjectURL(resultUrl);
        }
        
        resultUrl = URL.createObjectURL(resultBlob);
        
        resultImage.src = resultUrl;
        resultSection.style.display = 'block';
        emptyState.style.display = 'none';
        
        loadingOverlay.style.display = 'none';
        
        showNotification('Foto berhasil diproses!', 'success');
        
    } catch (error) {
        console.error('Error processing image:', error);
        loadingOverlay.style.display = 'none';
        showNotification('Gagal memproses foto: ' + error.message, 'error');
    }
}

function showNotification(message, type) {
    notification.textContent = message;
    notification.className = `notification ${type}`;
    notification.classList.add('show');
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

window.addEventListener('beforeunload', () => {
    if (resultUrl) {
        URL.revokeObjectURL(resultUrl);
    }
});