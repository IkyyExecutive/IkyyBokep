// config.js - File konfigurasi untuk multiple API keys
const CONFIG = {
    // Daftar API Keys yang bisa digunakan (tambah sesuai kebutuhan)
    API_KEYS: [
        "AIzaSyCn0CIs-NNn1QQRi6d9epN_ttjrK1rX6EM", 
        "AIzaSyBqMODlYUVyyclS5W39wT9FRzE6QxqplV0", 
        "AIzaSyA8PngT9g-1tbtZcqZX143B1rPLc6qjV40", 
        "AIzaSyA0Clx8OD1SV4e9_1AdjmkYAY17CS5M6bg", 
        "AIzaSyDlmxpgRMVk3-H33BLMcTwGSocnRlj6ui4", 
        "AIzaSyCGAQWqUOVB65AZy0bs0BMgrdT1HTV7Zkc"// GEMINI
    ],
    
    // Konfigurasi default
    DEFAULT_MODEL: "gemini-2.5-flash/gemini-2.5-pro/gemini-2.5-flash-image/gemini-3.1-flash-lite-preview", // Model Gemini
    DEFAULT_PROVIDER: "gemini", // "gemini" atau "openai"
    
    // Auto rotate API key jika satu key error/limit
    AUTO_ROTATE: true,
    
};

// Jangan ubah kode di bawah ini
window.API_CONFIG = CONFIG;
