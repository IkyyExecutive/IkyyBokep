let selectedAmount = 5000;
let currentTransactionId = null;
let lastRequestTime = 0;
const REQUEST_COOLDOWN = 30000;
let captchaVerified = false;

const amountButtons = document.querySelectorAll('.amount-btn');
const customAmountInput = document.querySelector('.custom-input');
const generateBtn = document.getElementById('generateQRIS');
const loadingElement = document.getElementById('loading');
const errorMessageElement = document.getElementById('errorMessage');
const errorTextElement = document.getElementById('errorText');
const successMessageElement = document.getElementById('successMessage');
const successTextElement = document.getElementById('successText');
const qrisSection = document.getElementById('qrisSection');
const qrisImageContainer = document.getElementById('qrisImageContainer');
const transactionIdElement = document.getElementById('transactionId');
const transactionAmountElement = document.getElementById('transactionAmount');
const expiryTimeElement = document.getElementById('expiryTime');
const loadMutasiBtn = document.getElementById('loadMutasi');
const mutasiLoading = document.getElementById('mutasiLoading');
const mutasiBody = document.getElementById('mutasiBody');
const mutasiTable = document.getElementById('mutasiTable');
const noMutasiElement = document.getElementById('noMutasi');

function formatCurrency(amount) {
    if (!amount) return 'Rp 0';
    if (typeof amount === 'string') {
        amount = amount.replace(/\./g, '');
        amount = amount.replace(',', '.');
        amount = parseFloat(amount);
    }
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount);
}

function parseAmount(amount) {
    if (!amount) return 0;
    if (typeof amount === 'string') {
        amount = amount.replace(/\./g, '');
        amount = amount.replace(',', '.');
        return parseFloat(amount);
    }
    return parseFloat(amount);
}

function formatDate(dateString) {
    try {
        if (dateString.includes('/')) {
            const parts = dateString.split(' ');
            if (parts.length === 2) return parts[0] + ' ' + parts[1];
            return dateString;
        }
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return 'Tanggal tidak valid';
        return date.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }) + ' ' + date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    } catch { return dateString; }
}

function showLoading() { 
    loadingElement.classList.remove('hidden');
    loadingElement.classList.add('block');
    generateBtn.disabled = true; 
}

function hideLoading() { 
    loadingElement.classList.remove('block');
    loadingElement.classList.add('hidden');
    generateBtn.disabled = !captchaVerified; 
}

function showError(message) { 
    errorTextElement.textContent = message; 
    errorMessageElement.classList.remove('hidden');
    successMessageElement.classList.add('hidden'); 
}

function hideError() { 
    errorMessageElement.classList.add('hidden'); 
}

function showSuccess(message) { 
    successTextElement.textContent = message; 
    successMessageElement.classList.remove('hidden');
    errorMessageElement.classList.add('hidden'); 
}

function hideSuccess() { 
    successMessageElement.classList.add('hidden'); 
}

function setActiveAmountButton(amount) {
    amountButtons.forEach(btn => {
        const btnAmount = parseInt(btn.dataset.amount);
        if (btnAmount === amount) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

amountButtons.forEach(btn => {
    btn.addEventListener('click', function() {
        selectedAmount = parseInt(this.dataset.amount);
        setActiveAmountButton(selectedAmount);
        customAmountInput.value = '';
    });
});

customAmountInput.addEventListener('input', function() {
    if (this.value) {
        selectedAmount = parseInt(this.value);
        setActiveAmountButton(0);
    }
});

function onCaptchaSuccess(response) {
    captchaVerified = true;
    generateBtn.disabled = false;
    generateBtn.innerHTML = '<i class="fas fa-qrcode"></i> Buat QRIS Pembayaran';
}

function onCaptchaExpired() {
    captchaVerified = false;
    generateBtn.disabled = true;
    generateBtn.innerHTML = '<i class="fas fa-shield-alt"></i> Verifikasi CAPTCHA Dahulu';
}

function getCaptchaResponse() {
    const response = grecaptcha.getResponse();
    if (!response || response.length === 0) {
        showError('Harap verifikasi bahwa Anda bukan robot');
        return null;
    }
    return response;
}

async function createQRIS() {
    if (!captchaVerified) {
        showError('Harap verifikasi CAPTCHA terlebih dahulu');
        return;
    }
    
    const now = Date.now();
    if (now - lastRequestTime < REQUEST_COOLDOWN) {
        const remaining = Math.ceil((REQUEST_COOLDOWN - (now - lastRequestTime)) / 1000);
        showError(`Tunggu ${remaining} detik sebelum membuat QRIS baru`);
        return;
    }
    
    if (!selectedAmount || selectedAmount < 500) {
        showError('Minimum donasi adalah Rp 500');
        return;
    }
    
    if (selectedAmount > 1000000) {
        showError('Maksimum donasi adalah Rp 1,000,000');
        return;
    }
    
    const captchaResponse = getCaptchaResponse();
    if (!captchaResponse) return;
    
    showLoading();
    hideError();
    hideSuccess();
    
    try {
        const response = await fetch('/api/payment/create-qris', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                amount: selectedAmount, 
                captcha: captchaResponse 
            })
        });
        
        const data = await response.json();
        hideLoading();
        
        if (data.status && data.result) {
            currentTransactionId = data.result.idtransaksi;
            lastRequestTime = Date.now();
            
            transactionIdElement.textContent = currentTransactionId;
            transactionAmountElement.textContent = formatCurrency(data.result.jumlah);
            expiryTimeElement.textContent = formatDate(data.result.expired);
            
            qrisImageContainer.innerHTML = `
                <img src="${data.result.imageqris.url}" alt="QRIS Payment" class="qris-image w-64 h-64">
                <p class="mt-3 text-sm text-gray-400">ID: ${currentTransactionId}</p>
            `;
            
            qrisSection.classList.remove('hidden');
            
            const scrollPosition = qrisSection.offsetTop - 100;
            window.scrollTo({ top: scrollPosition, behavior: 'smooth' });
            
            showSuccess('QRIS berhasil dibuat! Silakan scan untuk membayar.');
            
            setTimeout(loadMutasi, 2000);
            
        } else {
            showError(data.error || data.message || 'Gagal membuat QRIS. Silakan coba lagi.');
            grecaptcha.reset();
            captchaVerified = false;
            generateBtn.disabled = true;
            generateBtn.innerHTML = '<i class="fas fa-shield-alt"></i> Verifikasi CAPTCHA Dahulu';
        }
    } catch (error) {
        hideLoading();
        showError('Koneksi gagal. Periksa jaringan Anda dan coba lagi.');
        console.error('Error creating QRIS:', error);
        grecaptcha.reset();
        captchaVerified = false;
        generateBtn.disabled = true;
        generateBtn.innerHTML = '<i class="fas fa-shield-alt"></i> Verifikasi CAPTCHA Dahulu';
    }
}

async function loadMutasi() {
    mutasiLoading.classList.remove('hidden');
    mutasiLoading.classList.add('block');
    mutasiBody.innerHTML = '';
    
    try {
        const response = await fetch('/api/payment/mutasi');
        const data = await response.json();
        
        mutasiLoading.classList.remove('block');
        mutasiLoading.classList.add('hidden');
        
        if (data.status && data.result) {
            const { qris_history } = data.result;
            
            if (qris_history && qris_history.success && qris_history.results && qris_history.results.length > 0) {
                const inTransactions = qris_history.results.filter(item => item.status === 'IN');
                
                if (inTransactions.length > 0) {
                    noMutasiElement.classList.add('hidden');
                    mutasiTable.classList.remove('hidden');
                    
                    inTransactions.forEach(item => {
                        const row = document.createElement('tr');
                        const amount = item.kredit && parseAmount(item.kredit) > 0 ? parseAmount(item.kredit) : parseAmount(item.debet);
                        const isCredit = item.kredit && parseAmount(item.kredit) > 0;
                        const amountColor = isCredit ? '#51cf66' : '#ff6b6b';
                        const amountSign = isCredit ? '+' : '-';
                        const status = item.status === 'IN' ? 'Berhasil' : 'Pending';
                        const statusClass = item.status === 'IN' ? 'status-success' : 'status-pending';
                        
                        row.innerHTML = `
                            <td class="py-3 px-4 text-gray-400 text-sm">${formatDate(item.tanggal || '-')}</td>
                            <td class="py-3 px-4 font-semibold" style="color: ${amountColor}">${amountSign} ${formatCurrency(amount)}</td>
                            <td class="py-3 px-4"><span class="status-badge ${statusClass}"><i class="fas ${item.status === 'IN' ? 'fa-check-circle' : 'fa-clock'} mr-1"></i> ${status}</span></td>
                        `;
                        mutasiBody.appendChild(row);
                    });
                } else {
                    noMutasiElement.classList.remove('hidden');
                    mutasiTable.classList.add('hidden');
                }
            } else {
                noMutasiElement.classList.remove('hidden');
                mutasiTable.classList.add('hidden');
            }
        } else {
            showError('Format data tidak valid');
            noMutasiElement.classList.remove('hidden');
            mutasiTable.classList.add('hidden');
        }
    } catch (error) {
        mutasiLoading.classList.remove('block');
        mutasiLoading.classList.add('hidden');
        noMutasiElement.innerHTML = `
            <div class="w-20 h-20 bg-red-900/20 border border-red-800/50 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-exclamation-triangle text-red-400 text-2xl"></i>
            </div>
            <h4 class="text-red-400 font-semibold mb-2">Gagal Memuat Data</h4>
            <p class="text-gray-400">Silakan refresh halaman atau coba beberapa saat lagi</p>
        `;
        noMutasiElement.classList.remove('hidden');
        mutasiTable.classList.add('hidden');
        console.error('Error loading mutasi:', error);
    }
}

generateBtn.addEventListener('click', createQRIS);

loadMutasiBtn.addEventListener('click', function() {
    loadMutasi();
    showSuccess('Riwayat donasi diperbarui');
    setTimeout(hideSuccess, 3000);
});

document.addEventListener('DOMContentLoaded', function() {
    setActiveAmountButton(5000);
    
    loadMutasi();
    
    generateBtn.disabled = true;
    generateBtn.innerHTML = '<i class="fas fa-shield-alt"></i> Verifikasi CAPTCHA Dahulu';
    
    const firstButton = document.querySelector('.amount-btn[data-amount="5000"]');
    if (firstButton) {
        firstButton.click();
    }
});
