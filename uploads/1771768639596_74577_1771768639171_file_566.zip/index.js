const { Telegraf, Markup, session } = require("telegraf");
const axios = require("axios");
const chalk = require("chalk");
const fs = require("fs");
const path = require("path");
const qs = require("querystring");
const FormData = require("form-data");
const archiver = require("archiver");
const readline = require("readline");
const QRCode = require("qrcode");
const config = require("./config");
const { createdQris, cekStatus, toRupiah } = require("./lib/payment");

const bot = new Telegraf(config.botToken);
bot.use(session());

const globalNokos = {
  cachedServices: [],
  cachedCountries: {},
  lastServicePhoto: {},
  activeOrders: {}
};

// Fungsi animasi loading untuk order nokos

// Helper function untuk perhitungan harga
function calcTotalPrice(base, qty) {
    return base * qty;
}

// Helper function untuk render teks pembelian
function renderPurchaseText(app, qty, total) {
    return `<blockquote><b>🛒 𝗢𝗥𝗗𝗘𝗥 ${app.nama}</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>💰 𝖧𝖺𝗋𝗀𝖺 𝖲𝖺𝗍𝗎𝖺𝗇 :</b> ${toRupiah(app.harga)}
<b>📦 𝖩𝗎𝗆𝗅𝖺𝗁 :</b> ${qty}
<b>💵 𝖳𝗈𝗍𝖺𝗅 :</b> ${toRupiah(total)}
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>🚀 𝖠𝗍𝗎𝗋 𝖩𝗎𝗆𝗅𝖺𝗁 𝖮𝗋𝖽𝖾𝗋 𝖣𝖾𝗇𝗀𝖺𝗇 𝖳𝗈𝗆𝖻𝗈𝗅 +/- 𝖣𝗂𝖻𝖺𝗐𝖺𝗁 :</b></blockquote>`;
}

// Fungsi cek saldo user
async function checkUserBalance(userId) {
    const dbSaldoPath = "./database/saldoOtp.json";
    if (fs.existsSync(dbSaldoPath)) {
        try {
            const saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
            return saldoData[userId] || 0;
        } catch (err) {
            return 0;
        }
    }
    return 0;
}

// PERBAIKAN: Fungsi untuk mengurangi saldo dengan validasi
async function deductUserBalance(userId, amount, reason = "Purchase") {
    const dbSaldoPath = "./database/saldoOtp.json";
    try {
        let saldoData = {};
        
        if (fs.existsSync(dbSaldoPath)) {
            saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
        }
        
        const currentBalance = saldoData[userId] || 0;
        
        if (currentBalance < amount) {
            return { 
                success: false, 
                message: "Saldo tidak cukup!",
                currentBalance: currentBalance,
                required: amount
            };
        }
        
        // Kurangi saldo
        saldoData[userId] = currentBalance - amount;
        
        // Simpan ke database
        fs.writeFileSync(dbSaldoPath, JSON.stringify(saldoData, null, 2));
        
        // Log transaksi
        logSaldoTransaction(userId, -amount, "deduct", reason);
        
        console.log(`[DEDUCT SALDO] User ${userId}: ${amount} - ${reason}`);
        
        return { 
            success: true, 
            newBalance: saldoData[userId],
            message: "Saldo berhasil dikurangi",
            previousBalance: currentBalance
        };
        
    } catch (error) {
        console.error("[ERROR] deductUserBalance:", error);
        return { 
            success: false, 
            message: error.message 
        };
    }
}

// PERBAIKAN: Fungsi untuk log transaksi saldo
function logSaldoTransaction(userId, amount, type, reason) {
    try {
        const logPath = "./database/saldo_logs.json";
        let logs = [];
        
        if (fs.existsSync(logPath)) {
            logs = JSON.parse(fs.readFileSync(logPath, "utf8"));
        }
        
        logs.push({
            userId: userId,
            amount: amount,
            type: type, // 'add' atau 'deduct'
            reason: reason,
            timestamp: Date.now(),
            date: new Date().toISOString()
        });
        
        // Limit log ke 1000 entry terakhir
        if (logs.length > 1000) {
            logs = logs.slice(-1000);
        }
        
        fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));
        
    } catch (error) {
        console.error("[ERROR] logSaldoTransaction:", error);
    }
}

async function showNokosLoading(ctx, text = "Memproses...") {
  const msg = await ctx.reply(`⏳ ${text}`);
  return {
    message: msg,
    stop: async () => {
      try {
        await ctx.deleteMessage(msg.message_id);
      } catch (e) {}
    }
  };
}


// Cache yang lebih baik untuk layanan
let serviceCache = {
  data: [],
  timestamp: 0,
  ttl: 300000 // 5 menit
};

async function getCachedServices() {
  const now = Date.now();
  if (serviceCache.data.length === 0 || (now - serviceCache.timestamp) > serviceCache.ttl) {
    try {
      const res = await axios.get("https://www.rumahotp.com/api/v2/services", { 
        headers: { "x-apikey": config.RUMAHOTP },
        timeout: 10000 // Timeout 10 detik
      });
      
      if (res.data.success) {
        serviceCache.data = res.data.data;
        serviceCache.timestamp = now;
      }
    } catch (error) {
      console.error("Cache refresh error:", error.message);
      // Keep old cache if available
    }
  }
  return serviceCache.data;
}

function isPrivateChat(ctx) {
  return ctx.chat.type === 'private';
}

// Fungsi untuk cek membership channel
async function checkChannelMembership(userId) {
  try {
    // Pastikan channel sudah dikonfigurasi
    if (!config.channelName && !config.channelId) {
      console.log("[DEBUG] Channel tidak dikonfigurasi, skip check");
      return true;
    }
    
    const channelUsername = config.channelName || config.channelId?.replace('@', '');
    
    if (!channelUsername) {
      console.log("[DEBUG] Channel username tidak ditemukan");
      return true;
    }
    
    console.log(`[DEBUG] Checking membership for user ${userId} in channel ${channelUsername}`);
    
    // Cek status user di channel
    const chatMember = await bot.telegram.getChatMember(`@${channelUsername}`, userId);
    
    console.log(`[DEBUG] User ${userId} status: ${chatMember.status}`);
    
    // Status yang diperbolehkan
    const allowedStatuses = ['creator', 'administrator', 'member'];
    const isMember = allowedStatuses.includes(chatMember.status);
    
    return isMember;
    
  } catch (error) {
    console.error(`[ERROR] Failed to check channel membership:`, error.message);
    
    // Jika error karena bot tidak ada di channel atau channel tidak ditemukan
    if (error.description && (
      error.description.includes('bot is not a member') || 
      error.description.includes('chat not found') ||
      error.description.includes('CHAT_NOT_FOUND')
    )) {
      console.log("[WARNING] Bot tidak ada di channel atau channel tidak ditemukan");
      return true; // Skip check untuk development
    }
    
    return false;
  }
}

async function notifyOwnerNewUser(user) {
  try {
    const username = user.username ? `@${user.username}` : "-"
    const name = `${user.first_name || ""} ${user.last_name || ""}`.trim()
    const time = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
    
    const users = loadUsers()
    const totalUsers = users.length

    const text = `👤 <b>USER BARU TERDETEKSI</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `<b>Nama :</b> ${name}\n` +
      `<b>Username :</b> ${username}\n` +
      `<b>ID :</b> <code>${user.id}</code>\n` +
      `<b>Waktu :</b> ${time}\n\n` +
      `📊 <b>Total User:</b> ${totalUsers}`

    await bot.telegram.sendMessage(config.ownerId, text, { parse_mode: "HTML" })
  } catch (e) {
    console.log(e)
  }
}

async function requirePrivateChat(ctx, actionName) {
  if (!isPrivateChat(ctx)) {
    await ctx.answerCbQuery("❌ Perintah ini hanya bisa digunakan di Private Chat!", { show_alert: true });
    
    try {
      await ctx.reply("🚫 𝗙𝗜𝗧𝗨𝗥 𝗧𝗜𝗗𝗔𝗞 𝗕𝗜𝗦𝗔 𝗗𝗜𝗚𝗨𝗡𝗔𝗞𝗔𝗡!\n━━━━━━━━━━━━━━━━━━━━❍\n🚀 𝗛𝗮𝗻𝘆𝗮 𝗕𝗶𝘀𝗮 𝗗𝗶𝗴𝘂𝗻𝗮𝗸𝗮𝗻 𝗗𝗶\n𝗣𝗿𝗶𝘃𝗮𝘁𝗲 𝗖𝗵𝗮𝘁 𝗕𝗼𝘁!:", {
        reply_markup: {
          inline_keyboard: [
            [{ text: "🌸 𝗖𝗵𝗮𝘁 𝗕𝗼𝘁 𝗦𝗲𝗸𝗮𝗿𝗮𝗻𝗴", url: `https://t.me/${bot.botInfo.username}` }]
          ]
        }
      });
    } catch (e) {}
    
    return false;
  }
  return true;
}

async function getDropletCount() {
  try {
    const response = await fetch('https://api.digitalocean.com/v2/droplets', {
      headers: {
        'Authorization': `Bearer ${config.DO_TOKEN}` 
      }
    });
    
    if (!response.ok) {
      console.error('Gagal mengambil data droplet:', response.status);
      return 0;
    }
    
    const data = await response.json();
    return data.droplets.length;
    
  } catch (error) {
    console.error('Error getDropletCount:', error);
    return 0;
  }
}

async function createVPSDroplet(userId, vpsData) {
  try {
    const apiDO = config.ApiDO1;
    if (!apiDO) {
      return { success: false, msg: "API KEY DigitalOcean tidak ditemukan!" };
    }

    const sizeMap = {
      "2c2": "s-2vcpu-2gb-amd",
      "4c2": "s-2vcpu-4gb-amd",
      "8c4": "s-4vcpu-8gb-amd",
      "16c4": "s-4vcpu-16gb-amd",
      "16c8": "s-8vcpu-16gb-amd"
    };

    const size = sizeMap[vpsData.plan];
    if (!size) {
      return { success: false, msg: "PLAN VPS TIDAK VALID!" };
    }

    const osShort = (vpsData.osFamily || "ubuntu").toLowerCase();
    const regionShort = (vpsData.region || "sgp1").toLowerCase();
    const planShort = (vpsData.plan || "2c2").toLowerCase();
    const urut = String(Math.floor(Math.random() * 90) + 10);
    const hostname = `${osShort}-${planShort}-${regionShort}-${urut}`;
    const password = `${config.CostumPassVps}` + size.replace(/s-|-/g, "").toUpperCase();

    const payload = {
      name: hostname,
      region: vpsData.region,
      size: size,
      image: vpsData.os,
      ipv6: true,
      backups: false,
      tags: ["order-BuyVPS"],
      user_data: `#cloud-config
password: ${password}
chpasswd: { expire: False }`
    };

    console.log("Creating VPS with payload:", JSON.stringify(payload, null, 2));

    const resp = await axios.post("https://api.digitalocean.com/v2/droplets", payload, {
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiDO}`
      },
      timeout: 30000
    });

    if (resp.status !== 202) {
      return { success: false, msg: "Gagal membuat VPS: " + JSON.stringify(resp.data) };
    }

    const dropletId = resp.data.droplet.id;
    console.log(`VPS Created - ID: ${dropletId}, Hostname: ${hostname}`);

    await new Promise(r => setTimeout(r, 60000));

    const cek = await axios.get(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
      headers: { "Authorization": `Bearer ${apiDO}` },
      timeout: 10000
    });

    const dropletInfo = cek.data.droplet;
    const ip = dropletInfo?.networks?.v4?.[0]?.ip_address || "N/A";
    
    console.log(`VPS IP: ${ip}`);

    const vpsFolder = "./database";
    const vpsPath = `${vpsFolder}/data_vps.json`;

    if (!fs.existsSync(vpsFolder)) {
      fs.mkdirSync(vpsFolder, { recursive: true });
    }

    if (!fs.existsSync(vpsPath)) {
      fs.writeFileSync(vpsPath, JSON.stringify([], null, 2));
    }

    let vpsDB = [];
    try {
      vpsDB = JSON.parse(fs.readFileSync(vpsPath));
      if (!Array.isArray(vpsDB)) vpsDB = [];
    } catch (err) {
      vpsDB = [];
    }

    const created = new Date().toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });

    const paketInfo = {
      low: { garansi: 7, replace: 1 },
      medium: { garansi: 15, replace: 2 },
      high: { garansi: 30, replace: -1 }
    };

    const newVpsData = {
      userId: userId,
      username: vpsData.username || "-",
      hostname: hostname,
      ip: ip,
      password: password,
      region: vpsData.region,
      osFamily: vpsData.osFamily,
      os: vpsData.os,
      paket: vpsData.paket,
      plan: vpsData.plan,
      garansi: paketInfo[vpsData.paket]?.garansi || 7,
      replace: paketInfo[vpsData.paket]?.replace || 1,
      harga: vpsData.harga,
      dropletId: dropletId,
      created: created,
      penjual: bot.botInfo.username
    };

    vpsDB.push(newVpsData);
    fs.writeFileSync(vpsPath, JSON.stringify(vpsDB, null, 2));

    return {
      success: true,
      data: {
        hostname,
        ip,
        password,
        region: vpsData.region,
        os: vpsData.os,
        plan: vpsData.plan,
        garansi: paketInfo[vpsData.paket]?.garansi || 7,
        replace: paketInfo[vpsData.paket]?.replace || 1,
        created
      }
    };

  } catch (error) {
    console.error("Error creating VPS:", error);
    return { 
      success: false, 
      msg: error.response?.data?.message || error.message || "Unknown error" 
    };
  }
}

async function atlanticTransfer(nominal, config, note = "Withdraw Saldo Bot") {
  try {
    const reffId = `wd_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const body = {
      api_key: config.apiAtlantic,
      ref_id: reffId,
      kode_bank: config.wd_balance.bank_code,
      nomor_akun: config.wd_balance.destination_number,
      nama_pemilik: config.wd_balance.destination_name,
      nominal: Number(nominal),
      email: "bot@telegram.com",
      phone: config.wd_balance.destination_number,
      note: note
    };

    const response = await axios.post("https://atlantich2h.com/transfer/create", qs.stringify(body), {
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      timeout: 15000
    });

    return response.data;
  } catch (error) {
    throw new Error(`Gagal membuat transfer: ${error.message}`);
  }
}

async function atlanticTransferStatus(transferId, api_key) {
  const body = { api_key, id: String(transferId) };
  const response = await axios.post("https://atlantich2h.com/transfer/status", qs.stringify(body), {
    headers: { "Content-Type": "application/x-www-form-urlencoded" }
  });
  return response.data;
}

async function editMenuMessage(ctx, text, keyboard) {
  try {
    await ctx.editMessageText(text, {
      parse_mode: "HTML",
      ...keyboard
    });
  } catch (e) {
    try {
      const newMsg = await safeReply(ctx, text, {
        parse_mode: "HTML",
        ...keyboard
      });
      
      try {
        if (ctx.callbackQuery) {
          await ctx.deleteMessage();
        }
      } catch (err) {}
      
      return newMsg;
    } catch (replyErr) {
      console.error("Edit menu error:", replyErr);
      return null;
    }
  }
}

async function editMenuMessageWithPhoto(ctx, photo, caption, keyboard) {
  try {
    await ctx.editMessageMedia({
      type: 'photo',
      media: photo,
      caption: caption,
      parse_mode: 'HTML'
    }, {
      parse_mode: "HTML",
      ...keyboard
    });
  } catch (e) {
    try {
      try {
        if (ctx.callbackQuery) {
          await ctx.deleteMessage();
        }
      } catch (err) {}
      
      await ctx.replyWithPhoto(photo, {
        caption: caption,
        parse_mode: "HTML",
        ...keyboard
      });
    } catch (replyErr) {
      console.error("Edit menu with photo error:", replyErr);
      return null;
    }
  }
}

async function safeSend(method, chatId, ...args) {
  try {
    return await bot.telegram[method](chatId, ...args);
  } catch (err) {
    const m = err?.response?.description || err?.description || err?.message || String(err);
    if (typeof m === 'string' && (m.toLowerCase().includes('user is deactivated') || m.toLowerCase().includes('bot was blocked') || m.toLowerCase().includes('blocked'))) {
      return null;
    }
    throw err;
  }
}

async function safeReply(ctx, text, extra = {}) {
  try {
    return await ctx.reply(text, extra);
  } catch (err) {
    const m = err?.response?.description || err?.description || err?.message || String(err);
    if (typeof m === 'string' && (m.toLowerCase().includes('user is deactivated') || m.toLowerCase().includes('bot was blocked') || m.toLowerCase().includes('blocked'))) {
      return null;
    }
    throw err;
  }
}

const USERS_DB = "./users.json";
const DB_PATH = "./database.json";
const MANUAL_PAYMENTS_DB = "./manual_payments.json";
const activeTransactions = {};
const userState = {};
const liveChatState = {};
const ownerReplyState = {};
const SMM_HISTORY_DB = "./database/smm_history.json";

function getSmmHistory(userId) {
  if (!fs.existsSync(SMM_HISTORY_DB)) fs.writeFileSync(SMM_HISTORY_DB, JSON.stringify({}));
  const db = JSON.parse(fs.readFileSync(SMM_HISTORY_DB));
  return db[userId] || [];
}

function saveSmmHistory(userId, orderData) {
  const db = JSON.parse(fs.readFileSync(SMM_HISTORY_DB));
  if (!db[userId]) db[userId] = [];
  db[userId].unshift(orderData); 
  fs.writeFileSync(SMM_HISTORY_DB, JSON.stringify(db, null, 2));
}

async function callSmmApi(path, params = {}) {
  const maxRetries = 2;
  let lastError = null;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const requestBody = {
        api_id: config.smm.apiId,
        api_key: config.smm.apiKey,
        ...params
      };

      console.log(`[SMM API] Calling ${path} (attempt ${attempt}/${maxRetries})`, params);
      
      const response = await axios.post(`${config.smm.baseUrl}${path}`, requestBody, {
        headers: { 
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 SMM-Bot/1.0'
        },
        timeout: 10000, // Kurangi timeout jadi 10 detik
        validateStatus: function (status) {
          return status < 500; // Reject hanya jika server error
        }
      });
      
      console.log(`[SMM API] Response from ${path}:`, typeof response.data, Array.isArray(response.data));
      
      // Handle berbagai format response
      let result = response.data;
      
      // Jika response adalah array langsung
      if (Array.isArray(result)) {
        console.log(`[SMM API] Got array with ${result.length} items`);
        return { status: true, data: result };
      }
      
      // Jika response memiliki properti 'data'
      if (result && result.data) {
        console.log(`[SMM API] Got data property with`, Array.isArray(result.data) ? `${result.data.length} items` : 'object');
        return result;
      }
      
      // Jika response memiliki properti 'services'
      if (result && result.services) {
        console.log(`[SMM API] Got services property with ${result.services.length} items`);
        return result;
      }
      
      // Jika response memiliki status boolean
      if (typeof result.status === 'boolean') {
        console.log(`[SMM API] Got status: ${result.status}`);
        return result;
      }
      
      // Default: return as is
      console.log(`[SMM API] Returning raw response`);
      return result;
      
    } catch (error) {
      lastError = error;
      console.error(`[SMM API] Attempt ${attempt} failed:`, error.message);
      
      if (attempt < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
      }
    }
  }

  console.error("[SMM API] All attempts failed:", lastError?.message);
  return { 
    status: false, 
    msg: "Gagal connect ke server SMM setelah beberapa percobaan" 
  };
}

let botStartTime = Date.now();

const TESTIMONI_CHANNEL = config.testimoniChannel || "";

async function createAndSendFullBackup(ctx = null, isAuto = false) {
  const timestamp = new Date().toLocaleString("id-ID", { 
    timeZone: "Asia/Jakarta" 
  }).replace(/[\/:]/g, '-').replace(/, /g, '_');
  
  const backupName = `${config.botName || 'Bot'}_${timestamp}.zip`;
  const backupPath = path.join(__dirname, backupName);
  const output = fs.createWriteStream(backupPath);
  const archive = archiver('zip', { zlib: { level: 9 } });

  console.log(`[BACKUP] Memulai proses zip full SC...`);

  return new Promise((resolve, reject) => {
    output.on('close', async () => {
      console.log(`[BACKUP] Selesai. Size: ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB`);
      
      try {
        const caption = isAuto 
          ? `♻️ <b>AUTO BACKUP SC</b>\n📅 ${timestamp}`
          : `📦 <b>BACKUP SOURCE CODE</b>\n📅 ${timestamp}`;

        await bot.telegram.sendDocument(config.ownerId, {
          source: backupPath,
          filename: backupName
        }, { caption: caption, parse_mode: "HTML" });

        fs.unlinkSync(backupPath);
        if (ctx) await ctx.reply("✅ <b>Backup SC Terkirim ke Owner!</b>", { parse_mode: "HTML" });
        resolve(true);
      } catch (err) {
        console.error("[BACKUP FAIL]", err);
        if (ctx) await ctx.reply("❌ Gagal kirim backup.");
        if (fs.existsSync(backupPath)) fs.unlinkSync(backupPath);
        reject(err);
      }
    });

    archive.on('error', (err) => reject(err));
    archive.pipe(output);

    archive.glob('**/*', {
      cwd: __dirname,
      ignore: [
        'node_modules/**',
        '.git/**',
        'session.json',
        '*.zip',
        'backups/**'
      ]
    });

    archive.finalize();
  });
}

async function generateLocalQr(qrString) {
  try {
    return await QRCode.toBuffer(qrString, {
      type: 'png',
      width: 400,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    });
  } catch (err) {
    console.error("QR Generate Error:", err);
    return null;
  }
}

async function sendTestimoniKeChannel(userName, userId, productName, amount, type = "pembelian", additionalData = {}) {
  try {
    if (!TESTIMONI_CHANNEL) {
      console.log("[INFO] Channel testimoni belum diatur di config.js");
      return;
    }

    const now = new Date();
    const options = { 
      timeZone: 'Asia/Jakarta', 
      weekday: 'long',
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    };
    const waktuWIB = now.toLocaleString('id-ID', options);
    
    // Ambil data tambahan
    const { 
      orderId = null, 
      phoneNumber = null, 
      domain = null,
      fee = 0,
      photoUrl = null,
      customerNote = null
    } = additionalData;

    // HANYA 2 FOTO DEFAULT:
    // 1. Untuk semua transaksi sukses (kecuali nokos)
    const FOTO_DEFAULT_SUCCESS = "https://files.catbox.moe/vbsgt8.jpg";
    
    // 2. Khusus untuk nokos
    const FOTO_DEFAULT_NOKOS = "https://files.catbox.moe/vbsgt8.jpg";

    // Sensor nomor telepon
    const sensorNomor = (nomor) => {
      if (!nomor) return "TIDAK TERSEDIA";
      const str = nomor.toString();
      if (str.length <= 4) return str;
      return str.substring(0, 2) + '****' + str.substring(str.length - 2);
    };

    // Sensor domain
    const sensorDomain = (url) => {
      if (!url) return "TIDAK TERSEDIA";
      try {
        const domain = url.replace(/(^\w+:|^)\/\//, '');
        const parts = domain.split('.');
        if (parts.length > 2) {
          return parts[0].substring(0, 2) + '***.' + parts.slice(1).join('.');
        }
        return domain.substring(0, 2) + '***.' + domain.split('.').slice(1).join('.');
      } catch {
        return url.substring(0, 5) + '***';
      }
    };

    // Format ID order
    const formatOrderId = (id) => {
      if (!id) return `ORD-${Date.now().toString().substring(7)}`;
      const str = id.toString();
      if (str.length <= 6) return str;
      return str.substring(0, 4) + '***' + str.substring(str.length - 4);
    };

    // Emoji berdasarkan jenis transaksi
    const emojiList = {
      "pembelian": "🛒",
      "deposit": "💰",
      "vps": "🖥️",
      "panel": "📡",
      "script": "📁",
      "app": "📱",
      "smm": "🔥",
      "nokos": "📱",
      "lainnya": "🎉"
    };
    
    const emoji = emojiList[type] || "🎉";

    // Template testimoni yang lebih lengkap
    let testimoniText = '';
    const orderIdFormatted = formatOrderId(orderId);
    
    switch(type) {
      case "deposit":
        testimoniText = `
${emoji} 𝗧𝗘𝗦𝗧𝗜𝗠𝗢𝗡𝗜 𝗗𝗘𝗣𝗢𝗦𝗜𝗧 𝗦𝗨𝗞𝗦𝗘𝗦
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 𝗜𝗗𝗘𝗡𝗧𝗜𝗧𝗔𝗦 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔
├─ 📛 𝗡𝗮𝗺𝗮 : ${userName}
├─ 🆔 𝗜𝗗 : ${userId}
├─ 📋 𝗢𝗿𝗱𝗲𝗿 𝗜𝗗 : ${orderIdFormatted}
└─ ⏰ 𝗪𝗮𝗸𝘁𝘂 : ${waktuWIB}

💰 𝗗𝗘𝗧𝗔𝗜𝗟 𝗗𝗘𝗣𝗢𝗦𝗜𝗧
├─ 💵 𝗝𝘂𝗺𝗹𝗮𝗵 : ${toRupiah(amount)}
├─ 📊 𝗧𝗼𝘁𝗮𝗹 𝗦𝗮𝗹𝗱𝗼 : ${toRupiah(parseFloat(amount))}
├─ ✅ 𝗦𝘁𝗮𝘁𝘂𝘀 : BERHASIL
└─ ⚡ 𝗣𝗿𝗼𝘀𝗲𝘀 : INSTANT

🎯 𝗣𝗔𝗡𝗗𝗨𝗔𝗡 𝗦𝗘𝗧𝗘𝗟𝗔𝗛 𝗗𝗘𝗣𝗢𝗦𝗜𝗧
1. Saldo otomatis masuk ke akun Anda
2. Bisa langsung digunakan untuk order
3. Cek riwayat transaksi di /history
4. Untuk masalah, hubungi admin

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📣 𝗧𝗲𝗿𝗶𝗺𝗮𝗸𝗮𝘀𝗶𝗵 𝗦𝘂𝗱𝗮𝗵 𝗕𝗲𝗿𝗱𝗲𝗽𝗼𝘀𝗶𝘁 𝗗𝗶 :
 ➥ ${config.botName} 𝗕𝗼𝘁`;
        break;
        
      case "nokos":
        const totalNokos = parseFloat(amount) + parseFloat(fee || 0);
        testimoniText = `
${emoji} 𝗧𝗘𝗦𝗧𝗜𝗠𝗢𝗡𝗜 𝗢𝗥𝗗𝗘𝗥 𝗡𝗢𝗞𝗢𝗦 𝗦𝗨𝗞𝗦𝗘𝗦
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 𝗜𝗗𝗘𝗡𝗧𝗜𝗧𝗔𝗦 𝗣𝗘𝗠𝗕𝗘𝗟𝗜
├─ 📛 𝗡𝗮𝗺𝗮 : ${userName}
├─ 🆔 𝗜𝗗 : ${userId}
├─ 📋 𝗢𝗿𝗱𝗲𝗿 𝗜𝗗 : ${orderIdFormatted}
└─ ⏰ 𝗪𝗮𝗸𝘁𝘂 : ${waktuWIB}

📱 𝗗𝗘𝗧𝗔𝗜𝗟 𝗢𝗥𝗗𝗘𝗥 𝗡𝗢𝗞𝗢𝗦
├─ 🛒 𝗣𝗿𝗼𝗱𝘂𝗸 : ${productName}
├─ 📞 𝗡𝗼𝗺𝗼𝗿 : ${sensorNomor(phoneNumber)}
├─ 💰 𝗛𝗮𝗿𝗴𝗮 : ${toRupiah(amount)}
├─ 📊 𝗕𝗶𝗮𝘆𝗮 𝗟𝗮𝘆𝗮𝗻𝗮𝗻 : ${toRupiah(fee || 0)}
├─ 💵 𝗧𝗼𝘁𝗮𝗹 : ${toRupiah(totalNokos)}
├─ ✅ 𝗦𝘁𝗮𝘁𝘂𝘀 : BERHASIL
└─ 🕒 𝗣𝗿𝗼𝘀𝗲𝘀 : 2-5 MENIT

⚠️ 𝗣𝗔𝗡𝗗𝗨𝗔𝗡 𝗣𝗘𝗡𝗧𝗜𝗡𝗚 𝗡𝗢𝗞𝗢𝗦
1. Tunggu 2-5 menit sebelum cek SMS
2. Jangan spam cek SMS setiap detik
3. Jika timeout (10 menit), saldo dikembalikan
4. OTP akan muncul otomatis jika berhasil
5. Simpan bukti transaksi ini

${customerNote ? `📝 𝗖𝗮𝘁𝗮𝘁𝗮𝗻 : ${customerNote}\n` : ''}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📣 𝗧𝗲𝗿𝗶𝗺𝗮𝗸𝗮𝘀𝗶𝗵 𝗧𝗲𝗹𝗮𝗵 𝗠𝗲𝗺𝗯𝗲𝗹𝗶 𝗗𝗶 :
 ➥ ${config.botName} 𝗕𝗼𝘁`;
        break;
        
      case "panel":
        testimoniText = `
${emoji} 𝗧𝗘𝗦𝗧𝗜𝗠𝗢𝗡𝗜 𝗢𝗥𝗗𝗘𝗥 𝗣𝗔𝗡𝗘𝗟 𝗦𝗨𝗞𝗦𝗘𝗦
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 𝗜𝗗𝗘𝗡𝗧𝗜𝗧𝗔𝗦 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔
├─ 📛 𝗡𝗮𝗺𝗮 : ${userName}
├─ 🆔 𝗜𝗗 : ${userId}
├─ 📋 𝗢𝗿𝗱𝗲𝗿 𝗜𝗗 : ${orderIdFormatted}
└─ ⏰ 𝗪𝗮𝗸𝘁𝘂 : ${waktuWIB}

📡 𝗗𝗘𝗧𝗔𝗜𝗟 𝗢𝗥𝗗𝗘𝗥 𝗣𝗔𝗡𝗘𝗟
├─ 🛒 𝗣𝗮𝗸𝗲𝘁 : ${productName}
├─ 🌐 𝗗𝗼𝗺𝗮𝗶𝗻 : ${sensorDomain(domain)}
├─ 💰 𝗛𝗮𝗿𝗴𝗮 : ${toRupiah(amount)}
├─ ✅ 𝗦𝘁𝗮𝘁𝘂𝘀 : AKTIF
└─ ⚡ 𝗣𝗿𝗼𝘀𝗲𝘀 : INSTANT

🔧 𝗣𝗔𝗡𝗗𝗨𝗔𝗡 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗣𝗔𝗡𝗘𝗟
1. Panel sudah aktif dan bisa digunakan
2. Cek email untuk login credentials
3. Reset password tersedia di member area
4. Support 24/7 untuk masalah teknis
5. Backup data secara berkala

${customerNote ? `📝 𝗖𝗮𝘁𝗮𝘁𝗮𝗻 : ${customerNote}\n` : ''}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📣 𝗧𝗲𝗿𝗶𝗺𝗮𝗸𝗮𝘀𝗶𝗵 𝗧𝗲𝗹𝗮𝗵 𝗠𝗲𝗺𝗯𝗲𝗹𝗶 𝗗𝗶 :
 ➥ ${config.botName} 𝗕𝗼𝘁`;
        break;
        
      default:
        testimoniText = `
${emoji} 𝗧𝗘𝗦𝗧𝗜𝗠𝗢𝗡𝗜 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗦𝗨𝗞𝗦𝗘𝗦
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 𝗜𝗗𝗘𝗡𝗧𝗜𝗧𝗔𝗦 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔
├─ 📛 𝗡𝗮𝗺𝗮 : ${userName}
├─ 🆔 𝗜𝗗 : ${userId}
├─ 📋 𝗢𝗿𝗱𝗲𝗿 𝗜𝗗 : ${orderIdFormatted}
└─ ⏰ 𝗪𝗮𝗸𝘁𝘂 : ${waktuWIB}

🎁 𝗗𝗘𝗧𝗔𝗜𝗟 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜
├─ 🛒 𝗣𝗿𝗼𝗱𝘂𝗸 : ${productName}
├─ 💰 𝗛𝗮𝗿𝗴𝗮 : ${toRupiah(amount)}
├─ ✅ 𝗦𝘁𝗮𝘁𝘂𝘀 : BERHASIL
└─ ⚡ 𝗣𝗿𝗼𝘀𝗲𝘀 : INSTANT

📌 𝗣𝗔𝗡𝗗𝗨𝗔𝗡 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡
1. Simpan bukti transaksi ini
2. Cek produk di member area
3. Untuk masalah, hubungi admin
4. Jangan bagikan data login
5. Rate layanan kami di /rate

${customerNote ? `📝 𝗖𝗮𝘁𝗮𝘁𝗮𝗻 : ${customerNote}\n` : ''}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📣 𝗧𝗲𝗿𝗶𝗺𝗮𝗸𝗮𝘀𝗶𝗵 𝗧𝗲𝗹𝗮𝗵 𝗠𝗲𝗺𝗯𝗲𝗹𝗶 𝗗𝗶 :
 ➥ ${config.botName} 𝗕𝗼𝘁`;
    }

    // Tentukan foto yang akan digunakan
    let fotoUntukKirim = photoUrl; // Prioritaskan foto dari parameter
    
    // Jika tidak ada foto dari parameter, gunakan default
    if (!fotoUntukKirim) {
      if (type === "nokos") {
        fotoUntukKirim = FOTO_DEFAULT_NOKOS; // Foto khusus nokos
      } else {
        fotoUntukKirim = FOTO_DEFAULT_SUCCESS; // Foto untuk semua transaksi lain
      }
    }

    // Kirim testimoni dengan foto
    try {
      await bot.telegram.sendPhoto(TESTIMONI_CHANNEL, fotoUntukKirim, {
        caption: testimoniText,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ 
              text: `🛒 𝗢𝗥𝗗𝗘𝗥 𝗦𝗘𝗞𝗔𝗥𝗔𝗡𝗚`, 
              url: `https://t.me/${bot.botInfo.username}?start=shop` 
            }]
          ]
        }
      });
      
      console.log(`[SUCCESS] Testimoni ${type} dengan foto berhasil dikirim`);
      return;
      
    } catch (photoError) {
      console.warn("[WARNING] Gagal mengirim foto, coba kirim teks saja:", photoError.message);
      
      // Fallback: kirim hanya teks jika gagal
      await bot.telegram.sendMessage(TESTIMONI_CHANNEL, testimoniText, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ 
              text: `🛒 𝗢𝗥𝗗𝗘𝗥 𝗦𝗘𝗞𝗔𝗥𝗔𝗡𝗚`, 
              url: `https://t.me/${bot.botInfo.username}?start=shop` 
            }]
          ]
        }
      });
      
      console.log(`[SUCCESS] Testimoni ${type} (fallback teks) berhasil dikirim`);
    }
    
  } catch (error) {
    console.error("[ERROR] Gagal mengirim testimoni ke channel:", error.message);
  }
}

function readManualPayments() {
  if (!fs.existsSync(MANUAL_PAYMENTS_DB)) {
    fs.writeFileSync(MANUAL_PAYMENTS_DB, JSON.stringify([]));
  }
  return JSON.parse(fs.readFileSync(MANUAL_PAYMENTS_DB));
}

function saveManualPayments(data) {
  fs.writeFileSync(MANUAL_PAYMENTS_DB, JSON.stringify(data, null, 2));
}

function getBotStats() {
  try {
    const users = loadUsers();
    const totalUsers = users.length;

    const uptime = Date.now() - botStartTime;
    const days = Math.floor(uptime / (1000 * 60 * 60 * 24));
    const hours = Math.floor((uptime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));

    return {
      totalUsers,
      runtime: `${days}d ${hours}h ${minutes}m`,
      botName: config.botName || "BOT TELEGRAM",
      ownerName: config.ownerName || "Owner",
      backupCount: "Auto" 
    };
  } catch (e) {
    return {
      totalUsers: "Error",
      runtime: "Unknown",
      botName: config.botName || "BOT TELEGRAM",
      ownerName: config.ownerName || "Owner",
      backupCount: "-"
    };
  }
}

// ========== FUNGSI NOTIFIKASI STOK KE CHANNEL ==========
async function sendStockNotificationToChannel(productIndex, addedCount) {
  try {
    const db = readDb();
    const app = db.apps[productIndex];
    if (!app) return;

    const totalStock = (app.accounts || []).length;
    const productName = app.nama;
    const productPrice = app.harga;
    const photoUrl = config.stockNotificationPhoto || config.startPhoto || "https://via.placeholder.com/400";

    if (!config.stockChannelId) {
      console.log("[INFO] Channel notifikasi stok belum dikonfigurasi");
      return;
    }

    const channelId = config.stockChannelId.startsWith('@') ? config.stockChannelId : `@${config.stockChannelId}`;

    const caption = `
<b>🔥𝗨𝗣𝗗𝗘𝗧 𝗦𝗧𝗢𝗞 𝗕𝗔𝗥𝗨 📢</b>

<b>📦 𝗣𝗥𝗢𝗗𝗨𝗞 :</b> ${productName}
<b>𝗦𝗧𝗢𝗞 𝗠𝗔𝗦𝗨𝗞:</b> ${addedCount}
<b>𝗧𝗢𝗧𝗔𝗟 𝗦𝗧𝗢𝗞:</b> ${totalStock}
<b>𝗛𝗔𝗥𝗚𝗔:</b> ${toRupiah(productPrice)} per akun
 
Klik tombol di bawah untuk order! 🛒
`;

    // Ganti callback button dengan URL button yang mengarah ke bot dengan start=shop
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.url(`🛒 𝗢𝗥𝗗𝗘𝗥 𝗦𝗘𝗞𝗔𝗥𝗔𝗡𝗚`, `https://t.me/${bot.botInfo.username}?start=shop`)]
    ]);

    // Coba kirim dengan foto
    try {
      await bot.telegram.sendPhoto(channelId, photoUrl, {
        caption: caption,
        parse_mode: "HTML",
        reply_markup: keyboard.reply_markup
      });
      console.log(`[NOTIF] Stock notification sent for ${productName} with photo`);
    } catch (photoError) {
      // Jika gagal, kirim teks saja
      console.warn(`[WARNING] Gagal kirim foto, fallback ke teks: ${photoError.message}`);
      await bot.telegram.sendMessage(channelId, caption, {
        parse_mode: "HTML",
        reply_markup: keyboard.reply_markup
      });
      console.log(`[NOTIF] Stock notification sent for ${productName} (text only)`);
    }

  } catch (error) {
    console.error("[ERROR] Gagal mengirim notifikasi stok:", error.message);
  }
}
// ========== BROADCAST NOTIFIKASI STOK BARU KE SEMUA USER (DENGAN FOTO) ==========
async function sendStockNotificationToAllUsers(productIndex, addedCount) {
  try {
    const db = readDb();
    const app = db.apps[productIndex];
    if (!app) return;

    const totalStock = (app.accounts || []).length;
    const productName = app.nama;
    const productPrice = app.harga;
    const photoUrl = config.stockNotificationPhoto || config.startPhoto;

    if (!photoUrl) {
      console.log("[NOTIF] Foto notifikasi tidak tersedia, kirim teks saja.");
    }

    const users = loadUsers();
    if (users.length === 0) {
      console.log("[NOTIF] Tidak ada user untuk dikirimi notifikasi stok.");
      return;
    }

    const caption = `
<b>🔥 𝗨𝗣𝗗𝗘𝗧 𝗦𝗧𝗢𝗞 𝗕𝗔𝗥𝗨 📢</b>

<b>📦 𝗣𝗥𝗢𝗗𝗨𝗞 :</b> ${productName}
<b>𝗦𝗧𝗢𝗞 𝗠𝗔𝗦𝗨𝗞:</b> ${addedCount}
<b>𝗧𝗢𝗧𝗔𝗟 𝗦𝗧𝗢𝗞:</b> ${totalStock}
<b>𝗛𝗔𝗥𝗚𝗔:</b> ${toRupiah(productPrice)} per akun
 
Klik tombol di bawah untuk order! 🛒
`;

    const keyboard = Markup.inlineKeyboard([
      [Markup.button.url(`🛒 𝗢𝗥𝗗𝗘𝗥 𝗦𝗘𝗞𝗔𝗥𝗔𝗡𝗚`, `https://t.me/${bot.botInfo.username}?start=shop`)]
    ]);

    let successCount = 0;
    let failCount = 0;

    for (const userId of users) {
      try {
        if (photoUrl) {
          await bot.telegram.sendPhoto(userId, photoUrl, {
            caption: caption,
            parse_mode: "HTML",
            reply_markup: keyboard.reply_markup
          });
        } else {
          await bot.telegram.sendMessage(userId, caption, {
            parse_mode: "HTML",
            reply_markup: keyboard.reply_markup
          });
        }
        successCount++;
      } catch (err) {
        failCount++;
        console.log(`[NOTIF] Gagal kirim ke user ${userId}: ${err.message}`);
      }
      await new Promise(resolve => setTimeout(resolve, 50));
    }

    // Kirim juga ke owner
    try {
      if (photoUrl) {
        await bot.telegram.sendPhoto(config.ownerId, photoUrl, {
          caption: caption,
          parse_mode: "HTML",
          reply_markup: keyboard.reply_markup
        });
      } else {
        await bot.telegram.sendMessage(config.ownerId, caption, {
          parse_mode: "HTML",
          reply_markup: keyboard.reply_markup
        });
      }
    } catch (ownerErr) {
      console.log("[NOTIF] Gagal kirim ke owner:", ownerErr.message);
    }

    console.log(`[NOTIF] Broadcast stok selesai. Sukses: ${successCount}, Gagal: ${failCount}`);

    // Laporan singkat ke owner
    try {
      await bot.telegram.sendMessage(
        config.ownerId,
        `<b>📢 LAPORAN BROADCAST STOK</b>\n\n` +
        `Produk: ${productName}\n` +
        `Stok masuk: ${addedCount}\n` +
        `Total user: ${users.length}\n` +
        `Terkirim: ${successCount}\n` +
        `Gagal: ${failCount}`,
        { parse_mode: "HTML" }
      );
    } catch (reportErr) {}

  } catch (error) {
    console.error("[ERROR] Gagal broadcast notifikasi stok ke semua user:", error.message);
  }
}
// ========== NOTIFIKASI SCRIPT BARU KE CHANNEL ==========
async function sendScriptNotificationToChannel(scriptIndex) {
  try {
    const db = readDb();
    const script = db.scripts[scriptIndex];
    if (!script) return;

    const scriptName = script.nama;
    const scriptPrice = script.harga;
    const photoUrl = config.stockNotificationPhoto || config.startPhoto;

    if (!config.stockChannelId) {
      console.log("[INFO] Channel notifikasi belum dikonfigurasi");
      return;
    }

    const channelId = config.stockChannelId.startsWith('@') ? config.stockChannelId : `@${config.stockChannelId}`;

    const caption = `
<b>🔥𝗦𝗖𝗥𝗜𝗣𝗧 𝗕𝗔𝗥𝗨 𝗧𝗘𝗟𝗔𝗛 𝗗𝗜𝗧𝗔𝗠𝗕𝗔𝗛𝗞𝗔𝗡 📢</b>

<b>📦 𝗡𝗔𝗠𝗔 :</b> ${scriptName}
<b>💰 𝗛𝗔𝗥𝗚𝗔 :</b> ${toRupiah(scriptPrice)}
<b>📝 𝗗𝗘𝗦𝗞𝗥𝗜𝗣𝗦𝗜 :</b> ${script.deskripsi || '-'}
 
Klik tombol di bawah untuk order! 🛒
`;

    const keyboard = Markup.inlineKeyboard([
      [Markup.button.url(`🛒 𝗢𝗥𝗗𝗘𝗥 𝗦𝗘𝗞𝗔𝗥𝗔𝗡𝗚`, `https://t.me/${bot.botInfo.username}?start=shop`)]
    ]);

    try {
      await bot.telegram.sendPhoto(channelId, photoUrl, {
        caption: caption,
        parse_mode: "HTML",
        reply_markup: keyboard.reply_markup
      });
      console.log(`[NOTIF] Script notification sent for ${scriptName} with photo`);
    } catch (photoError) {
      console.warn(`[WARNING] Gagal kirim foto, fallback ke teks: ${photoError.message}`);
      await bot.telegram.sendMessage(channelId, caption, {
        parse_mode: "HTML",
        reply_markup: keyboard.reply_markup
      });
      console.log(`[NOTIF] Script notification sent for ${scriptName} (text only)`);
    }

  } catch (error) {
    console.error("[ERROR] Gagal mengirim notifikasi script ke channel:", error.message);
  }
}

// ========== BROADCAST NOTIFIKASI SCRIPT BARU KE SEMUA USER ==========
async function sendScriptNotificationToAllUsers(scriptIndex) {
  try {
    const db = readDb();
    const script = db.scripts[scriptIndex];
    if (!script) return;

    const scriptName = script.nama;
    const scriptPrice = script.harga;
    const photoUrl = config.stockNotificationPhoto || config.startPhoto;

    const users = loadUsers();
    if (users.length === 0) {
      console.log("[NOTIF] Tidak ada user untuk dikirimi notifikasi script.");
      return;
    }

    const caption = `
<b>🔥 𝗦𝗖𝗥𝗜𝗣𝗧 𝗕𝗔𝗥𝗨 𝗧𝗘𝗟𝗔𝗛 𝗗𝗜𝗧𝗔𝗠𝗕𝗔𝗛𝗞𝗔𝗡 📢</b>

<b>📦 𝗡𝗔𝗠𝗔 :</b> ${scriptName}
<b>💰 𝗛𝗔𝗥𝗚𝗔 :</b> ${toRupiah(scriptPrice)}
<b>📝 𝗗𝗘𝗦𝗞𝗥𝗜𝗣𝗦𝗜 :</b> ${script.deskripsi || '-'}
 
Klik tombol di bawah untuk order! 🛒
`;

    const keyboard = Markup.inlineKeyboard([
      [Markup.button.url(`🛒 𝗢𝗥𝗗𝗘𝗥 𝗦𝗘𝗞𝗔𝗥𝗔𝗡𝗚`, `https://t.me/${bot.botInfo.username}?start=shop`)]
    ]);

    let successCount = 0;
    let failCount = 0;

    for (const userId of users) {
      try {
        if (photoUrl) {
          await bot.telegram.sendPhoto(userId, photoUrl, {
            caption: caption,
            parse_mode: "HTML",
            reply_markup: keyboard.reply_markup
          });
        } else {
          await bot.telegram.sendMessage(userId, caption, {
            parse_mode: "HTML",
            reply_markup: keyboard.reply_markup
          });
        }
        successCount++;
      } catch (err) {
        failCount++;
        console.log(`[NOTIF] Gagal kirim ke user ${userId}: ${err.message}`);
      }
      await new Promise(resolve => setTimeout(resolve, 50));
    }

    // Kirim juga ke owner
    try {
      if (photoUrl) {
        await bot.telegram.sendPhoto(config.ownerId, photoUrl, {
          caption: caption,
          parse_mode: "HTML",
          reply_markup: keyboard.reply_markup
        });
      } else {
        await bot.telegram.sendMessage(config.ownerId, caption, {
          parse_mode: "HTML",
          reply_markup: keyboard.reply_markup
        });
      }
    } catch (ownerErr) {
      console.log("[NOTIF] Gagal kirim ke owner:", ownerErr.message);
    }

    console.log(`[NOTIF] Broadcast script selesai. Sukses: ${successCount}, Gagal: ${failCount}`);

    // Laporan singkat ke owner
    try {
      await bot.telegram.sendMessage(
        config.ownerId,
        `<b>📢 LAPORAN BROADCAST SCRIPT BARU</b>\n\n` +
        `Nama: ${scriptName}\n` +
        `Harga: ${toRupiah(scriptPrice)}\n` +
        `Total user: ${users.length}\n` +
        `Terkirim: ${successCount}\n` +
        `Gagal: ${failCount}`,
        { parse_mode: "HTML" }
      );
    } catch (reportErr) {}

  } catch (error) {
    console.error("[ERROR] Gagal broadcast notifikasi script ke semua user:", error.message);
  }
}
// ========== NOTIFIKASI SCRIPT BARU KE CHANNEL ==========
async function sendScriptNotificationToChannel(scriptIndex) {
  try {
    const db = readDb();
    const script = db.scripts[scriptIndex];
    if (!script) return;

    const scriptName = script.nama;
    const scriptPrice = script.harga;
    const photoUrl = config.stockNotificationPhoto || config.startPhoto;

    if (!config.stockChannelId) {
      console.log("[INFO] Channel notifikasi belum dikonfigurasi");
      return;
    }

    const channelId = config.stockChannelId.startsWith('@') ? config.stockChannelId : `@${config.stockChannelId}`;

    const caption = `
<b>🔥𝗦𝗖𝗥𝗜𝗣𝗧 𝗕𝗔𝗥𝗨 𝗧𝗘𝗟𝗔𝗛 𝗗𝗜𝗧𝗔𝗠𝗕𝗔𝗛𝗞𝗔𝗡 📢</b>

<b>📦 𝗡𝗔𝗠𝗔 :</b> ${scriptName}
<b>💰 𝗛𝗔𝗥𝗚𝗔 :</b> ${toRupiah(scriptPrice)}
<b>📝 𝗗𝗘𝗦𝗞𝗥𝗜𝗣𝗦𝗜 :</b> ${script.deskripsi || '-'}
 
Klik tombol di bawah untuk order! 🛒
`;

    const keyboard = Markup.inlineKeyboard([
      [Markup.button.url(`🛒 𝗢𝗥𝗗𝗘𝗥 𝗦𝗘𝗞𝗔𝗥𝗔𝗡𝗚`, `https://t.me/${bot.botInfo.username}?start=shop`)]
    ]);

    // Kirim ke channel (prioritas dengan foto, fallback teks)
    try {
      await bot.telegram.sendPhoto(channelId, photoUrl, {
        caption: caption,
        parse_mode: "HTML",
        reply_markup: keyboard.reply_markup
      });
    } catch (photoError) {
      await bot.telegram.sendMessage(channelId, caption, {
        parse_mode: "HTML",
        reply_markup: keyboard.reply_markup
      });
    }
  } catch (error) {
    console.error("[ERROR] Gagal mengirim notifikasi script ke channel:", error.message);
  }
}

function formatUserCard(ctx, msg) {
  const username = ctx.from.username ? `@${ctx.from.username}` : '-';
  return `<b>📩 PESAN DARI USER</b>\n<b>Username :</b> ${username}\n<b>ID User  :</b> ${ctx.from.id}\n\n<b>Pesan:</b>\n${msg}`;
}

bot.on("document", async (ctx, next) => {
  const userId = ctx.from.id;
  const state = userState[userId];

  if (state?.step === "WAITING_SCRIPT_FILE" && userId === config.ownerId) {
    const doc = ctx.message.document;

    if (!doc.file_name.endsWith(".zip"))
      return safeReply(ctx, "<blockquote>❌ File harus format .zip!</blockquote>", { parse_mode: "HTML" });

    userState[userId] = {
      step: "WAITING_SCRIPT_DETAIL",
      file_id: doc.file_id,
      temp_fileName: doc.file_name.replace(/\s/g, "_"),
    };

    return safeReply(ctx, `<blockquote>✅ <b>File diterima!</b>\n<b>Kirim detail:</b>\nNama | Harga | Deskripsi</blockquote>`, { parse_mode: "HTML" });
  }

  return next();
});

bot.command("pesan", async (ctx) => {
  const raw = ctx.message.text || "";
  const msg = raw.replace(/^\/pesan(@\w+)?\s*/i, "").trim();

  if (!msg) {
    liveChatState[ctx.from.id] = { step: "WAITING_MESSAGE" };
    return safeReply(ctx, "📝 <b>𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗞𝗲𝘁𝗶𝗸 𝗣𝗲𝘀𝗮𝗻 𝗔𝗻𝗱𝗮 𝗨𝗻𝘁𝘂𝗸 𝗗𝗶𝗸𝗶𝗿𝗶𝗺 𝗞𝗲 𝗢𝘄𝗻𝗲𝗿 𝗕𝗼𝘁.</b>\n❌ 𝗞𝗲𝘁𝗶𝗸 /batal 𝗨𝗻𝘁𝘂𝗸 𝗠𝗲𝗺𝗯𝗮𝘁𝗮𝗹𝗸𝗮𝗻 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗣𝗲𝘀𝗮𝗻", { parse_mode: "HTML" });
  }

  return sendToOwner(ctx, msg);
});

bot.command("batal", (ctx) => {
  if (liveChatState[ctx.from.id]?.step === "WAITING_MESSAGE") {
    delete liveChatState[ctx.from.id];
    return safeReply(ctx, "❌ 𝗣𝗲𝗻𝗴𝗶𝗿𝗶𝗺𝗮𝗻 𝗣𝗲𝘀𝗮𝗻 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗗𝗶𝗯𝗮𝘁𝗮𝗹𝗸𝗮𝗻.");
  }
  if (ownerReplyState[ctx.from.id]) {
    delete ownerReplyState[ctx.from.id];
    return safeReply(ctx, "❌ 𝗠𝗼𝗱𝗲 𝗕𝗮𝗹𝗮𝘀𝗮𝗻 𝗢𝘄𝗻𝗲𝗿 𝗗𝗶𝗵𝗲𝗻𝘁𝗶𝗸𝗮𝗻.");
  }
  if (userState[ctx.from.id]?.step === "WAITING_BROADCAST" && ctx.from.id === config.ownerId) {
    delete userState[ctx.from.id];
    return safeReply(ctx, "❌ 𝗕𝗿𝗼𝗮𝗱𝗰𝗮𝘀𝘁 𝗗𝗶𝗯𝗮𝘁𝗮𝗹𝗸𝗮𝗻.");
  }
  return; 
});

bot.on("text", async (ctx, next) => {
  try {
    const st = liveChatState[ctx.from.id];
    if (st && st.step === "WAITING_MESSAGE") {
      const text = ctx.message.text;
      delete liveChatState[ctx.from.id];
      return await sendToOwner(ctx, text);
    }
  } catch (e) {}
  return next();
});

async function sendToOwner(ctx, messageText) {
  try {
    const owner = config.ownerId;
    const layout = formatUserCard(ctx, messageText);
    await bot.telegram.sendMessage(owner, layout, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "📨 𝗕𝗮𝗹𝗮𝘀 𝗣𝗲𝘀𝗮𝗻 𝗨𝘀𝗲𝗿", callback_data: `reply_${ctx.from.id}` }]
        ]
      }
    });
    await safeReply(ctx, "✅ <b>𝗣𝗲𝘀𝗮𝗻 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗗𝗶𝗸𝗶𝗿𝗶𝗺𝗸𝗮𝗻 𝗞𝗲𝗽𝗮𝗱𝗮 𝗢𝘄𝗻𝗲𝗿 𝗕𝗼𝘁.</b>", { parse_mode: "HTML" });
  } catch (err) {
    return safeReply(ctx, "❌ 𝗣𝗲𝗻𝗴𝗶𝗿𝗶𝗺𝗮𝗻 𝗣𝗲𝘀𝗮𝗻 𝗚𝗮𝗴𝗮𝗹, 𝗧𝗲𝗿𝗷𝗮𝗱𝗶 𝗘𝗿𝗿𝗼𝗿 𝗦𝗶𝘀𝘁𝗲𝗺.");
  }
}

bot.action(/reply_(\d+)/, async (ctx) => {
  try {
    if (String(ctx.from.id) !== String(config.ownerId)) {
      await ctx.answerCbQuery("❌ 𝗛𝗮𝗻𝘆𝗮 𝗢𝘄𝗻𝗲𝗿 𝗦𝗮𝗷𝗮 𝗬𝗮𝗻𝗴 𝗕𝗶𝘀𝗮 𝗠𝗲𝗺𝗯𝗮𝗹𝗮𝘀 𝗣𝗲𝘀𝗮𝗻 𝗨𝘀𝗲𝗿.", { show_alert: true });
      return;
    }
    const targetId = ctx.match[1];
    ownerReplyState[ctx.from.id] = { target: targetId, step: "WAITING_REPLY" };
    await ctx.answerCbQuery();
    await safeReply(ctx, "✉️ <b>𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗞𝗶𝗿𝗶𝗺 𝗕𝗮𝗹𝗮𝘀𝗮𝗻 𝗔𝗻𝗱𝗮 𝗦𝗲𝗸𝗮𝗿𝗮𝗻𝗴!</b>\n━━━━━━━━━━━━━━━━━━━━❍\n<b>🌸 𝗝𝗲𝗻𝗶𝘀 𝗕𝗮𝗹𝗮𝘀𝗮𝗻 𝗕𝗶𝘀𝗮 𝗕𝗲𝗿𝘂𝗽𝗮 :</b>\n<b>➥ 𝗧𝗲𝗸𝘀 | 𝗙𝗼𝘁𝗼 | 𝗩𝗶𝗱𝗲𝗼 | 𝗙𝗶𝗹𝗲</b>\n<b>➥ 𝗞𝗲𝘁𝗶𝗸 /batal 𝗨𝗻𝘁𝘂𝗸 𝗠𝗲𝗺𝗯𝗮𝘁𝗮𝗹𝗸𝗮𝗻.</b>", { parse_mode: "HTML" });
  } catch (e) {}
});

// Fungsi untuk menampilkan panduan order nokos
async function showNokosGuide(ctx) {
  const guideText = `
📚 𝗣𝗔𝗡𝗗𝗨𝗔𝗡 𝗟𝗘𝗡𝗚𝗞𝗔𝗣 𝗢𝗥𝗗𝗘𝗥 𝗡𝗢𝗞𝗢𝗦
━━━━━━━━━━━━━━━━━━━━━⨳

𝗧𝗔𝗛𝗔𝗣 𝟭: 𝗗𝗘𝗣𝗢𝗦𝗜𝗧 𝗦𝗔𝗟𝗗𝗢
1. Klik menu "💰 Deposit"
2. Masukkan nominal minimal Rp 2.000
3. Scan QRIS yang muncul
4. Bayar sesuai nominal TOTAL
5. Saldo otomatis masuk dalam 2 menit

𝗧𝗔𝗛𝗔𝗣 𝟮: 𝗣𝗜𝗟𝗜𝗛 𝗟𝗔𝗬𝗔𝗡𝗔𝗡
1. Klik "📱 Order Nokos (Virtual)"
2. Pilih aplikasi yang diinginkan
3. Pilih negara yang tersedia
4. Pilih provider dengan stok tersedia

𝗧𝗔𝗛𝗔𝗣 𝟯: 𝗣𝗥𝗢𝗦𝗘𝗦 𝗢𝗥𝗗𝗘𝗥
1. Klik "✅ Konfirmasi Order"
2. Sistem akan mencari nomor aktif
3. Jika berhasil, nomor akan muncul
4. Saldo otomatis terpotong

⚠️ 𝗣𝗘𝗡𝗧𝗜𝗡𝗚:
• TUNGGU 2-3 MENIT sebelum cek SMS
• Jangan spam tombol "📩 Cek SMS"
• Sistem butuh waktu menerima SMS
• Jika timeout 5 menit, saldo dikembalikan

🎯 𝗧𝗜𝗣𝗦 𝗦𝗨𝗞𝗦𝗘𝗦:
1. Pilih provider dengan stok banyak
2. Gunakan operator "Random" untuk peluang lebih tinggi
3. Pastikan saldo mencukupi
4. Sabar menunggu SMS masuk

━━━━━━━━━━━━━━━━━━━━━⨳
𝗡𝗲𝗲𝗱 𝗵𝗲𝗹𝗽? 𝗞𝗲𝘁𝗶𝗸 /𝗽𝗲𝘀𝗮𝗻 𝘂𝗻𝘁𝘂𝗸 𝗵𝘂𝗯𝘂𝗻𝗴𝗶 𝗼𝘄𝗻𝗲𝗿`;

  await ctx.reply(guideText, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "📱 𝙋𝙞𝙡𝙞𝙝 𝘼𝙥𝙡𝙞𝙠𝙖𝙨𝙞", callback_data: "choose_service" }],
        [{ text: "💰 𝘿𝙚𝙥𝙤𝙨𝙞𝙩 𝙎𝙖𝙡𝙙𝙤", callback_data: "topup_nokos" }],
        [{ text: "📋 𝘾𝙚𝙠 𝙎𝙖𝙡𝙙𝙤", callback_data: "cek_saldo_user" }],
        [{ text: "🔙 𝙆𝙚𝙢𝙗𝙖𝙡𝙞", callback_data: "back_home" }]
      ]
    }
  });
}

// Fungsi untuk menampilkan panduan deposit
async function showDepositGuide(ctx) {
  const guideText = `
💰 𝗣𝗔𝗡𝗗𝗨𝗔𝗡 𝗗𝗘𝗣𝗢𝗦𝗜𝗧 𝗦𝗔𝗟𝗗𝗢
━━━━━━━━━━━━━━━━━━━━━⨳

𝗧𝗔𝗛𝗔𝗣 𝗣𝗘𝗥𝗧𝗔𝗠𝗔: 𝗠𝗘𝗠𝗨𝗟𝗔𝗜 𝗗𝗘𝗣𝗢𝗦𝗜𝗧
1. Klik menu "💰 Deposit" di menu utama
2. Masukkan nominal yang ingin di deposit
3. Minimal deposit: Rp 2.000
4. Contoh: 2000 (untuk deposit Rp 2.000)

𝗧𝗔𝗛𝗔𝗣 𝗞𝗘𝗗𝗨𝗔: 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡
1. Bot akan membuat QRIS pembayaran
2. Scan QR dengan aplikasi e-wallet/bank
3. Bayar SESUAI nominal yang tertera
4. Jangan bayar kurang/lebih dari nominal

𝗧𝗔𝗛𝗔𝗣 𝗞𝗘𝗧𝗜𝗚𝗔: 𝗞𝗢𝗡𝗙𝗜𝗥𝗠𝗔𝗦𝗜
1. Sistem otomatis cek pembayaran
2. Jika berhasil, saldo langsung masuk
3. Notifikasi akan dikirim ke Anda
4. Bisa langsung digunakan untuk order

⚠️ 𝗣𝗘𝗥𝗛𝗔𝗧𝗜𝗔𝗡:
• QRIS berlaku 10 menit
• Bayar sesuai nominal sampai digit terakhir
• Jangan bayar ke QRIS yang expired
• Jika gagal, buat ulang deposit

🎯 𝗧𝗜𝗣𝗦 𝗖𝗘𝗣𝗔𝗧:
1. Gunakan e-wallet yang sudah verifikasi
2. Pastikan saldo e-wallet mencukupi
3. Screenshot bukti bayar jika perlu
4. Hubungi owner jika ada masalah

━━━━━━━━━━━━━━━━━━━━━⨳
𝗦𝗮𝗹𝗱𝗼 𝗺𝘂𝗹𝘂𝘀? 𝗞𝗹𝗶𝗸 𝗯𝘂𝘁𝘁𝗼𝗻 𝗱𝗶𝗯𝗮𝘄𝗮𝗵`;

  await ctx.reply(guideText, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "💰 𝘿𝙚𝙥𝙤𝙨𝙞𝙩 𝙎𝙚𝙠𝙖𝙧𝙖𝙣𝙜", callback_data: "topup_nokos" }],
        [{ text: "📋 𝘾𝙚𝙠 𝙎𝙖𝙡𝙙𝙤", callback_data: "cek_saldo_user" }],
        [{ text: "📱 𝙊𝙧𝙙𝙚𝙧 𝙉𝙤𝙠𝙤𝙨", callback_data: "nokos_guide" }],
        [{ text: "🔙 𝙆𝙚𝙢𝙗𝙖𝙡𝙞", callback_data: "back_home" }]
      ]
    }
  });
}

// Fungsi untuk panduan lengkap
async function showFullGuide(ctx) {
  const guideText = `
📖 𝗣𝗔𝗡𝗗𝗨𝗔𝗡 𝗟𝗘𝗡𝗚𝗞𝗔𝗣 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔𝗔𝗡 𝗕𝗢𝗧
━━━━━━━━━━━━━━━━━━━━━━━━━⨳

𝗕𝗔𝗚𝗜𝗔𝗡 𝟭: 𝗗𝗘𝗣𝗢𝗦𝗜𝗧 𝗦𝗔𝗟𝗗𝗢
💰 <b>Cara Deposit:</b>
1. Klik "💰 Deposit" di menu
2. Masukkan nominal (min Rp 2.000)
3. Scan QRIS yang muncul
4. Bayar sesuai nominal
5. Tunggu 2-3 menit, saldo otomatis masuk

𝗕𝗔𝗚𝗜𝗔𝗡 𝟮: 𝗢𝗥𝗗𝗘𝗥 𝗡𝗢𝗞𝗢𝗦
📱 <b>Step-by-step:</b>
1. Deposit saldo terlebih dahulu
2. Pilih aplikasi yang diinginkan
3. Pilih negara & provider
4. Klik konfirmasi order
5. <b>TUNGGU 2-3 MENIT</b> sebelum cek SMS
6. Klik "📩 Cek SMS" setelah menunggu

⚠️ <b>Catatan Penting:</b>
• Jangan spam cek SMS
• Sistem butuh waktu menerima SMS
• Jika timeout 5 menit, saldo dikembalikan
• Pilih provider dengan stok banyak

𝗕𝗔𝗚𝗜𝗔𝗡  𝟯: 𝗣𝗥𝗢𝗗𝗨𝗞 𝗟𝗔𝗜𝗡𝗡𝗬𝗔
🖥 <b>VPS DigitalOcean:</b>
• Proses ±60 detik
• Detail VPS dikirim otomatis
• Garansi sesuai paket

📡 <b>Panel Pterodactyl:</b>
• Akun dibuat otomatis
• Login info dikirim
• Support root/admin

━━━━━━━━━━━━━━━━━━━━━━━━━⨳
📞 <b>𝗞𝗢𝗡𝗧𝗔𝗞 𝗕𝗔𝗡𝗧𝗨𝗔𝗡:</b>
• Gunakan /pesan untuk hubungi owner
• Screenshoot error jika ada masalah
• Jangan lupa baca panduan dengan seksama

⏰ <b>𝗪𝗔𝗞𝗧𝗨 𝗥𝗘𝗦𝗣𝗢𝗡:</b>
• Deposit: 2-3 menit
• Order: 2-5 menit
• Support: 1-12 jam`;

  await ctx.reply(guideText, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "💰 𝘿𝙚𝙥𝙤𝙨𝙞𝙩", callback_data: "deposit_guide" },
          { text: "📱 𝙉𝙤𝙠𝙤𝙨", callback_data: "nokos_guide" }
        ],
        [
          { text: "🖥 𝙑𝙋𝙎", callback_data: "buyvps_start" }
        ],
        [
          { text: "📡 𝙋𝙖𝙣𝙚𝙡", callback_data: "menu_panel" },
          { text: "📁 𝙎𝙘𝙧𝙞𝙥𝙩", callback_data: "menu_scripts" }
        ],
        [
          { text: "🔙 𝙆𝙚𝙢𝙗𝙖𝙡𝙞", callback_data: "shop_menu" }
        ]
      ]
    }
  });
}

// Tambahkan action handler untuk panduan lengkap
bot.action("full_guide", async (ctx) => {
  await showFullGuide(ctx);
});

// Tambahkan action handler untuk panduan deposit
bot.action("deposit_guide", async (ctx) => {
  await showDepositGuide(ctx);
});

// Tambahkan action handler untuk panduan nokos
bot.action("nokos_guide", async (ctx) => {
  await showNokosGuide(ctx);
});

async function forwardReplyToUser(ownerCtx, targetUserId, messageType, payload) {
  try {
    if (messageType === "text") {
      await bot.telegram.sendMessage(targetUserId, `💬 <b>𝗕𝗮𝗹𝗮𝘀𝗮𝗻 𝗗𝗮𝗿𝗶 𝗢𝘄𝗻𝗲𝗿:</b>\n\n${payload}`, { parse_mode: "HTML" });
      await ownerCtx.reply("✅ 𝗕𝗮𝗹𝗮𝘀𝗮𝗻 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗧𝗲𝗿𝗸𝗶𝗿𝗶𝗺 𝗦𝗲𝗯𝗮𝗴𝗮𝗶 𝗧𝗲𝗸𝘀.");
      return;
    }
  } catch (e) {
    await ownerCtx.reply("❌ 𝗚𝗮𝗴𝗮𝗹 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝗮𝗹𝗮𝘀𝗮𝗻 𝗞𝗲 𝗨𝘀𝗲𝗿.");
  }
}

bot.on("text", async (ctx, next) => {
  try {
    const st = ownerReplyState[ctx.from.id];
    if (st && st.step === "WAITING_REPLY") {
      const target = st.target;
      const text = ctx.message.text;
      delete ownerReplyState[ctx.from.id];
      await forwardReplyToUser(ctx, target, "text", text);
      return;
    }
  } catch (e) {}
  return next();
});

function getFileExtension(name) {
    const ext = name.split(".").pop().toLowerCase();
    if (["js"].includes(ext)) return "javascript";
    if (["py"].includes(ext)) return "python";
    if (["html","htm"].includes(ext)) return "html";
    if (["css"].includes(ext)) return "css";
    if (["json"].includes(ext)) return "json";
    if (["zip","rar","7z","tar","gz"].includes(ext)) return "archive";
    return "text";
}

async function downloadFile(fileId) {
    try {
        const fileLink = await bot.telegram.getFileLink(fileId);
        const res = await axios.get(fileLink, { responseType: "arraybuffer" });
        return res.data;
    } catch (err) {
        throw new Error("Gagal download file: " + err.message);
    }
}

function getFileContent(buffer) {
    try {
        return Buffer.from(buffer).toString("utf8");
    } catch (err) {
        throw new Error("Gagal membaca file: " + err.message);
    }
}

async function analyzeErrorWithGemini(codeContent, fileName) {
    try {
        if (getFileExtension(fileName) === "archive") {
            return "❌ <b>File adalah arsip (zip/rar), bukan file kode.</b>\nSilakan ekstrak dulu dan kirim file kode individual (js, py, html, css, json).";
        }
        
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent?key=${config.GEMINI_API_KEY}`,
            {
                contents: [{
                    parts: [{
                        text: `Deteksi error pada file bernama ${fileName}. Berikan hasilnya dalam format:

\`\`\`${getFileExtension(fileName)}
(kode atau analisis singkat di sini)
\`\`\`

JANGAN beri penjelasan panjang. Singkat & jelas saja.

Isi file:
${codeContent}
`
                    }]
                }]
            }
        );
        return res.data.candidates[0].content.parts[0].text;
    } catch (err) {
        throw new Error("Gemini error: " + err.message);
    }
}

async function fixErrorWithGemini(codeContent, fileName) {
    try {
        if (getFileExtension(fileName) === "archive") {
            throw new Error("File adalah arsip (zip/rar), bukan file kode. Silakan ekstrak dulu.");
        }
        
        const res = await axios.post(
            `https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent?key=${config.GEMINI_API_KEY}`,
            {
                contents: [{
                    parts: [{
                        text: `Perbaiki error dalam file ${fileName} dan kirimkan hanya kode final:\n\n${codeContent}`
                    }]
                }]
            }
        );
        return res.data.candidates[0].content.parts[0].text;
    } catch (err) {
        throw new Error("Gemini error: " + err.message);
    }
}

const premiumUsers = new Set([config.ownerId]);
let userLimits = new Map();

function updateUserLimit(userId) {
    if (premiumUsers.has(userId)) return 999;
    const now = userLimits.get(userId) || config.USER_LIMIT;
    const sisa = now - 1;
    userLimits.set(userId, sisa);
    return sisa;
}

function getUserLimit(userId) {
    return premiumUsers.has(userId) ? "Unlimited" : (userLimits.get(userId) || config.USER_LIMIT);
}

function loadUsers() {
  if (!fs.existsSync(USERS_DB)) {
    fs.writeFileSync(USERS_DB, JSON.stringify([]));
  }
  return JSON.parse(fs.readFileSync(USERS_DB));
}

function saveUsers(list) {
  fs.writeFileSync(USERS_DB, JSON.stringify(list, null, 2));
}

function checkAndAddUser(user) {
  const users = loadUsers()
  const isNewUser = !users.includes(user.id)
  
  if (isNewUser) {
    users.push(user.id)
    saveUsers(users)
    
    notifyOwnerNewUser(user)
    
    return true
  }
  return false
}

bot.on("message", (ctx, next) => {
  try {
    checkAndAddUser(ctx.from);
  } catch (e) {
    console.error("[ERROR] Error adding user:", e);
  }
  return next();
});

function readDb() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({
      isPanelOpen: true,
      scripts: [],
      apps: [],
      paymentMethod: config.payment?.method || 'orkut'
    }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDb(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function getActivePaymentMethod() {
  const db = readDb();
  return (db && db.paymentMethod) ? db.paymentMethod : (config.payment?.method || 'orkut');
}
function setActivePaymentMethod(method) {
  const db = readDb();
  db.paymentMethod = method;
  saveDb(db);
}

function readSaldo() {
    const path = "./database/saldoOtp.json";
    if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));
    try {
        return JSON.parse(fs.readFileSync(path, "utf8"));
    } catch (e) { return {}; }
}

function saveSaldo(data) {
    fs.writeFileSync("./database/saldoOtp.json", JSON.stringify(data, null, 2));
}

async function createAdminAccount(username) {
  try {
    const headers = {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": `Bearer ${config.panel.apikey}`
    };
    
    const password = username + "001";
    const email = `${username.toLowerCase()}@admin.com`;

    const userRes = await axios.post(`${config.panel.domain}/api/application/users`, {
      email: email,
      username: username.toLowerCase(),
      first_name: username,
      last_name: "Admin",
      language: "en",
      password: password,
      root_admin: true
    }, { headers });

    const user = userRes.data.attributes;

    return { 
        success: true, 
        data: { 
            id: user.id,
            username: user.username, 
            password: password, 
            email: user.email,
            login: config.panel.domain 
        } 
    };
  } catch (error) {
    console.error("Create Admin Error:", error.response?.data || error.message);
    return { success: false, msg: error.response?.data?.errors?.[0]?.detail || error.message };
  }
}

async function createPanelAccount(username, ram, disk, cpu) {
  try {
    const headers = {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": `Bearer ${config.panel.apikey}`
    };
    const password = username + "001";
    const email = `${username.toLowerCase()}@gmail.com`;

    const userRes = await axios.post(`${config.panel.domain}/api/application/users`, {
      email, username: username.toLowerCase(), first_name: username, last_name: "User", language: "en", password
    }, { headers });

    const user = userRes.data.attributes;

    await axios.post(`${config.panel.domain}/api/application/servers`, {
      name: `${username} Server`,
      user: user.id,
      egg: config.panel.eggId,
      docker_image: config.panel.image,
      startup: config.panel.startup,
      environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
      limits: { memory: ram, swap: 0, disk: disk, io: 500, cpu: cpu },
      feature_limits: { databases: 1, backups: 1, allocations: 1 },
      deploy: { locations: [config.panel.locationId], dedicated_ip: false, port_range: [] }
    }, { headers });

    return { success: true, data: { username: user.username, password, login: config.panel.domain } };
  } catch (error) {
    return { success: false, msg: error.response?.data?.errors?.[0]?.detail || error.message };
  }
}

bot.start(async (ctx) => {
  const userId = ctx.from.id;
  
  // Skip check untuk owner
  if (String(userId) === String(config.ownerId)) {
    console.log("[DEBUG] Owner detected, skipping channel check");
    // Lanjutkan ke start normal
    return proceedToStartMenu(ctx);
  }
  
  // Cek membership channel
  const isMember = await checkChannelMembership(userId);
  
  if (!isMember) {
    const channelLink = `https://t.me/${config.channelName || config.channelId?.replace('@', '')}`;
    
    return ctx.reply(
      `🚫 <b>Akses Ditolak!</b>\n\n` +
      `Kamu harus bergabung ke channel resmi terlebih dahulu untuk menggunakan bot ini.\n\n` +
      `🔗 <a href="${channelLink}">Join Channel</a>\n\n` +
      `Setelah bergabung, tekan tombol di bawah ini.`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "✅ Saya Sudah Join", callback_data: "verify_join" }],
            [{ text: "🔗 Join Channel Sekarang", url: channelLink }]
          ]
        },
        disable_web_page_preview: true
      }
    );
  }
  
  // Jika sudah join, lanjutkan ke menu
  return proceedToStartMenu(ctx);
});

// Fungsi untuk menampilkan menu start
async function proceedToStartMenu(ctx) {
  const stats = getBotStats();
  
  checkAndAddUser(ctx.from);
  
  const welcomeText = `
   𝗪𝗲𝗹𝗰𝗼𝗺𝗲 ${ctx.from.first_name || 'User'}!  
   𝘚𝘦𝘭𝘢𝘮𝘢𝘵 𝘥𝘢𝘵𝘢𝘯𝘨 𝘥𝘪 ${stats.botName}     
═══════════════════════════════
📊 <b>𝗕𝗢𝗧 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡</b>
├─ 🏷️ <b>Owner :</b> ${stats.ownerName}
├─ 🤖 <b>Bot Name :</b> ${stats.botName}
├─ 🔥 <b>Version :</b> 8.0.0 Premium
├─ ⚡ <b>Prefix :</b> / (Slash)

📈 <b>𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗞 𝗦𝗜𝗦𝗧𝗘𝗠</b>
├─ 👥 <b>Total Users :</b> ${stats.totalUsers}
├─ ⏱️ <b>Runtime :</b> ${stats.runtime}
└─ 🆙 <b>Status :</b> <code>ONLINE</code>
`;
  const menuKeyboard = {
  inline_keyboard: [
    // Baris 1: MENU LAYANAN (full width - header)
    [
      { text: "🛍 𝗠𝗘𝗡𝗨 𝗟𝗔𝗬𝗔𝗡𝗔𝗡", callback_data: "shop_menu" }
    ],
    // Baris 2: CARA PENGGUNAAN & DEPOSIT (2 kolom)
    [
      { text: "📜 𝗣𝗔𝗡𝗗𝗨𝗔𝗡", callback_data: "full_guide" },
      { text: "💰 𝗗𝗘𝗣𝗢𝗦𝗜𝗧", callback_data: "topup_nokos" }
    ],
    // Baris 3: OWNER & TOOLS (2 kolom)
    [
      { text: "👑 𝗢𝗪𝗡𝗘𝗥", callback_data: "menu_owner_contact" },
      { text: "🛠️ 𝗧𝗢𝗢𝗟𝗦", callback_data: "menu_tools" }
    ],
    // Baris 4: CHANNEL (2 kolom) - Sekarang CHANNEL jadi 2 kolom dengan satu dummy
    [
      { text: "📢 𝗖𝗛𝗔𝗡𝗡𝗘𝗟", url: `https://t.me/${config.channelName}` },
    ]
  ]
};

  if (config.startPhoto && config.startPhoto.trim() !== "" && config.startPhoto !== "-") {
    try {
      await ctx.replyWithPhoto(config.startPhoto, {
        caption: welcomeText,
        parse_mode: "HTML",
        reply_markup: menuKeyboard
      });
    } catch (e) {
      await safeReply(ctx, welcomeText, {
        parse_mode: "HTML",
        reply_markup: menuKeyboard
      });
    }
  } else {
    await safeReply(ctx, welcomeText, {
      parse_mode: "HTML",
      reply_markup: menuKeyboard
    });
  }

  if (String(ctx.from.id) === String(config.ownerId)) {
    try {
      await safeReply(ctx, `✅ <b>Welcome Back Owner!</b>\n👑 <b>${stats.ownerName}</b>\n\n📊 <b>Bot Status:</b> ONLINE\n👥 <b>Users:</b> ${stats.totalUsers}\n⏱️ <b>Uptime:</b> ${stats.runtime}`, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "👑 𝗠𝗘𝗡𝗨 𝗢𝗪𝗡𝗘𝗥", callback_data: "menu_owner" }],
            [{ text: "🔙 𝗠𝗘𝗡𝗨 𝗨𝗧𝗔𝗠𝗔", callback_data: "back_home" }]
          ]
        }
      });
    } catch (ownerError) {}
  }
}

// Action untuk verifikasi join channel
bot.action("verify_join", async (ctx) => {
  await ctx.answerCbQuery("⏳ Memverifikasi...", { show_alert: false });
  
  const userId = ctx.from.id;
  const isMember = await checkChannelMembership(userId);
  
  if (!isMember) {
    const channelLink = `https://t.me/${config.channelName || config.channelId?.replace('@', '')}`;
    
    return ctx.editMessageText(
      `❌ <b>Kamu belum join channel!</b>\n\n` +
      `Kami tidak mendeteksi kamu di channel kami.\n\n` +
      `Pastikan kamu sudah:\n` +
      `1. Klik link di bawah\n` +
      `2. Join channel\n` +
      `3. Kembali ke bot\n\n` +
      `🔗 <a href="${channelLink}">Join Channel Sekarang</a>`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🔄 Coba Lagi", callback_data: "verify_join" }],
            [{ text: "🔗 Join Channel", url: channelLink }]
          ]
        },
        disable_web_page_preview: true
      }
    );
  }
  
  // Jika sudah join
  await ctx.editMessageText(
    `✅ <b>Verifikasi Berhasil!</b>\n\n` +
    `Selamat datang di ${config.botName || 'Bot'}!\n` +
    `Sekarang kamu bisa menggunakan semua fitur bot.`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🚀 Mulai Menggunakan Bot", callback_data: "verified_start" }]
        ]
      }
    }
  );
});

// Action setelah verifikasi berhasil
bot.action("verified_start", async (ctx) => {
  try {
    await ctx.deleteMessage();
  } catch (e) {}
  
  // Simulasikan /start
  const fakeMessage = {
    text: "/start",
    from: ctx.from,
    chat: ctx.chat
  };
  
  await bot.handleUpdate({
    message: fakeMessage,
    update_id: Date.now()
  });
});

bot.action("menu_scripts", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'menu_scripts')) return;
  
  const db = readDb();
  if ((db.scripts || []).length === 0) {
    await editMenuMessage(ctx, "🚫 <b>𝗠𝗼𝗵𝗼𝗻 𝗠𝗮𝗮𝗳, 𝗕𝗲𝗹𝘂𝗺 𝗔𝗱𝗮 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗬𝗮𝗻𝗴 𝗗𝗶𝗷𝘂𝗮𝗹 𝗢𝗹𝗲𝗵 𝗢𝘄𝗻𝗲𝗿 𝗕𝗼𝘁.</b>", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "back_home" }]
        ]
      }
    });
    return;
  }
  
  const buttons = db.scripts.map((item, index) => {
    return [{ text: `${item.nama} - ${toRupiah(item.harga)}`, callback_data: `buy_sc_${index}` }];
  });
  
  buttons.push([{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "back_home" }]);
  
  await editMenuMessage(ctx, "<b>📂 𝗣𝗶𝗹𝗶𝗵 𝗦𝗰𝗿𝗶𝗽𝘁 𝗗𝗶𝗯𝗮𝘄𝗮𝗵 𝗬𝗮𝗻𝗴 𝗜𝗻𝗴𝗶𝗻 𝗞𝗮𝗺𝘂 𝗕𝗲𝗹𝗶 :</b>", {
    reply_markup: { inline_keyboard: buttons }
  });
});

bot.action("menu_apps", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'menu_apps')) return;
  
  const db = readDb();
  if ((db.apps || []).length === 0) {
    await editMenuMessage(ctx, "🚫 <b>𝗠𝗼𝗵𝗼𝗻 𝗠𝗮𝗮𝗳, 𝗯𝗹𝗺 𝗱𝗶 𝘀𝘁𝗼𝗸 𝗢𝘄𝗻𝗲𝗿.</b>", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "back_home" }]
        ]
      }
    });
    return;
  }
  
  const buttons = db.apps.map((app, i) => {
    const stock = (app.accounts || []).length;
    return [{ text: `${app.nama} (${stock} stok) - ${toRupiah(app.harga)}`, callback_data: `buy_app_${i}` }];
  });
  
  buttons.push([{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "back_home" }]);
  
  await editMenuMessage(ctx, "<b>🌐 daftar digital ocean:</b>", {
    reply_markup: { inline_keyboard: buttons }
  });
});

bot.action("menu_panel", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'menu_panel')) return;
  
  const db = readDb();
  if (!db.isPanelOpen) {
    await editMenuMessage(ctx, "<b>🚫 𝗠𝗼𝗵𝗼𝗻 𝗠𝗮𝗮𝗳, 𝗦𝘁𝗼𝗸 𝗣𝗮𝗻𝗲𝗹 𝗕𝗲𝗹𝘂𝗺 𝗧𝗲𝗿𝘀𝗲𝗱𝗶𝗮 𝗨𝗻𝘁𝘂𝗸 𝗦𝗮𝗮𝘁 𝗜𝗻𝗶. 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗖𝗼𝗯𝗮 𝗟𝗮𝗴𝗶 𝗡𝗮𝗻𝘁𝗶</b>.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "back_home" }]
        ]
      }
    });
    return;
  }

  userState[ctx.from.id] = { step: "WAITING_USERNAME_PANEL" };

  await editMenuMessage(ctx,
    "<b>🍂 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗞𝗶𝗿𝗶𝗺 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 𝗨𝗻𝘁𝘂𝗸 𝗣𝗮𝗻𝗲𝗹 𝗬𝗮𝗻𝗴 𝗜𝗻𝗴𝗶𝗻 𝗞𝗮𝗺𝘂 𝗕𝗲𝗹𝗶 𝗗𝗲𝗻𝗴𝗮𝗻 𝗠𝗶𝗻𝗶𝗺𝗮𝗹 𝟱-𝟴 𝗛𝘂𝗿𝘂𝗳.</b>\n",
    {
      reply_markup: {
        inline_keyboard: [
          [{ text: "❌ 𝗕𝗮𝘁𝗮𝗹 𝗠𝗲𝗺𝗯𝗲𝗹𝗶 𝗣𝗮𝗻𝗲𝗹", callback_data: "back_home" }]
        ]
      }
    }
  );

  setTimeout(() => {
    const st = userState[ctx.from.id];
    if (st && st.step === "WAITING_USERNAME_PANEL") {
      delete userState[ctx.from.id];
      safeReply(ctx, "❌ <b>𝗪𝗮𝗸𝘁𝘂 𝗦𝘂𝗱𝗮𝗵 𝗛𝗮𝗯𝗶𝘀!</b>\n🚀 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗖𝗼𝗯𝗮 𝗕𝘂𝘆 𝗣𝗮𝗻𝗲𝗹 𝗟𝗮𝗴𝗶.", { parse_mode: "HTML" });
    }
  }, 60000);
});

bot.action("panel_guide", async (ctx) => {
  await ctx.replyWithPhoto(
    config.panel?.menuPhoto || config.startPhoto,
    {
      caption: `
<b>📚 PANDUAN ORDER PANEL</b>
━━━━━━━━━━━━━━━━━━━━━

<b>🎯 TAHAPAN ORDER:</b>

<b>1️⃣ PILIH PAKET</b>
- Pilih paket sesuai kebutuhan
- Perhatikan spesifikasi RAM, Disk, CPU
- Pilih yang sesuai dengan budget

<b>2️⃣ BUAT USERNAME</b>
- Masukkan username unik
- Minimal 5 karakter
- Hanya huruf dan angka
- Tidak boleh spasi/khusus

<b>3️⃣ BAYAR & AKTIVASI</b>
- Bayar via QRIS/Transfer
- Tunggu 2-5 menit proses
- Panel otomatis aktif
- Detail login dikirim

<b>4️⃣ LOGIN & KONFIGURASI</b>
- Login di domain yang tersedia
- Buat server baru
- Upload aplikasi/bot
- Start server

<b>⚡ TIPS & TRIK:</b>
• Gunakan username yang mudah diingat
• Simpan detail login dengan aman
• Backup data secara berkala
• Monitor resource usage
• Hubungi support jika ada masalah

<b>📞 SUPPORT:</b>
• Telegram: @dekzymarket
• WhatsApp: https://wa.me/6281927989701

━━━━━━━━━━━━━━━━━━━━━
<i>Selamat menggunakan panel!</i>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "📡 Order Panel Sekarang", callback_data: "menu_panel" }],
          [{ text: "🔙 Kembali ke Menu", callback_data: "shop_menu" }]
        ]
      }
    }
  );
});
// ACTION UNTUK MENU LAYANAN (SHOP MENU)
bot.action("shop_menu", async (ctx) => {
  try {
    const stats = getBotStats();
    
    // Cek dan tambah user
    if (typeof checkAndAddUser === 'function') {
      checkAndAddUser(ctx.from);
    }
    
    const shopText = `
𝗟𝗔𝗬𝗔𝗡𝗔𝗡 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗕𝗢𝗧     
  𝗦𝗲𝗺𝘂𝗮 𝗸𝗲𝗯𝘂𝘁𝘂𝗵𝗮𝗻 𝗱𝗶 𝗼𝗻𝗲 𝗯𝗼𝘁!!
══════════════════════════════
<b>⚡ 𝗞𝗘𝗨𝗡𝗧𝗨𝗡𝗚𝗔𝗡 :</b>
• ⏱️ Proses INSTANT (2-5 menit)
• 🔒 Payment MULTI metode
• 🛡️ Garansi semua produk
• 📞 Support 24/7 aktif
• 🔄 Auto backup data

<b>🎯 𝗦𝗧𝗔𝗧𝗨𝗦 𝗦𝗜𝗦𝗧𝗘𝗠 :</b>
├─ 🟢 All Services ONLINE
├─ ⚡ Processing: FAST
├─ 💰 Payment: ACTIVE
└─ 👤 Support: AVAILABLE

<code>══════════════════════════════</code>
<i>Pilih kategori layanan di bawah:</i>`;

    const shopKeyboard = {
      inline_keyboard: [
        // Baris 1: Layanan Unggulan (2 kolom)
        [
          { text: "📱 𝗡𝗢𝗞𝗢𝗦 𝗢𝗧𝗣", callback_data: "choose_service" },
          { text: "💰 𝗗𝗘𝗣𝗢𝗦𝗜𝗧", callback_data: "deposit_guide" }
        ],
        // Baris 2: VPS & PANEL (2 kolom)
        [
          { text: "🖥️ 𝗩𝗣𝗦 𝗗𝗢", callback_data: "buyvps_start" },
          { text: "🌐 𝗖𝗟𝗢𝗨𝗗", callback_data: "menu_apps" }
        ],
        // Baris 3: SCRIPT & ADMIN (2 kolom)
        [
          { text: "📁 𝗦𝗖𝗥𝗜𝗣𝗧", callback_data: "menu_scripts" },
          { text: "🛠️ 𝗔𝗗𝗠𝗜𝗡", callback_data: "buy_admin_panel" }
        ],
        // Baris 4: RESELLER & PANDUAN (2 kolom)
        [
          { text: "🤝 𝗥𝗘𝗦𝗘𝗟𝗟𝗘𝗥", callback_data: "buy_reseller_panel" },
          { text: "📡 𝗣𝗔𝗡𝗘𝗟", callback_data: "menu_panel" }
        ],
        // Baris 5: TOOLS & BACK TO START (2 kolom) - DIUBAH!
        [
          { text: "🏠 𝗞𝗘𝗠𝗕𝗔𝗟𝗜", callback_data: "go_to_start" }
        ]
      ]
    };

    // EDIT PESAN DENGAN FOTO
    await editMenuMessageWithPhoto(ctx, config.shopPhoto || config.startPhoto, shopText, {
      parse_mode: 'HTML',
      reply_markup: shopKeyboard
    });

  } catch (error) {
    console.error('Error shop_menu:', error);
    
    // FALLBACK: kalau gagal edit, kirim pesan baru
    try {
      await ctx.replyWithPhoto(config.shopPhoto || config.startPhoto, {
        caption: shopText,
        parse_mode: 'HTML',
        reply_markup: shopKeyboard
      });
    } catch (e) {
      await ctx.reply(shopText, {
        parse_mode: 'HTML',
        reply_markup: shopKeyboard
      });
    }
  }
});

// ACTION UNTUK KEMBALI KE MENU START (MENGGUNAKAN EDIT)
bot.action("go_to_start", async (ctx) => {
  try {
    const stats = getBotStats();
    
    // Cek dan tambah user
    if (typeof checkAndAddUser === 'function') {
      checkAndAddUser(ctx.from);
    }
    
    const welcomeText = `
🤗 𝗪𝗲𝗹𝗰𝗼𝗺𝗲 ${ctx.from.first_name || 'User'}!  😍
𝘚𝘦𝘭𝘢𝘮𝘢𝘵 𝘥𝘢𝘵𝘢𝘯𝘨 𝘥𝘪 ${stats.botName}  
═══════════════════════════════
📊 <b>𝗕𝗢𝗧 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡</b>
├─ 🏷️ <b>Owner :</b> ${stats.ownerName}
├─ 🤖 <b>Bot Name :</b> ${stats.botName}
├─ 🔥 <b>Version :</b> 8.0.0 Premium
├─ ⚡ <b>Prefix :</b> / (Slash)

📈 <b>𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗞 𝗦𝗜𝗦𝗧𝗘𝗠</b>
├─ 👥 <b>Total Users :</b> ${stats.totalUsers}
├─ ⏱️ <b>Runtime :</b> ${stats.runtime}
└─ 🆙 <b>Status :</b> <code>ONLINE</code>
`;

    const startKeyboard = {
      inline_keyboard: [
        [{ text: "🛍 𝗠𝗘𝗡𝗨 𝗟𝗔𝗬𝗔𝗡𝗔𝗡", callback_data: "shop_menu" }],
        [
          { text: "📜 𝗣𝗔𝗡𝗗𝗨𝗔𝗡", callback_data: "full_guide" },
          { text: "💰 𝗗𝗘𝗣𝗢𝗦𝗜𝗧", callback_data: "topup_nokos" }
        ],
        [
          { text: "👑 𝗢𝗪𝗡𝗘𝗥", callback_data: "menu_owner_contact" },
          { text: "🛠️ 𝗧𝗢𝗢𝗟𝗦", callback_data: "menu_tools" }
        ],
        [
          { text: "📢 𝗖𝗛𝗔𝗡𝗡𝗘𝗟", url: `https://t.me/${config.channelName}` },
        ]
      ]
    };

    // ✅ INI YANG DIPERBAIKI: startText → welcomeText
    await editMenuMessageWithPhoto(ctx, config.startPhoto, welcomeText, {
      parse_mode: 'HTML',
      reply_markup: startKeyboard
    });

  } catch (error) {
    console.error('Error go_to_start:', error);
    
    // FALLBACK: kalau gagal edit
    try {
      await ctx.reply('Maaf, terjadi kesalahan. Silakan ketik /start').catch(() => {});
    } catch (e) {}
  }
});
bot.action("menu_tools", async (ctx) => {
  await editMenuMessage(ctx, 
    `<blockquote><b>╭━━━✧「 𝗧𝗢𝗢𝗟𝗦 𝗠𝗘𝗡𝗨 」✧━━━❍</b>
<b>┃ 🎬 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗠𝗲𝗻𝘂</b>
<b>┃ ├⌑</b> /ytsearch <i>(Searching YouTube)</i>
<b>┃ └⌑</b> /ytmp3 <i>(Audio)</i>
<b>┃</b>
<b>┃ 🎥 𝗧𝗶𝗸𝗧𝗼𝗸 𝗠𝗲𝗻𝘂</b>
<b>┃ └⌑</b> /tiktokmp4 <i>(Video)</i>
<b>┃</b>
<b>┃ 📝 𝗛𝗲𝗹𝗽 𝗠𝗲𝗻𝘂</b>
<b>┃ ├⌑</b> /checkerror
<b>┃ └⌑</b> /fixerror
<b>┃</b>
<b>┃ 🛠️ 𝗧𝗼𝗼𝗹𝘀 𝗠𝗲𝗻𝘂</b>
<b>┃ ├⌑</b> /makeqr
<b>┃ ├⌑</b> /ssweb
<b>┃ ├⌑</b> /shorten
<b>┃ ├⌑</b> /react <i>(React WA Channel)</i>
<b>┃ ├⌑</b> /qc <i>(Quote Creator)</i>
<b>┃ ├⌑</b> /brat <i>(Brat Sticker)</i>
<b>┃ └⌑</b> /tourl <i>(Upload to URL)</i>
<b>╰━━━━━━━━━━━━━━━━━━━━━━❍</b></blockquote>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "back_home" }]
        ]
      }
    }
  );
});

bot.action("menu_owner_contact", async (ctx) => {
  await editMenuMessage(ctx,
    `╔══════════════════════════════════╗
║      👑 𝗢𝗪𝗡𝗘𝗥 𝗦𝗨𝗣𝗣𝗢𝗥𝗧       ║
╠══════════════════════════════════╣
║  𝗛𝘂𝗯𝘂𝗻𝗴𝗶 𝗼𝘄𝗻𝗲𝗿 𝗯𝗶𝗹𝗮 𝗯𝘂𝘁𝘂𝗵 𝗯𝗮𝗻𝘁𝘂𝗮𝗻 ║
╚══════════════════════════════════╝

<b>📇 𝗣𝗥𝗢𝗙𝗜𝗟 𝗢𝗪𝗡𝗘𝗥</b>
├─ 🏷️ <b>Nama :</b> ${config.ownerName || "𝗔𝗱𝗺𝗶𝗻"}
├─ 📞 <b>WhatsApp :</b> ${config.ownerWa}
├─ ✈️ <b>Telegram :</b> ${config.ownerUser}
└─ 🆔 <b>User ID :</b> <code>${config.ownerId}</code>

<b>⏰ 𝗪𝗔𝗞𝗧𝗨 𝗢𝗡𝗟𝗜𝗡𝗘</b>
├─ Senin - Jumat: 08.00 - 22.00 WIB
├─ Sabtu - Minggu: 09.00 - 21.00 WIB
└─ Support 24/7 via Telegram

<b>📞 𝗞𝗢𝗡𝗧𝗔𝗞 𝗗𝗔𝗥𝗜𝗨𝗥𝗧</b>
• WhatsApp: Chat langsung
• Telegram: Fast response
• Email: Support ticket
• Bot: Auto reply system

<b>⚠️ 𝗣𝗘𝗡𝗧𝗜𝗡𝗚</b>
• Sertakan bukti transaksi jika ada masalah
• Screenshoot error yang terjadi
• Jangan spam chat owner
• Respon dalam 1-12 jam

<b>🎯 𝗟𝗔𝗬𝗔𝗡𝗔𝗡 𝗦𝗨𝗣𝗣𝗢𝗥𝗧</b>
├─ Troubleshooting order
├─ Refund & komplain
├─ Bantuan teknis
├─ Konsultasi produk
└─ Request fitur baru

<code>══════════════════════════════</code>
<i>Pilih opsi di bawah untuk mulai:</i>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💬 𝗞𝗜𝗥𝗜𝗠 𝗣𝗘𝗦𝗔𝗡", callback_data: "send_message_owner" },
            { text: "📞 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣", url: `https://wa.me/${config.ownerWa.replace(/[^0-9]/g, '')}` }
          ],
          [
            { text: "✈️ 𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠", url: `https://t.me/${config.ownerUser.replace('@', '')}` }
          ],
          [
            { text: "🔙 𝗠𝗘𝗡𝗨 𝗨𝗧𝗔𝗠𝗔", callback_data: "back_home" }
          ]
        ]
      }
    }
  );
});

bot.action("send_message_owner", async (ctx) => {
  liveChatState[ctx.from.id] = { step: "WAITING_MESSAGE" };
  await editMenuMessage(ctx, 
    "📝 <b>𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗞𝗲𝘁𝗶𝗸 𝗣𝗲𝘀𝗮𝗻 𝗨𝗻𝘁𝘂𝗸 𝗗𝗶𝗸𝗶𝗿𝗶𝗺 𝗞𝗲𝗽𝗮𝗱𝗮 𝗢𝘄𝗻𝗲𝗿 𝗕𝗼𝘁.</b>\n<b>🍂 𝗧𝗲𝗸𝗮𝗻 𝗕𝘂𝘁𝘁𝗼𝗻 𝗕𝗮𝘁𝗮𝗹 𝗗𝗶𝗯𝗮𝘄𝗮𝗵 𝗨𝗻𝘁𝘂𝗸 𝗠𝗲𝗺𝗯𝗮𝘁𝗮𝗹𝗸𝗮𝗻.</b>",
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "❌ 𝗕𝗮𝘁𝗮𝗹 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗣𝗲𝘀𝗮𝗻", callback_data: "back_home" }]
        ]
      }
    }
  );
});

bot.action("back_home", async (ctx) => {
  const stats = getBotStats();
  
  // ========== PERUBAHAN TAMPILAN BACK HOME ==========
  const welcomeText = `
<b>👋 𝗦𝗘𝗟𝗔𝗠𝗔𝗧 𝗗𝗔𝗧𝗔𝗡𝗚 𝗞𝗘𝗠𝗕𝗔𝗟𝗜</b>
<i>${ctx.from.first_name || 'User'}!</i>

📊 <b>𝗦𝗧𝗔𝗧𝗨𝗦 𝗕𝗢𝗧</b>
├─ 🤖 <b>Nama Bot :</b> ${stats.botName}
├─ 👑 <b>Owner :</b> ${stats.ownerName}
├─ ⚡ <b>Version :</b> 8.0.0 Premium
├─ 👥 <b>Users :</b> ${stats.totalUsers}
├─ ⏱️ <b>Uptime :</b> ${stats.runtime}
└─ 🟢 <b>Status :</b> <code>ACTIVE</code>

<code>══════════════════════════════</code>
<i>Pilih menu di bawah untuk mulai:</i>`;

  const menuKeyboard = {
    inline_keyboard: [
      // Baris 1: Menu Utama (LAYANAN & GUIDE)
      [
        { text: `🎯 𝗟𝗔𝗬𝗔𝗡𝗔𝗡`, callback_data: `shop_menu` },
        { text: "🌐 𝗖𝗟𝗢𝗨𝗗", callback_data: "menu_apps" }
      ],
      // Baris 2: Layanan Populer (NOKOS & DEPOSIT)
      [
        { text: `📱 𝗡𝗢𝗞𝗢𝗦`, callback_data: `choose_service` },
        { text: `💰 𝗗𝗘𝗣𝗢𝗦𝗜𝗧`, callback_data: `deposit_guide` }
      ],
      // Baris 3: VPS & PANEL (2 kolom)
      [
        { text: `🖥️ 𝗩𝗣𝗦`, callback_data: `buyvps_start` },
        { text: `📡 𝗣𝗔𝗡𝗘𝗟`, callback_data: `menu_panel` }
      ],
      // Baris 4: SCRIPT & TOOLS (2 kolom)
      [
        { text: `📁 𝗦𝗖𝗥𝗜𝗣𝗧`, callback_data: `menu_scripts` },
        { text: `⚡ 𝗚𝗨𝗜𝗗𝗘`, callback_data: `full_guide` }   
      ]
    ]
};
  // ========== AKHIR PERUBAHAN ==========

  if (config.startPhoto) {
    try {
      await editMenuMessageWithPhoto(ctx, config.startPhoto, welcomeText, {
        parse_mode: "HTML",
        reply_markup: menuKeyboard
      });
    } catch (e) {
      try {
        await editMenuMessage(ctx, welcomeText, {
          parse_mode: "HTML",
          reply_markup: menuKeyboard
        });
      } catch (err) {
        await safeReply(ctx, welcomeText, {
          parse_mode: "HTML",
          reply_markup: menuKeyboard
        });
      }
    }
  } else {
    try {
      await editMenuMessage(ctx, welcomeText, {
        parse_mode: "HTML",
        reply_markup: menuKeyboard
      });
    } catch (err) {
      await safeReply(ctx, welcomeText, {
        parse_mode: "HTML",
        reply_markup: menuKeyboard
      });
    }
  }
});

// ========== MENU OWNER DENGAN FITUR GANTI STIKER ==========
function showOwnerMenu(ctx) {
  if (String(ctx.from.id) !== String(config.ownerId)) 
    return safeReply(ctx, "<blockquote>🚫 <b>Kamu Bukan Owner Bot!</b></blockquote>", { parse_mode: "HTML" });

  safeReply(ctx, `<blockquote><b>💠───「 ❝ 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨 ❞ 」───💠</b>\n<b>➥ Silahkan Tekan Button Dibawah:</b></blockquote>`,
    {
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        // ===== TAMBAHKAN BUTTON UNTUK GANTI STIKER =====
        [ Markup.button.callback("🎨 ☇ 𝗚𝗔𝗡𝗧𝗜 𝗦𝗧𝗜𝗞𝗘𝗥 𝗪𝗘𝗟𝗖𝗢𝗠𝗘", "change_sticker_menu") ],
        // ==============================================
        [ Markup.button.callback("🟢 ☇ 𝗦𝗲𝘁𝘁𝗶𝗻𝗴 𝗣𝗮𝗻𝗲𝗹 (𝗢𝗻/𝗢𝗳𝗳)", "owner_panel") ],
        [ Markup.button.callback("📢 ☇ 𝗕𝗿𝗼𝗮𝗱𝗰𝗮𝘀𝘁", "owner_broadcast") ],
        [
          Markup.button.callback("➕ ☇ 𝗔𝗱𝗱 𝗦𝗰𝗿𝗶𝗽𝘁", "add_script"),
          Markup.button.callback("🗑 ☇ 𝗗𝗲𝗹𝗲𝘁𝗲 𝗦𝗰𝗿𝗶𝗽𝘁", "del_script")
        ],
        [
          Markup.button.callback("📱 ☇ 𝗔𝗱𝗱 𝗮𝗸𝘂𝗻 𝗱𝗶𝗴𝗶𝘁𝗮𝗹 𝗼𝗰𝗲𝗮𝗻", "add_app"),
          Markup.button.callback("🗑 ☇ 𝗗𝗲𝗹𝗲𝘁𝗲 𝗗𝗼", "del_app")
        ],
        [
          Markup.button.callback("➕ ☇ 𝗔𝗱𝗱 𝗔𝗰𝗰𝗼𝘂𝗻𝘁", "owner_add_account"),
          Markup.button.callback("🗑 ☇ 𝗗𝗲𝗹𝗲𝘁𝗲 𝗔𝗰𝗰𝗼𝘂𝗻𝘁", "owner_del_account")
        ],
        [ Markup.button.callback("🖥️ ☇ 𝗟𝗶𝘀𝘁 𝗩𝗣𝗦 𝗢𝗿𝗱𝗲𝗿𝘀", "list_vps_orders") ],
        [ Markup.button.callback("🌐 ☇ 𝗟𝗶𝘀𝘁 𝗽𝗿𝗼𝗱𝘂𝗸 𝗱𝗶𝗴𝗶𝘁𝗮𝗹 𝗼𝗰𝗲𝗮𝗻", "list_apps") ],
        [ Markup.button.callback("💳 ☇ 𝗚𝗮𝗻𝘁𝗶 𝗠𝗲𝘁𝗼𝗱𝗲 𝗣𝗮𝘆𝗺𝗲𝗻𝘁", "change_payment") ],
        [ Markup.button.callback("🧾 ☇ 𝗠𝗲𝗻𝘂 𝗠𝗮𝗻𝘂𝗮𝗹 𝗣𝗮𝘆𝗺𝗲𝗻𝘁𝘀", "manual_payments_menu") ],
        [ Markup.button.callback("💸 ☇ 𝗪𝗶𝘁𝗵𝗱𝗿𝗮𝘄 𝗦𝗮𝗹𝗱𝗼 (𝗔𝗹𝘁𝗮𝗻𝘁𝗶𝗰)", "menu_wd_info") ],
        [ 
          Markup.button.callback("💰 ☇ 𝗧𝗮𝗺𝗯𝗮𝗵 𝗦𝗮𝗹𝗱𝗼", "manual_add_saldo_menu"),
          Markup.button.callback("🗑️ ☇ 𝗞𝘂𝗿𝗮𝗻𝗴𝗶 𝗦𝗮𝗹𝗱𝗼", "manual_reduce_saldo_menu")
        ],
        [ 
          Markup.button.callback("📊 ☇ 𝗦𝘁𝗮𝘁𝗶𝘀𝘁𝗶𝗸 𝗦𝗮𝗹𝗱𝗼", "stats_saldo_menu"),
          Markup.button.callback("📋 ☇ 𝗟𝗼𝗴 𝗦𝗮𝗹𝗱𝗼", "logsaldo_menu")
        ],
        [ Markup.button.callback("💾 ☇ 𝗕𝗮𝗰𝗸𝘂𝗽 𝗗𝗮𝘁𝗮𝗯𝗮𝘀𝗲", "backup_database") ],
        [ Markup.button.callback("🔙 ☇ 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "back_home") ]
      ])
    }
  );
}

bot.action("menu_owner", (ctx) => {
  ctx.answerCbQuery().catch(()=>{});
  showOwnerMenu(ctx);
});

// Tambahkan action handler untuk menu baru
bot.action("manual_add_saldo_menu", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner!", { show_alert: true });
  }
  
  await editMenuMessage(ctx,
    `<blockquote><b>💰 MENU TAMBAH SALDO MANUAL</b>\n\n` +
    `<b>Perintah yang tersedia:</b>\n` +
    `<code>/addsaldo [user_id] [jumlah]</code>\n` +
    `<code>/ceksaldo [user_id]</code>\n` +
    `<code>/logsaldo</code>\n\n` +
    `<i>Kirim perintah di chat untuk menggunakan fitur.</i></blockquote>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 Kembali ke Menu Owner", callback_data: "menu_owner" }]
        ]
      }
    }
  );
});

bot.action("logsaldo_menu", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner!", { show_alert: true });
  }
  
  // Panggil command logsaldo
  await ctx.answerCbQuery("Memuat log saldo...");
  const fakeMessage = {
    text: "/logsaldo",
    from: ctx.from,
    chat: ctx.chat
  };
  
  // Simulasikan command
  await bot.handleUpdate({
    message: fakeMessage,
    update_id: Date.now()
  });
});

// Menu reduce saldo
bot.action("manual_reduce_saldo_menu", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner!", { show_alert: true });
  }
  
  await editMenuMessage(ctx,
    `<blockquote><b>🗑️ MENU KURANGI/HAPUS SALDO</b>\n\n` +
    `<b>Perintah yang tersedia:</b>\n` +
    `<code>/delsaldo [user_id] [jumlah]</code>\n` +
    `<code>/delsaldo [user_id] all</code> - Hapus semua saldo\n` +
    `<code>/delsaldo [user_id] reset</code> - Reset ke 0\n` +
    `<code>/removeuser [user_id]</code> - Hapus user dari DB\n` +
    `<code>/topbalance [limit]</code> - Top user by saldo\n` +
    `<code>/statssaldo</code> - Statistik saldo\n\n` +
    `<i>Kirim perintah di chat untuk menggunakan fitur.</i></blockquote>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 Kembali ke Menu Owner", callback_data: "menu_owner" }]
        ]
      }
    }
  );
});

// Menu stats saldo
bot.action("stats_saldo_menu", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner!", { show_alert: true });
  }
  
  await ctx.answerCbQuery("Memuat statistik...", { show_alert: false });
  
  // Simulasikan command statssaldo
  const fakeMessage = {
    text: "/statssaldo",
    from: ctx.from,
    chat: ctx.chat
  };
  
  await bot.handleUpdate({
    message: fakeMessage,
    update_id: Date.now()
  });
});

// Action untuk refresh top balance
bot.action("refresh_top_balance", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner!", { show_alert: true });
  }
  
  await ctx.answerCbQuery("🔄 Memperbarui data...", { show_alert: false });
  
  // Simulasikan command topbalance
  const fakeMessage = {
    text: "/topbalance 10",
    from: ctx.from,
    chat: ctx.chat
  };
  
  await bot.handleUpdate({
    message: fakeMessage,
    update_id: Date.now()
  });
});

// Action untuk export top balance
bot.action("export_top_balance", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner!", { show_alert: true });
  }
  
  try {
    // Path database saldo
    const dbSaldoPath = "./database/saldoOtp.json";
    let saldoData = {};
    
    if (fs.existsSync(dbSaldoPath)) {
      try {
        saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
      } catch (err) {
        saldoData = {};
      }
    }

    // Ambil top 50 user
    const usersArray = Object.entries(saldoData)
      .map(([userId, balance]) => ({ userId, balance }))
      .filter(user => user.balance > 0)
      .sort((a, b) => b.balance - a.balance)
      .slice(0, 50);

    if (usersArray.length === 0) {
      return ctx.answerCbQuery("❌ Tidak ada data", { show_alert: true });
    }

    // Buat file CSV
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `top_balance_${timestamp}.csv`;
    const filepath = `./${filename}`;
    
    let csvContent = "Rank,User ID,Saldo\n";
    
    usersArray.forEach((user, index) => {
      const row = [
        index + 1,
        user.userId,
        user.balance
      ].join(',');
      
      csvContent += row + '\n';
    });
    
    fs.writeFileSync(filepath, csvContent);
    
    // Kirim file ke owner
    await ctx.replyWithDocument(
      { source: fs.createReadStream(filepath), filename: filename },
      { 
        caption: `<blockquote>📊 <b>EXPORT TOP BALANCE</b>\nTotal: ${usersArray.length} user</blockquote>`, 
        parse_mode: "HTML" 
      }
    );
    
    // Hapus file temporary
    fs.unlinkSync(filepath);
    
    await ctx.answerCbQuery("✅ Data berhasil diexport", { show_alert: false });
    
  } catch (error) {
    console.error("[ERROR] export_top_balance:", error);
    ctx.answerCbQuery("❌ Gagal export data", { show_alert: true });
  }
});

// Action untuk refresh stats saldo
bot.action("refresh_stats_saldo", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner!", { show_alert: true });
  }
  
  await ctx.answerCbQuery("🔄 Memperbarui statistik...", { show_alert: false });
  
  // Simulasikan command statssaldo
  const fakeMessage = {
    text: "/statssaldo",
    from: ctx.from,
    chat: ctx.chat
  };
  
  await bot.handleUpdate({
    message: fakeMessage,
    update_id: Date.now()
  });
});

// Action untuk detail stats saldo
bot.action("detail_stats_saldo", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner!", { show_alert: true });
  }
  
  try {
    // Path database saldo
    const dbSaldoPath = "./database/saldoOtp.json";
    let saldoData = {};
    
    if (fs.existsSync(dbSaldoPath)) {
      try {
        saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
      } catch (err) {
        saldoData = {};
      }
    }

    // Group by balance range
    const ranges = {
      "0": 0,
      "1-10k": 0,
      "10k-50k": 0,
      "50k-100k": 0,
      "100k-500k": 0,
      "500k-1jt": 0,
      ">1jt": 0
    };

    Object.values(saldoData).forEach(balance => {
      if (balance === 0) ranges["0"]++;
      else if (balance <= 10000) ranges["1-10k"]++;
      else if (balance <= 50000) ranges["10k-50k"]++;
      else if (balance <= 100000) ranges["50k-100k"]++;
      else if (balance <= 500000) ranges["100k-500k"]++;
      else if (balance <= 1000000) ranges["500k-1jt"]++;
      else ranges[">1jt"]++;
    });

    let message = `<blockquote>📈 <b>DETAIL DISTRIBUSI SALDO</b>\n\n`;
    
    for (const [range, count] of Object.entries(ranges)) {
      if (count > 0) {
        message += `<b>${range}:</b> ${count} user\n`;
      }
    }

    // User dengan saldo tertinggi dan terendah (non-zero)
    const nonZeroUsers = Object.entries(saldoData)
      .filter(([_, balance]) => balance > 0)
      .map(([userId, balance]) => ({ userId, balance }))
      .sort((a, b) => b.balance - a.balance);

    if (nonZeroUsers.length > 0) {
      const highest = nonZeroUsers[0];
      const lowest = nonZeroUsers[nonZeroUsers.length - 1];
      
      message += `\n<b>🎯 SALDO TERTINGGI:</b> ${toRupiah(highest.balance)}\n`;
      message += `<b>📉 SALDO TERENDAH (non-zero):</b> ${toRupiah(lowest.balance)}\n`;
      message += `<b>📊 RATA-RATA SALDO (non-zero):</b> ${toRupiah(
        nonZeroUsers.reduce((sum, user) => sum + user.balance, 0) / nonZeroUsers.length
      )}`;
    }

    message += `\n\n<i>Total user dalam database: ${Object.keys(saldoData).length}</i></blockquote>`;

    await ctx.editMessageText(message, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 Kembali ke Statistik", callback_data: "refresh_stats_saldo" }],
          [{ text: "📋 Export Detail", callback_data: "export_detail_stats" }]
        ]
      }
    });

  } catch (error) {
    console.error("[ERROR] detail_stats_saldo:", error);
    ctx.answerCbQuery("❌ Gagal mengambil detail", { show_alert: true });
  }
});

// Action untuk export detail stats
bot.action("export_detail_stats", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner!", { show_alert: true });
  }
  
  try {
    // Path database saldo
    const dbSaldoPath = "./database/saldoOtp.json";
    let saldoData = {};
    
    if (fs.existsSync(dbSaldoPath)) {
      try {
        saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
      } catch (err) {
        saldoData = {};
      }
    }

    if (Object.keys(saldoData).length === 0) {
      return ctx.answerCbQuery("❌ Database kosong", { show_alert: true });
    }

    // Buat file CSV dengan semua data
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `saldo_detail_${timestamp}.csv`;
    const filepath = `./${filename}`;
    
    let csvContent = "User ID,Saldo\n";
    
    // Sort by balance descending
    const sortedUsers = Object.entries(saldoData)
      .sort(([,a], [,b]) => b - a);
    
    sortedUsers.forEach(([userId, balance]) => {
      csvContent += `${userId},${balance}\n`;
    });
    
    fs.writeFileSync(filepath, csvContent);
    
    // Kirim file ke owner
    await ctx.replyWithDocument(
      { source: fs.createReadStream(filepath), filename: filename },
      { 
        caption: `<blockquote>📊 <b>EXPORT DETAIL SALDO</b>\nTotal: ${sortedUsers.length} user</blockquote>`, 
        parse_mode: "HTML" 
      }
    );
    
    // Hapus file temporary
    fs.unlinkSync(filepath);
    
    await ctx.answerCbQuery("✅ Detail berhasil diexport", { show_alert: false });
    
  } catch (error) {
    console.error("[ERROR] export_detail_stats:", error);
    ctx.answerCbQuery("❌ Gagal export detail", { show_alert: true });
  }
});

bot.action("menu_owner", (ctx) => {
  ctx.answerCbQuery().catch(()=>{});
  showOwnerMenu(ctx);
});

// Update smm_menu action untuk menampilkan statistik nokos
bot.action("smm_menu", async (ctx) => {
    const userId = ctx.from.id;
    
    // Ambil saldo dengan cara yang lebih cepat
    let saldo = 0;
    try {
        const dbSaldoPath = "./database/saldoOtp.json";
        if (fs.existsSync(dbSaldoPath)) {
            const saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8") || "{}");
            saldo = saldoData[userId] || 0;
        }
    } catch (e) {
        console.error("[ERROR] Gagal baca saldo:", e.message);
    }

    // Hitung statistik dengan cache untuk performa
    let totalOrders = 0;
    let successfulOrders = 0;
    
    // Cek history SMM untuk statistik yang lebih akurat
    try {
        const smmHistory = getSmmHistory(userId);
        totalOrders = smmHistory.length;
        successfulOrders = smmHistory.filter(h => h.status === "success" || !h.status).length;
    } catch (e) {
        console.error("[ERROR] Gagal baca history SMM:", e.message);
    }

    const text = `
╔══════════════════════════════════╗
║     📱 𝗦𝗠𝗠 𝗣𝗔𝗡𝗘𝗟 𝗠𝗘𝗡𝗨          ║
╠══════════════════════════════════╣

👤 <b>User:</b> ${ctx.from.first_name || "User"}
💰 <b>Saldo:</b> <code>${toRupiah(saldo)}</code>
📊 <b>Total Order:</b> ${totalOrders}
✅ <b>Sukses:</b> ${successfulOrders}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔥 <b>LAYANAN SOSIAL MEDIA TERBAIK</b>
├─ Instagram Followers/Likes/Views
├─ TikTok Followers/Likes/Views
├─ YouTube Subscribers/Likes/Views
├─ Twitter Followers/Likes/Retweets
├─ Facebook Likes/Shares/Followers
└─ Telegram Members/Reactions

⚡ <b>FITUR UNGGULAN:</b>
• Proses INSTANT (1-10 menit)
• Harga TERMURAH di pasaran
• Support 24/7
• Garansi refill/refund
• Auto submit, no delay

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 <i>Pilih menu di bawah untuk mulai:</i>`;

    await editMenuMessage(ctx, text, {
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                // Baris 1: Layanan Utama
                [
                    { text: "📱 𝙇𝙞𝙨𝙩 𝙇𝙖𝙮𝙖𝙣𝙖𝙣", callback_data: "smm_services_0" },
                    { text: "💰 𝘿𝙚𝙥𝙤𝙨𝙞𝙩", callback_data: "topup_nokos" }
                ],
                // Baris 2: Cek & Riwayat
                [
                    { text: "📋 𝘾𝙚𝙠 𝙎𝙖𝙡𝙙𝙤", callback_data: "cek_saldo_user" },
                    { text: "📜 𝙍𝙞𝙬𝙖𝙮𝙖𝙩", callback_data: "smm_history" }
                ],
                // Baris 3: Support & Status
                [
                    { text: "🔍 𝘾𝙚𝙠 𝙎𝙩𝙖𝙩𝙪𝙨", callback_data: "smm_check_status" },
                    { text: "💬 𝙃𝙚𝙡𝙥", callback_data: "send_message_owner" }
                ],
                // Baris 4: Navigasi
                [
                    { text: "🔙 𝙈𝙚𝙣𝙪 𝙐𝙩𝙖𝙢𝙖", callback_data: "shop_menu" }
                ]
            ]
        }
    });
});

// Tambahkan callback untuk menu cek saldo di SMM menu
bot.action("cek_saldo_user", async (ctx) => {
  const userId = ctx.from.id;
  
  try {
    // Path database saldo
    const dbSaldoPath = "./database/saldoOtp.json";
    let saldoData = {};
    
    if (fs.existsSync(dbSaldoPath)) {
      try {
        saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
      } catch (err) {
        saldoData = {};
      }
    }

    const userBalance = saldoData[userId] || 0;
    
    await ctx.answerCbQuery(`Saldo Anda: ${toRupiah(userBalance)}`, { show_alert: true });
    
  } catch (error) {
    ctx.answerCbQuery("❌ Gagal mengambil saldo", { show_alert: true });
  }
});

// Action untuk menghapus log saldo
bot.action("clear_saldo_logs", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner!", { show_alert: true });
  }
  
  try {
    const logPath = "./database/saldo_logs.json";
    
    if (fs.existsSync(logPath)) {
      const oldLogs = JSON.parse(fs.readFileSync(logPath, "utf8"));
      fs.writeFileSync(logPath, JSON.stringify([], null, 2));
      
      await ctx.answerCbQuery(`✅ Log dihapus (${oldLogs.length} entri)`, { show_alert: true });
      await ctx.editMessageText("<blockquote>✅ <b>Log saldo berhasil dihapus!</b></blockquote>", {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "🔙 Menu Owner", callback_data: "menu_owner" }]]
        }
      });
    }
    
  } catch (error) {
    ctx.answerCbQuery("❌ Gagal menghapus log", { show_alert: true });
  }
});

// Action untuk export log saldo
bot.action("export_saldo_logs", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner!", { show_alert: true });
  }
  
  try {
    const logPath = "./database/saldo_logs.json";
    
    if (!fs.existsSync(logPath)) {
      return ctx.answerCbQuery("❌ Tidak ada log", { show_alert: true });
    }
    
    const logs = JSON.parse(fs.readFileSync(logPath, "utf8"));
    
    if (logs.length === 0) {
      return ctx.answerCbQuery("❌ Log kosong", { show_alert: true });
    }
    
    // Buat file CSV
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `saldo_logs_${timestamp}.csv`;
    const filepath = `./${filename}`;
    
    let csvContent = "User ID,Jumlah,Saldo Lama,Saldo Baru,Alasan,Waktu,Tipe\n";
    
    logs.forEach(log => {
      const row = [
        log.userId,
        log.amount,
        log.oldBalance,
        log.newBalance,
        `"${log.reason.replace(/"/g, '""')}"`,
        log.timestamp,
        log.type
      ].join(',');
      
      csvContent += row + '\n';
    });
    
    fs.writeFileSync(filepath, csvContent);
    
    // Kirim file ke owner
    await ctx.replyWithDocument(
      { source: fs.createReadStream(filepath), filename: filename },
      { caption: `<blockquote>📊 <b>EXPORT LOG SALDO</b>\nTotal: ${logs.length} entri</blockquote>`, parse_mode: "HTML" }
    );
    
    // Hapus file temporary
    fs.unlinkSync(filepath);
    
    await ctx.answerCbQuery("✅ Log berhasil diexport", { show_alert: false });
    
  } catch (error) {
    console.error("[ERROR] export_saldo_logs:", error);
    ctx.answerCbQuery("❌ Gagal export log", { show_alert: true });
  }
});

bot.action("list_vps_orders", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner yang boleh melihat order VPS!", { show_alert: true });
  }
  
  const vpsPath = "./database/data_vps.json";
  
  if (!fs.existsSync(vpsPath)) {
    return safeReply(ctx, "<blockquote>📭 Belum ada data VPS yang terjual.</blockquote>", { 
      parse_mode: "HTML" 
    });
  }
  
  try {
    const vpsDB = JSON.parse(fs.readFileSync(vpsPath));
    
    if (!Array.isArray(vpsDB) || vpsDB.length === 0) {
      return safeReply(ctx, "<blockquote>📭 Belum ada data VPS yang terjual.</blockquote>", { 
        parse_mode: "HTML" 
      });
    }
    
    let message = "<b>📋 DAFTAR ORDER VPS</b>\n\n";
    
    vpsDB.forEach((vps, i) => {
      message += `<b>${i + 1}. ${vps.hostname}</b>\n`;
      message += `<code>   User:</code> ${vps.username} (${vps.userId})\n`;
      message += `<code>   IP:</code> ${vps.ip}\n`;
      message += `<code>   Region:</code> ${vps.region}\n`;
      message += `<code>   Paket:</code> ${vps.paket}\n`;
      message += `<code>   Harga:</code> ${toRupiah(vps.harga)}\n`;
      message += `<code>   Tanggal:</code> ${vps.created}\n\n`;
    });
    
    await safeReply(ctx, message, {
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "menu_owner")]
      ])
    });
    
  } catch (error) {
    console.error("Error reading VPS data:", error);
    safeReply(ctx, "<blockquote>❌ Gagal membaca data VPS.</blockquote>", { 
      parse_mode: "HTML" 
    });
  }
});

bot.action("backup_database", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner yang boleh backup!", { show_alert: true });
  }
  
  await ctx.answerCbQuery("⏳ Memproses Full Backup...", { show_alert: false });
  await safeReply(ctx, "<blockquote>📦 <b>Sedang mempacking seluruh Source Code & Database...</b>\n<i>Mohon tunggu, proses tergantung ukuran file.</i></blockquote>", { parse_mode: "HTML" });
  
  createAndSendFullBackup(ctx, false);
});


bot.action("manual_payments_menu", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  ctx.answerCbQuery().catch(()=>{});
  
  const payments = readManualPayments();
  const pendingCount = payments.filter(p => p.status === "pending").length;
  
  safeReply(ctx, `<blockquote><b>🧾 𝗠𝗲𝗻𝘂 𝗣𝗮𝘆𝗺𝗲𝗻𝘁 𝗠𝗮𝗻𝘂𝗮𝗹</b>\n<b>𝖯𝖾𝗇𝖽𝗂𝗇𝗀:</b> ${pendingCount}</blockquote>`, {
    parse_mode: "HTML",
    ...Markup.inlineKeyboard([
      [ Markup.button.callback("📋 𝗟𝗶𝘀𝘁 𝗣𝗲𝗻𝗱𝗶𝗻𝗴", "list_pending_payments") ],
      [ Markup.button.callback("📜 𝗔𝗹𝗹 𝗣𝗮𝘆𝗺𝗲𝗻𝘁", "list_all_payments") ],
      [ Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "menu_owner") ]
    ])
  });
});

bot.action("list_pending_payments", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("🚫 𝗞𝗮𝗺𝘂 𝗕𝘂𝗸𝗮𝗻𝗹𝗮𝗵 𝗢𝘄𝗻𝗲𝗿 𝗕𝗼𝘁!");
  
  const payments = readManualPayments();
  const pending = payments.filter(p => p.status === "pending");
  
  if (pending.length === 0) {
    safeReply(ctx, "⏳ 𝗧𝗶𝗱𝗮𝗸 𝗔𝗱𝗮 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻 𝗬𝗮𝗻𝗴 𝗦𝗲𝗱𝗮𝗻𝗴 𝗣𝗲𝗻𝗱𝗶𝗻𝗴");
    return showOwnerMenu(ctx);
  }
  
  let message = "<b>📋 𝗗𝗮𝘁𝗮 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻 𝗣𝗲𝗻𝗱𝗶𝗻𝗴</b>\n\n";
  pending.forEach((p, i) => {
    message += `<b>${i+1}. ${p.userName} (${p.userId})</b>\n`;
    message += `<code>   𝗜𝘁𝗲𝗺 :</code> ${p.itemName}\n`;
    message += `<code>   𝗔𝗺𝗼𝘂𝗻𝘁 :</code> ${toRupiah(p.amount)}\n`;
    message += `<code>   𝗧𝗶𝗺𝗲 :</code> ${new Date(p.timestamp).toLocaleString()}\n`;
    message += `   [Verify](tg://user?id=${p.userId})\n\n`;
  });
  
  safeReply(ctx, message, {
    parse_mode: "HTML",
    ...Markup.inlineKeyboard([
      [ Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "manual_payments_menu") ]
    ])
  });
});

bot.action("list_all_payments", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  
  const payments = readManualPayments();
  
  if (payments.length === 0) {
    safeReply(ctx, "❌ 𝗕𝗲𝗹𝘂𝗺 𝗔𝗱𝗮 𝗥𝗶𝘄𝗮𝘆𝗮𝘁 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻 𝗠𝗮𝗻𝘂𝗮𝗹.");
    return showOwnerMenu(ctx);
  }
  
  let message = "<b>📜 𝗕𝗲𝗿𝗶𝗸𝘂𝘁 𝗥𝗶𝘄𝗮𝘆𝗮𝘁 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻 𝗠𝗮𝗻𝘂𝗮𝗹l</b>\n\n";
  payments.forEach((p, i) => {
    const statusEmoji = p.status === "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱" ? "✅" : p.status === "𝗥𝗲𝗷𝗲𝗰𝘁𝗲𝗱" ? "❌" : "⏳";
    message += `<b>${i+1}. ${statusEmoji} ${p.userName}</b>\n`;
    message += `<code>   𝗜𝘁𝗲𝗺 :</code> ${p.itemName}\n`;
    message += `<code>   𝗔𝗺𝗼𝘂𝗻𝘁 :</code> ${toRupiah(p.amount)}\n`;
    message += `<code>   𝗦𝘁𝗮𝘁𝘂𝘀 :</code> ${p.status}\n`;
    message += `<code>   𝗧𝗶𝗺𝗲 :</code> ${new Date(p.timestamp).toLocaleString()}\n\n`;
  });
  
  safeReply(ctx, message, {
    parse_mode: "HTML",
    ...Markup.inlineKeyboard([
      [ Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "manual_payments_menu") ]
    ])
  });
});

bot.action("change_payment", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  ctx.answerCbQuery().catch(()=>{});
  const active = getActivePaymentMethod();
  safeReply(ctx, `<b>💸 𝗠𝗲𝘁𝗼𝗱𝗲 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻 𝗬𝗮𝗻𝗴 𝗔𝗸𝘁𝗶𝗳 𝗦𝗮𝗮𝘁 𝗜𝗻𝗶 :</b> <code>${active.toUpperCase()}</code>\n<b>🚀 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗣𝗶𝗹𝗶𝗵 𝗣𝗮𝘆𝗺𝗲𝗻𝘁 𝗕𝗮𝗿𝘂 𝗗𝗶𝗯𝗮𝘄𝗮𝗵:</b>`, {
    parse_mode: "HTML",
    ...Markup.inlineKeyboard([
      [ Markup.button.callback("🌊 𝗔𝘁𝗹𝗮𝗻𝘁𝗶𝗰", "set_payment_atlantic") ],
      [ Markup.button.callback("🍂 𝗢𝗿𝗸𝘂𝘁 / 𝗢𝗿𝗱𝗲𝗿𝗞𝘂𝗼𝘁𝗮", "set_payment_orkut") ],
      // ===== TAMBAH BARIS INI =====
      [ Markup.button.callback("🎯 𝗣𝗮𝗸𝗮𝘀𝗶𝗿", "set_payment_pakasir") ],
      // =============================
      [ Markup.button.callback("🌸 𝗠𝗮𝗻𝘂𝗮𝗹 (𝗤𝗥𝗜𝗦 𝗙𝗼𝘁𝗼)", "set_payment_manual") ],
      [ Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "menu_owner") ]
    ])
  });
});

bot.action("set_payment_pakasir", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  setActivePaymentMethod("pakasir");
  safeReply(ctx, "✅ <b>𝗠𝗲𝘁𝗼𝗱𝗲 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗗𝗶𝗴𝗮𝗻𝘁𝗶 𝗞𝗲 𝗣𝗔𝗞𝗔𝗦𝗜𝗥</b>", { parse_mode: "HTML" });
  showOwnerMenu(ctx);
});

bot.action("set_payment_atlantic", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  setActivePaymentMethod("atlantic");
  safeReply(ctx, "✅ <b>𝗠𝗲𝘁𝗼𝗱𝗲 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗗𝗶𝗴𝗮𝗻𝘁𝗶 𝗞𝗲 𝗔𝗧𝗟𝗔𝗡𝗧𝗜𝗖</b>", { parse_mode: "HTML" });
  showOwnerMenu(ctx);
});

bot.action("set_payment_orkut", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  setActivePaymentMethod("orkut");
  safeReply(ctx, "✅ <b>𝗠𝗲𝘁𝗼𝗱𝗲 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗗𝗶𝗴𝗮𝗻𝘁𝗶 𝗞𝗲 𝗢𝗥𝗞𝗨𝗧</b>", { parse_mode: "HTML" });
  showOwnerMenu(ctx);
});

bot.action("set_payment_manual", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  setActivePaymentMethod("manual");
  safeReply(ctx, "✅ <b>𝗠𝗲𝘁𝗼𝗱𝗲 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗗𝗶𝗴𝗮𝗻𝘁𝗶 𝗞𝗲 𝗤𝗥𝗜𝗦 𝗠𝗮𝗻𝘂𝗮𝗹</b>", { parse_mode: "HTML" });
  showOwnerMenu(ctx);
});

bot.action("owner_panel", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  const db = readDb();
  db.isPanelOpen = !db.isPanelOpen;
  saveDb(db);
  const status = db.isPanelOpen ? "🟢 𝗣𝗮𝗻𝗲𝗹 𝗢𝗻𝗹𝗶𝗻𝗲" : "🔴 𝗣𝗮𝗻𝗲𝗹 𝗢𝗳𝗳𝗹𝗶𝗻𝗲";
  safeReply(ctx, `<b>🚀 𝗦𝘁𝗮𝘁𝘂𝘀 𝗣𝗮𝗻𝗲𝗹 𝗦𝗲𝗸𝗮𝗿𝗮𝗻𝗴 :</b> ${status}`, { parse_mode: "HTML" });
});

bot.action("owner_broadcast", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  ctx.answerCbQuery().catch(()=>{});
  userState[ctx.from.id] = { step: "WAITING_BROADCAST" };
  safeReply(ctx, "📨 <b>𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗞𝗶𝗿𝗶𝗺 𝗧𝗲𝗸𝘀/𝗙𝗼𝘁𝗼 𝗬𝗮𝗻𝗴 𝗜𝗻𝗴𝗶𝗻 𝗞𝗮𝗺𝘂 𝗕𝗿𝗼𝗮𝗱𝗰𝗮𝘀𝘁..</b>\n🍂 𝗧𝗲𝗸𝗮𝗻 𝗕𝘂𝘁𝘁𝗼𝗻 𝗗𝗶𝗯𝗮𝘄𝗮𝗵 𝗨𝗻𝘁𝘂𝗸 𝗠𝗲𝗺𝗯𝗮𝘁𝗮𝗹𝗸𝗮𝗻.", {
    parse_mode: "HTML",
    ...Markup.inlineKeyboard([
      [Markup.button.callback("❌ 𝗕𝗮𝘁𝗮𝗹𝗸𝗮𝗻 𝗕𝗿𝗼𝗮𝗱𝗰𝗮𝘀𝘁", "cancel_broadcast")]
    ])
  });
});

bot.action("cancel_broadcast", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  if (userState[ctx.from.id]?.step === "WAITING_BROADCAST") {
    delete userState[ctx.from.id];
    safeReply(ctx, "❌ 𝗕𝗿𝗼𝗮𝗱𝗰𝗮𝘀𝘁 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗗𝗶𝗯𝗮𝘁𝗮𝗹𝗸𝗮𝗻.");
    showOwnerMenu(ctx);
  }
});

bot.action("buyvps_start", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_start')) return;
  
  await editMenuMessage(ctx,
`<blockquote><b>🛒 𝗞𝗔𝗧𝗔𝗟𝗢𝗚 𝗩𝗣𝗦 𝗗𝗜𝗚𝗜𝗧𝗔𝗟 𝗢𝗖𝗘𝗔𝗡</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━⨳
📦 𝗦𝗧𝗢𝗞 𝗩𝗣𝗦 𝗦𝗘𝗞𝗔𝗥𝗔𝗡𝗚 𝗧𝗘𝗥𝗦𝗘𝗗𝗜𝗔! 
⚙️ 𝗣𝗜𝗟𝗜𝗛 𝗧𝗬𝗣𝗘 𝗩𝗣𝗦 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗦𝗘𝗗𝗜𝗔 :

<b>🔴 𝗩𝗣𝗦 𝗛𝗜𝗚𝗛</b>
├✧ 𝖦𝖺𝗋𝖺𝗇𝗌𝗂 : 5 𝖧𝖺𝗋𝗂
├✧ 𝖱𝖾𝗉𝗅𝖺𝖼𝖾 : 1× 
└✧ 𝖧𝖺𝗋𝗀𝖺 𝖬𝗎𝗅𝖺𝗂 𝖣𝖺𝗋𝗂 : ${toRupiah(config.hargaVPS.high['2c2'])}
━━━━━━━━━━━━━━━━━━━━━━━━━⨳
<b>🚀 𝗦𝗜𝗟𝗔𝗛𝗞𝗔𝗡 𝗣𝗜𝗟𝗜𝗛 𝗞𝗔𝗧𝗔𝗟𝗢𝗚 
𝗩𝗣𝗦 𝗬𝗔𝗡𝗚 𝗧𝗘𝗥𝗦𝗘𝗗𝗜𝗔 :</b></blockquote>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔴 ☇ 𝗩𝗣𝗦 𝗛𝗜𝗚𝗛", callback_data: "buyvps_pkg:high" }],
          [{ text: "🔙 ☇ 𝗞𝗘𝗠𝗕𝗔𝗟𝗜", callback_data: "shop_menu" }]
        ]
      }
    }
  );
});

bot.action(/buyvps_pkg:(low|medium|high)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_pkg')) return;
  
  const paket = ctx.match[1];
  const userId = ctx.from.id;
  
  const count = await getDropletCount();
  const sisaVPS = Math.max(0, 10 - count);

  if (sisaVPS <= 0) {
    return editMenuMessage(ctx,
`<blockquote>🚫 𝗦𝗧𝗢𝗞 𝗩𝗣𝗦 𝗦𝗨𝗗𝗔𝗛 𝗛𝗔𝗕𝗜𝗦! 
━━━━━━━━━━━━━━━━━━━━⨳
📨 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗛𝘂𝗯𝘂𝗻𝗴𝗶 𝗢𝘄𝗻𝗲𝗿
𝗨𝗻𝘁𝘂𝗸 𝗦𝗲𝗴𝗲𝗿𝗮 𝗥𝗲𝘀𝘁𝗼𝗰𝗸 𝗩𝗣𝗦.</blockquote>`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "buyvps_start" }]
          ]
        }
      }
    );
  }

  if (!userState[userId]) userState[userId] = {};
  userState[userId].vpsData = { paket };

  let listRam = [];
  const dataHarga = config.hargaVPS?.[paket] || {};

  listRam = [
    { id: 1, label: "2GB 2 CPU | 60GB SSD | 3TB BW", plan: "2c2" },
    { id: 2, label: "4GB 2 CPU | 80GB SSD | 4TB BW", plan: "4c2" },
    { id: 3, label: "8GB 4 CPU | 160GB SSD | 5TB BW", plan: "8c4" },
    { id: 4, label: "16GB 4 CPU | 200GB SSD | 8TB BW", plan: "16c4" },
    { id: 5, label: "16GB 8 CPU | 320GB SSD | 6TB BW", plan: "16c8" }
  ];

  listRam = listRam.map(x => ({
    ...x,
    harga: dataHarga[x.plan] || 0
  }));

  let teks = `🖥 *PILIH SPESIFIKASI VPS*\n` +
             `──────────────────────────\n\n`;

  for (const item of listRam) {
    teks += `*${item.id}.* ${item.label}\n` +
            `└➤ *Rp ${item.harga.toLocaleString("id-ID")}*\n` +
            `──────────────────────────\n`;
  }

  teks += `\n✅ *STOK TERSEDIA : ${sisaVPS} VPS*`;

  const keyboard = listRam.map(v => [
    { 
      text: `${v.id}. ${v.label.split("|")[0].trim()} - Rp ${v.harga.toLocaleString("id-ID")}`, 
      callback_data: `buyvps_ram:${v.plan}` 
    }
  ]);

  keyboard.push([{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "buyvps_start" }]);

  await editMenuMessage(ctx, teks, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: keyboard }
  });
});

bot.action(/buyvps_ram:(.+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_ram')) return;
  
  const plan = ctx.match[1];
  const userId = ctx.from.id;
  
  if (userState[userId]?.vpsData) {
    userState[userId].vpsData.plan = plan;
  }

  const osFamily = [
    { name: "Ubuntu", key: "ubuntu" },
    { name: "Debian", key: "debian" },
    { name: "CentOS Stream", key: "centos" },
    { name: "Fedora", key: "fedora" },
    { name: "AlmaLinux", key: "almalinux" },
    { name: "Rocky Linux", key: "rocky" },
  ];

  const keyboard = osFamily.map(os => [{
    text: os.name,
    callback_data: `buyvps_osfamily:${os.key}`
  }]);

  keyboard.push([
    { text: "🔙 Kembali", callback_data: `buyvps_pkg:${userState[userId]?.vpsData?.paket}` }
  ]);

  await editMenuMessage(ctx,
    `💾 *Spesifikasi Dipilih*: ${plan}\n\nPilih *OS Family*:`,
    {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard }
    }
  ); 
});

bot.action(/buyvps_osfamily:(.+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_osfamily')) return;
  
  const osKey = ctx.match[1];
  const userId = ctx.from.id;
  
  if (userState[userId]?.vpsData) {
    userState[userId].vpsData.osFamily = osKey;
  }

  const osVersions = {
    ubuntu: [
      { name: "Ubuntu 20.04", slug: "ubuntu-20-04-x64" },
      { name: "Ubuntu 22.04", slug: "ubuntu-22-04-x64" },
      { name: "Ubuntu 24.04", slug: "ubuntu-24-04-x64" },
    ],
    debian: [
      { name: "Debian 12", slug: "debian-12-x64" },
      { name: "Debian 13", slug: "debian-13-x64" },
    ],
    centos: [
      { name: "CentOS Stream 9", slug: "centos-stream-9-x64" },
    ],
    fedora: [
      { name: "Fedora 42", slug: "fedora-42-x64" },
    ],
    almalinux: [
      { name: "AlmaLinux 8", slug: "almalinux-8-x64" },
      { name: "AlmaLinux 9", slug: "almalinux-9-x64" },
    ],
    rocky: [
      { name: "Rocky Linux 8", slug: "rockylinux-8-x64" },
      { name: "Rocky Linux 9", slug: "rockylinux-9-x64" },
    ]
  };

  const versionList = osVersions[osKey] || [];

  const keyboard = versionList.map(v => [{
    text: v.name,
    callback_data: `buyvps_os:${v.slug}`
  }]);

  keyboard.push([
    { text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶 𝗞𝗲 𝗢𝗦 𝗙𝗮𝗺𝗶𝗹𝘆", callback_data: `buyvps_ram:${userState[userId]?.vpsData?.plan}` }
  ]);

  await editMenuMessage(ctx,
    `🖥 *OS Dipilih*: ${osKey.toUpperCase()}\n\nPilih *Versi OS*:`,
    {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard }
    }
  );
});

bot.action(/buyvps_os:(.+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_os')) return;
  
  const osSlug = ctx.match[1];
  const userId = ctx.from.id;
  
  if (userState[userId]?.vpsData) {
    userState[userId].vpsData.os = osSlug;
  }

  const regionList = [
    { name: "𝗦𝗜𝗡𝗚𝗔𝗣𝗢𝗥𝗘 (𝗥𝗘𝗖𝗢𝗠𝗘𝗡𝗗𝗘𝗗)", code: "sgp1" },
    { name: "𝗡𝗘𝗪 𝗬𝗢𝗥𝗞", code: "nyc3" },
    { name: "𝗦𝗔𝗡 𝗙𝗥𝗔𝗡𝗖𝗜𝗦𝗖𝗢", code: "sfo3" },
    { name: "𝗔𝗠𝗦𝗧𝗘𝗥𝗗𝗔𝗠", code: "ams3" },
    { name: "𝗟𝗢𝗡𝗗𝗢𝗡", code: "lon1" },
    { name: "𝗙𝗥𝗔𝗡𝗞𝗙𝗨𝗥𝗧", code: "fra1" },
  ];

  let text = `📍 *PILIH REGION VPS*\n\n`;
  regionList.forEach((r, i) => text += `${i + 1}. ${r.name}\n`);

  if (userState[userId]?.vpsData) {
    userState[userId].vpsData.regionList = regionList;
  }

  const buttons = regionList.map((r, i) => [
    { text: `${i + 1}. ${r.name}`, callback_data: `buyvps_region:${r.code}` }
  ]);

  buttons.push([
    { text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: `buyvps_osfamily:${userState[userId]?.vpsData?.osFamily}` }
  ]);

  await editMenuMessage(ctx, text, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: buttons }
  });
});

bot.action(/buyvps_region:(.+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_region')) return;
  
  const region = ctx.match[1];
  const userId = ctx.from.id;
  
  if (!userState[userId]?.vpsData) {
    return ctx.answerCbQuery("❌ Session VPS tidak ditemukan!", { show_alert: true });
  }

  const vpsData = userState[userId].vpsData;
  vpsData.region = region;

  const paket = vpsData.paket;
  const plan = vpsData.plan;
  const hargaRaw = config.hargaVPS?.[paket]?.[plan] || 0;
  
  vpsData.harga = hargaRaw;
  vpsData.username = ctx.from.username || ctx.from.first_name;

  const paketInfo = {
    low: { garansi: "7 Hari", replace: "1x" },
    medium: { garansi: "15 Hari", replace: "2x" },
    high: { garansi: "30 Hari", replace: "Unlimited" }
  };

  const specList = {
    "2c2": "2GB 2 VCPU | 60GB SSD | 3TB BW",
    "4c2": "4GB 2 VCPU | 80GB SSD | 4TB BW",
    "8c4": "8GB 4 VCPU | 160GB SSD | 5TB BW",
    "16c4": "16GB 4 VCPU | 200GB SSD | 8TB BW",
    "16c8": "16GB 8 VCPU | 320GB SSD | 6TB BW"
  };

  const labelSpec = specList[plan] || "-";
  const harga = `Rp ${hargaRaw.toLocaleString("id-ID")}`;

  await editMenuMessage(ctx,
`✅ *KONFIRMASI PEMESANAN VPS*
━━━━━━━━━━━━━━━━━━━━━━

📦 *Paket*: ${paket.toUpperCase()}
💸 *Harga*: *${harga}*

🛡️ *Garansi*: ${paketInfo[paket].garansi}
♻️ *Replace*: ${paketInfo[paket].replace}

🖥 *Spesifikasi*
• ${labelSpec}
• CPU/RAM Code: *${plan}*

🧩 *OS Family*: ${vpsData.osFamily.toUpperCase()}
🖥 *OS Version*: ${vpsData.os}
🌍 *Region*: ${region}

━━━━━━━━━━━━━━━━━━━━━━.`,
    {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "💰 𝗢𝗿𝗱𝗲𝗿 𝗩𝗽𝘀 𝗦𝗲𝗸𝗮𝗿𝗮𝗻𝗴", callback_data: "buyvps_pay_qris" }],
          [{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: `buyvps_os:${vpsData.os}` }]
        ]
      }
    }
  );
});

bot.action(/choose_service(_page_(\d+))?/, async (ctx) => {
  const page = ctx.match[2] ? parseInt(ctx.match[2]) : 1;
  const perPage = 15; // Kurangi per page untuk tampilan lebih rapi
  const apiKey = config.RUMAHOTP;

  try {
    if (!ctx.match[2]) {
       await ctx.editMessageCaption("⏳ <b>Memuat daftar layanan...</b>", { parse_mode: "HTML" }).catch(() => {});
    }

    if (globalNokos.cachedServices.length === 0) {
      const res = await axios.get("https://www.rumahotp.com/api/v2/services", { headers: { "x-apikey": apiKey } });
      if (res.data.success) globalNokos.cachedServices = res.data.data;
    }

    const services = globalNokos.cachedServices;
    const totalPages = Math.ceil(services.length / perPage);
    const start = (page - 1) * perPage;
    const list = services.slice(start, start + perPage);

    // Group services by first letter untuk tampilan lebih terorganisir
    const groupedButtons = [];
    const letters = {};
    
    list.forEach(srv => {
      const firstLetter = srv.service_name.charAt(0).toUpperCase();
      if (!letters[firstLetter]) {
        letters[firstLetter] = [];
      }
      letters[firstLetter].push(srv);
    });

    // Buat button dengan grouping yang rapi
    Object.keys(letters).forEach(letter => {
      const letterServices = letters[letter];
      letterServices.forEach(srv => {
        groupedButtons.push([{
          text: `📱 ${srv.service_name}`,
          callback_data: `service_${srv.service_code}`
        }]);
      });
    });

    // Navigation buttons dengan style baru
    const nav = [];
    if (page > 1) nav.push({ text: "⬅️ Sebelumnya", callback_data: `choose_service_page_${page - 1}` });
    if (page < totalPages) nav.push({ text: "Selanjutnya ➡️", callback_data: `choose_service_page_${page + 1}` });
    if (nav.length) groupedButtons.push(nav);

    // Tombol aksi cepat
    groupedButtons.push([
      { text: "💰 Deposit", callback_data: "topup_nokos" },
      { text: "📋 Cek Saldo", callback_data: "cek_saldo_user" }
    ]);
    
    groupedButtons.push([
      { text: "🔙 Kembali", callback_data: "shop_menu" }
    ]);

    const caption = `
<b>📱 𝗗𝗔𝗙𝗧𝗔𝗥 𝗔𝗣𝗟𝗜𝗞𝗔𝗦𝗜 𝗢𝗧𝗣</b>
━━━━━━━━━━━━━━━━━━━━━

🎯 <b>Pilih aplikasi di bawah:</b>
💡 <b>Tips:</b> Pilih yang stok banyak untuk hasil maksimal

📊 <b>Halaman:</b> ${page}/${totalPages}
📈 <b>Total Layanan:</b> ${services.length}

━━━━━━━━━━━━━━━━━━━━━`;

    globalNokos.lastServicePhoto[ctx.from.id] = { chatId: ctx.chat.id, messageId: ctx.callbackQuery.message.message_id };

    if (config.ppthumb && !ctx.match[2]) {
       await editMenuMessageWithPhoto(ctx, config.ppthumb, caption, { reply_markup: { inline_keyboard: groupedButtons } });
    } else {
       await ctx.editMessageCaption(caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: groupedButtons } });
    }

  } catch (error) {
    console.error(error);
    await ctx.answerCbQuery("❌ Gagal memuat layanan.");
  }
});

bot.action(/service_(.+)/, async (ctx) => {
  const serviceId = ctx.match[1];
  const apiKey = config.RUMAHOTP;

  await ctx.editMessageCaption("⏳ <b>Memuat negara...</b>", { parse_mode: "HTML" }).catch(() => {});

  try {
    if (!globalNokos.cachedCountries[serviceId]) {
      const res = await axios.get(`https://www.rumahotp.com/api/v2/countries?service_id=${serviceId}`, {
        headers: { "x-apikey": apiKey }
      });
      if (res.data.success) {
         globalNokos.cachedCountries[serviceId] = res.data.data.filter(x => x.pricelist && x.pricelist.length > 0);
      }
    }

    const countries = globalNokos.cachedCountries[serviceId] || [];
    if (countries.length === 0) return ctx.editMessageCaption("❌ Negara tidak tersedia.", { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{text: "🔙 Kembali", callback_data: "choose_service"}]] } });

    const slice = countries.slice(0, 20);
    
    const buttons = slice.map(c => [{
      text: `${c.name} (${c.stock_total})`,
      callback_data: `country_${serviceId}_${c.iso_code}_${c.number_id}`
    }]);

    buttons.push([{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "choose_service" }]);

    await ctx.editMessageCaption(`<b>🌍 𝗣𝗜𝗟𝗜𝗛 𝗡𝗘𝗚𝗔𝗥𝗔</b>\nLayanan ID: ${serviceId}`, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons }
    });
  } catch (e) {
    ctx.answerCbQuery("Error memuat negara");
  }
});

// ==================== TAMBAHKAN FUNGSI BARU UNTUK PILIHAN SERVER ====================
bot.action(/country_(.+)_(.+)_(.+)_server/, async (ctx) => {
  const [_, serviceId, iso, numberId] = ctx.match;
  const apiKey = config.RUMAHOTP;

  await ctx.editMessageCaption("⏳ <b>Memuat server...</b>", { parse_mode: "HTML" }).catch(() => {});

  try {
    let countryData = globalNokos.cachedCountries[serviceId]?.find(c => String(c.number_id) === String(numberId));
    
    if (!countryData) {
       const res = await axios.get(`https://www.rumahotp.com/api/v2/countries?service_id=${serviceId}`, { headers: { "x-apikey": apiKey } });
       countryData = res.data.data.find(c => String(c.number_id) === String(numberId));
    }

    if (!countryData) return ctx.answerCbQuery("Data negara tidak ditemukan");

    // Ambil semua provider yang tersedia
    const providers = (countryData.pricelist || [])
      .filter(p => p.available && p.stock > 0)
      .map(p => ({
        ...p,
        finalPrice: (parseInt(p.price) || 0) + (config.UNTUNG_NOKOS || 500)
      }))
      .sort((a, b) => a.finalPrice - b.finalPrice);

    if (providers.length === 0) {
      return ctx.editMessageCaption("❌ Tidak ada server yang tersedia untuk negara ini.", { 
        parse_mode: "HTML", 
        reply_markup: { inline_keyboard: [[{text: "🔙 Kembali", callback_data: `service_${serviceId}`}]] } 
      });
    }

    // Buat tombol untuk pilihan server
    const buttons = [];
    providers.forEach((p, index) => {
      buttons.push([{
        text: `Server ${index + 1} | ${toRupiah(p.finalPrice)} (${p.stock})`,
        callback_data: `server_detail_${numberId}_${p.provider_id}_${serviceId}_${p.finalPrice}_${index + 1}`
      }]);
    });

    // Tambahkan tombol navigasi
    buttons.push([
      { text: "⬅️ Pilih Negara Lain", callback_data: `service_${serviceId}` },
      { text: "🔙 Kembali", callback_data: `country_${serviceId}_${iso}_${numberId}` }
    ]);

    await ctx.editMessageCaption(`
<b>🖥️ 𝗣𝗜𝗟𝗜𝗛 𝗦𝗘𝗥𝗩𝗘𝗥</b>
━━━━━━━━━━━━━━━━━━━━━

🇮🇩 <b>Negara:</b> ${countryData.name}
📊 <b>Total Server:</b> ${providers.length}

💡 <b>Pilih server berdasarkan harga dan stok:</b>
• Harga termasuk keuntungan ${toRupiah(config.UNTUNG_NOKOS || 500)}
• Stok ditampilkan dalam kurung
• Server diurutkan dari termurah
━━━━━━━━━━━━━━━━━━━━━`, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons }
    });

  } catch (e) {
    console.error("Server load error:", e);
    ctx.answerCbQuery("Gagal memuat server");
  }
});

// ==================== DETAIL SERVER ====================
bot.action(/server_detail_(.+)_(.+)_(.+)_(.+)_(.+)/, async (ctx) => {
  const [_, numberId, providerId, serviceId, priceStr, serverNum] = ctx.match;
  const price = parseInt(priceStr);
  const apiKey = config.RUMAHOTP;

  try {
    let countryData = globalNokos.cachedCountries[serviceId]?.find(c => String(c.number_id) === String(numberId));
    
    if (!countryData) {
       const res = await axios.get(`https://www.rumahotp.com/api/v2/countries?service_id=${serviceId}`, { headers: { "x-apikey": apiKey } });
       countryData = res.data.data.find(c => String(c.number_id) === String(numberId));
    }

    const provider = (countryData?.pricelist || []).find(p => String(p.provider_id) === String(providerId));
    
    const buttons = [
      [{ text: "✅ Pilih Server Ini", callback_data: `buy_nokos_${numberId}_${providerId}_${serviceId}_${price}` }],
      [{ text: "📡 Pilih Operator", callback_data: `operator_${numberId}_${providerId}_${serviceId}_${price}` }],
      [
        { text: "⬅️ Lihat Server Lain", callback_data: `country_${serviceId}_${countryData?.iso_code || 'ID'}_${numberId}_server` },
        { text: "🔙 Kembali", callback_data: `country_${serviceId}_${countryData?.iso_code || 'ID'}_${numberId}` }
      ]
    ];

    await ctx.editMessageCaption(`
<b>🖥️ 𝗗𝗘𝗧𝗔𝗜𝗟 𝗦𝗘𝗥𝗩𝗘𝗥</b>
━━━━━━━━━━━━━━━━━━━━━

📡 <b>Server:</b> Server ${serverNum}
💰 <b>Harga:</b> ${toRupiah(price)}
📊 <b>Stok:</b> ${provider?.stock || 0}
🌍 <b>Negara:</b> ${countryData?.name || 'Tidak diketahui'}
🆔 <b>Provider ID:</b> ${providerId}

💡 <b>Fitur Server:</b>
• Support semua negara
• Pilihan operator lengkap
• Stok real-time
• Harga sudah termasuk fee
━━━━━━━━━━━━━━━━━━━━━`, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons }
    });

  } catch (e) {
    ctx.answerCbQuery("Gagal memuat detail server");
  }
});

// ==================== MODIFIKASI FUNGSI COUNTRY UNTUK DUA PILIHAN ====================
bot.action(/country_(.+)_(.+)_(.+)/, async (ctx) => {
  const [_, serviceId, iso, numberId] = ctx.match;
  const apiKey = config.RUMAHOTP;
  const untung = config.UNTUNG_NOKOS || 500;

  await ctx.editMessageCaption("⏳ <b>Memuat opsi...</b>", { parse_mode: "HTML" }).catch(() => {});

  try {
    let countryData = globalNokos.cachedCountries[serviceId]?.find(c => String(c.number_id) === String(numberId));
    
    if (!countryData) {
       const res = await axios.get(`https://www.rumahotp.com/api/v2/countries?service_id=${serviceId}`, { headers: { "x-apikey": apiKey } });
       countryData = res.data.data.find(c => String(c.number_id) === String(numberId));
    }

    if (!countryData) return ctx.answerCbQuery("Data negara error");

    const providers = (countryData.pricelist || [])
      .filter(p => p.available && p.stock > 0)
      .map(p => {
        const finalPrice = (parseInt(p.price) || 0) + untung;
        return { ...p, finalPrice };
      });

    if (providers.length === 0) return ctx.editMessageCaption("❌ Stok kosong untuk negara ini.", { 
      parse_mode: "HTML", 
      reply_markup: { inline_keyboard: [[{text: "🔙 Kembali", callback_data: `service_${serviceId}`}]] } 
    });

    // TAMPILAN MENU DUA PILIHAN SEPERTI DI FOTO
    const buttons = [
      [
        { 
          text: "📡 PILIH SERVER", 
          callback_data: `country_${serviceId}_${iso}_${numberId}_server` 
        }
      ],
      [
        { 
          text: "💰 PILIH HARGA LANGSUNG", 
          callback_data: `pilih_harga_direct_${serviceId}_${iso}_${numberId}` 
        }
      ],
      [{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: `service_${serviceId}` }]
    ];

    await ctx.editMessageCaption(`
<b>🎯 𝗣𝗜𝗟𝗜𝗛 𝗠𝗘𝗧𝗢𝗗𝗘 𝗢𝗥𝗗𝗘𝗥</b>
━━━━━━━━━━━━━━━━━━━━━

🌍 <b>Negara:</b> ${countryData.name}
📊 <b>Total Server Tersedia:</b> ${providers.length}
💰 <b>Rentang Harga:</b> ${toRupiah(Math.min(...providers.map(p => p.finalPrice)))} - ${toRupiah(Math.max(...providers.map(p => p.finalPrice)))}

<u><b>PILIHAN ORDER:</b></u>
1️⃣ <b>PILIH SERVER</b> - Pilih server spesifik dengan detail lengkap
2️⃣ <b>PILIH HARGA</b> - Langsung pilih harga tanpa pilih server

━━━━━━━━━━━━━━━━━━━━━
💡 <i>Rekomendasi: Pilih Server untuk kontrol penuh</i>`, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons }
    });

  } catch (e) {
    console.error("Country error:", e);
    ctx.answerCbQuery("Gagal memuat opsi");
  }
});

// ==================== PILIH HARGA DIRECT (UNTUK USER YANG MAU CEPAT) ====================
bot.action(/pilih_harga_direct_(.+)_(.+)_(.+)/, async (ctx) => {
  const [_, serviceId, iso, numberId] = ctx.match;
  const apiKey = config.RUMAHOTP;
  const untung = config.UNTUNG_NOKOS || 500;

  await ctx.editMessageCaption("⏳ <b>Memuat harga...</b>", { parse_mode: "HTML" }).catch(() => {});

  try {
    let countryData = globalNokos.cachedCountries[serviceId]?.find(c => String(c.number_id) === String(numberId));
    
    if (!countryData) {
       const res = await axios.get(`https://www.rumahotp.com/api/v2/countries?service_id=${serviceId}`, { headers: { "x-apikey": apiKey } });
       countryData = res.data.data.find(c => String(c.number_id) === String(numberId));
    }

    if (!countryData) return ctx.answerCbQuery("Data negara error");

    const providers = (countryData.pricelist || [])
      .filter(p => p.available && p.stock > 0)
      .map(p => {
        const finalPrice = (parseInt(p.price) || 0) + untung;
        return { ...p, finalPrice };
      })
      .sort((a, b) => a.finalPrice - b.finalPrice);

    if (providers.length === 0) return ctx.editMessageCaption("❌ Stok kosong untuk negara ini.", { 
      parse_mode: "HTML", 
      reply_markup: { inline_keyboard: [[{text: "🔙 Kembali", callback_data: `country_${serviceId}_${iso}_${numberId}`}]] } 
    });

    // Buat tombol harga seperti di foto
    const buttons = providers.map(p => [{
      text: `${toRupiah(p.finalPrice)} (Stok: ${p.stock})`,
      callback_data: `buy_nokos_${numberId}_${p.provider_id}_${serviceId}_${p.finalPrice}`
    }]);

    // Tambahkan tombol kembali
    buttons.push([
      { text: "⬅️ Pilih Metode Lain", callback_data: `country_${serviceId}_${iso}_${numberId}` },
      { text: "🔙 Ke Negara", callback_data: `service_${serviceId}` }
    ]);

    await ctx.editMessageCaption(`
<b>💵 𝗣𝗜𝗟𝗜𝗛 𝗛𝗔𝗥𝗚𝗔 𝗗𝗜𝗥𝗘𝗖𝗧</b>
━━━━━━━━━━━━━━━━━━━━━

🌍 <b>Negara:</b> ${countryData.name}
📊 <b>Total Opsi:</b> ${providers.length}

<u><b>Daftar Harga:</b></u>
• Harga sudah termasuk fee
• Stok ditampilkan dalam kurung
• Otomatis pilih server terbaik
━━━━━━━━━━━━━━━━━━━━━`, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons }
    });

  } catch (e) {
    ctx.answerCbQuery("Gagal memuat harga direct");
  }
});

bot.action(/buy_nokos_(.+)_(.+)_(.+)_(.+)/, async (ctx) => {
  const [_, numberId, providerId, serviceId, price] = ctx.match;
  
  const buttons = [
    [{ text: "✅ 𝗞𝗼𝗻𝗳𝗶𝗿𝗺𝗮𝘀𝗶 𝗢𝗿𝗱𝗲𝗿 (𝗥𝗮𝗻𝗱𝗼𝗺 𝗢𝗽𝗲𝗿𝗮𝘁𝗼𝗿)", callback_data: `confirm_nokos_${numberId}_${providerId}_${serviceId}_any_${price}` }],
    [{ text: "📡 𝗣𝗶𝗹𝗶𝗵 𝗢𝗽𝗲𝗿𝗮𝘁𝗼𝗿 𝗧𝗲𝗿𝘁𝗲𝗻𝘁𝘂", callback_data: `operator_${numberId}_${providerId}_${serviceId}_${price}` }],
    [{ text: "🔙 𝗕𝗮𝘁𝗮𝗹 𝗢𝗿𝗱𝗲𝗿", callback_data: "choose_service" }]
  ];

  await ctx.editMessageCaption(`<b>🛒 𝗞𝗢𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗢𝗥𝗗𝗘𝗥</b>\n└⌑ 💰 𝖧𝖺𝗋𝗀𝖺 : ${toRupiah(price)}\n\n𝖫𝖺𝗇𝗃𝗎𝗍𝗄𝖺𝗇 𝖮𝗋𝖽𝖾𝗋`, {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: buttons }
  });
});

bot.action(/operator_(.+)_(.+)_(.+)_(.+)/, async (ctx) => {
  const [_, numberId, providerId, serviceId, price] = ctx.match;
  const apiKey = config.RUMAHOTP;

  try {
     const countryData = globalNokos.cachedCountries[serviceId]?.find(c => String(c.number_id) === String(numberId));
     if (!countryData) return ctx.answerCbQuery("Data negara hilang, ulangi dari awal.");

     const res = await axios.get(`https://www.rumahotp.com/api/v2/operators?country=${encodeURIComponent(countryData.name)}&provider_id=${providerId}`, { headers: { "x-apikey": apiKey } });
     
     const ops = res.data.data || [];
     if(ops.length === 0) return ctx.answerCbQuery("Operator spesifik tidak tersedia, gunakan random.");

     const buttons = ops.map(op => [{
        text: op.name,
        callback_data: `confirm_nokos_${numberId}_${providerId}_${serviceId}_${op.id}_${price}`
     }]);
     buttons.push([{text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: `buy_nokos_${numberId}_${providerId}_${serviceId}_${price}`}]);

     await ctx.editMessageCaption(`<b>📡 𝗣𝗜𝗟𝗜𝗛 𝗢𝗣𝗘𝗥𝗔𝗧𝗢𝗥</b>\n└⌑ 𝖯𝗋𝗈𝗏𝗂𝖽𝖾𝗋 𝖨𝖣 : ${providerId}`, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: buttons }
     });

  } catch(e) {
     ctx.answerCbQuery("Gagal load operator");
  }
});

// Modifikasi fungsi confirm_nokos untuk auto refund lebih baik
bot.action(/confirm_nokos_(.+)_(.+)_(.+)_(.+)_(.+)/, async (ctx) => {
  const [_, numberId, providerId, serviceId, operatorId, priceStr] = ctx.match;
  const price = parseInt(priceStr);
  const userId = ctx.from.id;
  const apiKey = config.RUMAHOTP;

  // PERBAIKAN: Pastikan ID adalah string untuk akurasi saldo
  const saldoData = JSON.parse(fs.readFileSync("./database/saldoOtp.json", "utf8") || "{}");
  const userSaldo = saldoData[String(userId)] || 0;

  if (userSaldo < price) {
    return ctx.answerCbQuery(`🚫 Saldo tidak cukup! Butuh ${toRupiah(price)}, Saldo: ${toRupiah(userSaldo)}`, { 
      show_alert: true 
    });
  }

  const loading = await showNokosLoading(ctx, "🔄 Mencari nomor terbaik...");
  
  try {
    saldoData[String(userId)] = userSaldo - price;
    fs.writeFileSync("./database/saldoOtp.json", JSON.stringify(saldoData, null, 2));

    let url = `https://www.rumahotp.com/api/v2/orders?number_id=${numberId}&provider_id=${providerId}`;
    if (operatorId && operatorId !== 'any') {
        url += `&operator_id=${operatorId}`;
    }
    
    const res = await axios.get(url, { 
      headers: { "x-apikey": apiKey },
      timeout: 30000 
    });

    loading.stop();
    
    if (!res.data.success) {
      saldoData[String(userId)] = userSaldo; 
      fs.writeFileSync("./database/saldoOtp.json", JSON.stringify(saldoData, null, 2));
      
      const errMsg = res.data.message || res.data.msg || "Stok habis atau gangguan provider";
      
      try { await ctx.deleteMessage(loading.message.message_id); } catch (e) {}
      
      return ctx.editMessageCaption(`❌ <b>ORDER GAGAL</b>\n━━━━━━━━━━━━━━━━━━━━━\n${errMsg}\n\n✅ <b>Saldo berhasil dikembalikan</b>`, { 
        parse_mode: "HTML", 
        reply_markup: { 
          inline_keyboard: [[{ text: "🔄 Coba Lagi", callback_data: "choose_service" }]]
        } 
      });
    }

    const d = res.data.data;
    
    globalNokos.activeOrders[d.order_id] = {
      userId,
      price,
      messageId: ctx.callbackQuery.message.message_id,
      startTime: Date.now(),
      phoneNumber: d.phone_number,
      service: d.service,
      // Timer refund otomatis
      autoRefundTimer: setTimeout(async () => {
        try {
          const orderInfo = globalNokos.activeOrders[d.order_id];
          if (orderInfo) {
            const statusRes = await axios.get(`https://www.rumahotp.com/api/v1/orders/get_status?order_id=${d.order_id}`, {
              headers: { "x-apikey": apiKey }
            });
            
            if (statusRes.data.data?.status !== 'completed') {
              await axios.get(`https://www.rumahotp.com/api/v1/orders/set_status?order_id=${d.order_id}&status=cancel`, {
                headers: { "x-apikey": apiKey }
              });
              
              const refundSaldoData = JSON.parse(fs.readFileSync("./database/saldoOtp.json", "utf8") || "{}");
              refundSaldoData[String(userId)] = (refundSaldoData[String(userId)] || 0) + price;
              fs.writeFileSync("./database/saldoOtp.json", JSON.stringify(refundSaldoData, null, 2));
              
              await bot.telegram.editMessageCaption(
                ctx.chat.id,
                orderInfo.messageId,
                null,
                `⏰ <b>ORDER TIMEOUT - AUTO REFUND</b>\n━━━━━━━━━━━━━━━━━━━━━\n\n📞 Nomor: ${orderInfo.phoneNumber}\n💰 Refund: ${toRupiah(price)}\n\n✅ Saldo dikembalikan karena tidak ada OTP.`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🔄 Order Lagi", callback_data: "choose_service" }]] } }
              );
            }
            delete globalNokos.activeOrders[d.order_id];
          }
        } catch (error) {}
      }, 5 * 60 * 1000) 
    };

    // ... (Testimoni & UI Sukses tetap sama)
    const text = `✅ <b>ORDER BERHASIL!</b>\n━━━━━━━━━━━━━━━━━━━━━\n📦 <b>INFO ORDER</b>\n├─ 📱 <b>Aplikasi:</b> ${d.service}\n├─ 📞 <b>Nomor:</b> <code>${d.phone_number}</code>\n└─ 💰 <b>Harga:</b> ${toRupiah(price)}\n\n⏰ <b>AUTO REFUND:</b> 5 menit jika OTP tidak masuk.`;
    await ctx.editMessageCaption(text, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "📩 Cek SMS Sekarang", callback_data: `check_sms_${d.order_id}` }],
          [{ text: "🔄 Refresh", callback_data: `refresh_sms_${d.order_id}` }],
          [{ text: "❌ Batalkan & Refund", callback_data: `cancel_sms_${d.order_id}` }]
        ]
      }
    });

  } catch (error) {
    loading.stop();
    // Refund darurat jika sistem crash
    const saldoCurrent = JSON.parse(fs.readFileSync("./database/saldoOtp.json", "utf8") || "{}");
    saldoCurrent[String(userId)] = userSaldo;
    fs.writeFileSync("./database/saldoOtp.json", JSON.stringify(saldoCurrent, null, 2));
  }
});

// Tambah action handler untuk refresh SMS
bot.action(/refresh_sms_(.+)/, async (ctx) => {
  const orderId = ctx.match[1];
  const apiKey = config.RUMAHOTP;

  await ctx.answerCbQuery("🔄 Memperbarui status SMS...", { show_alert: false });
  
  const loading = await showNokosLoading(ctx, "Memperbarui status OTP...");
  
  try {
    const res = await axios.get(`https://www.rumahotp.com/api/v1/orders/get_status?order_id=${orderId}`, {
       headers: { "x-apikey": apiKey }
    });

    const d = res.data.data;
    
    loading.stop();
    try {
      await ctx.deleteMessage(loading.message.message_id);
    } catch (e) {}
    
    if (d.status === "completed" || (d.otp_code && d.otp_code !== "-")) {
       await ctx.editMessageCaption(`✅ <b>𝗦𝗠𝗦 𝗗𝗜𝗧𝗘𝗥𝗜𝗠𝗔!</b>\n\n📱 <b>Nomor:</b> <code>${d.phone_number}</code>\n🔑 <b>OTP:</b> <code>${d.otp_code}</code>\n\n🎉 <b>Transaksi Selesai!</b>`, { 
         parse_mode: "HTML",
         reply_markup: {
           inline_keyboard: [[
             { text: "🛒 Order Lagi", callback_data: "choose_service" },
             { text: "📱 Menu Layanan", callback_data: "shop_menu" }
           ]]
         }
       });
       delete globalNokos.activeOrders[orderId];
    } else if (d.status === 'processing') {
       await ctx.editMessageCaption(`⏳ <b>MASIH MENUNGGU SMS</b>\n\n📞 <b>Nomor:</b> <code>${d.phone_number}</code>\n🔄 <b>Status:</b> Proses menerima SMS\n\n💡 <b>Tips:</b> Tunggu 1-2 menit lagi ya!`, {
         parse_mode: "HTML",
         reply_markup: {
           inline_keyboard: [
             [{ text: "🔄 Refresh OTP", callback_data: `refresh_sms_${orderId}` }],
             [{ text: "📩 Cek SMS", callback_data: `check_sms_${orderId}` }]
           ]
         }
       });
    } else {
       await ctx.editMessageCaption(`ℹ️ <b>STATUS ORDER</b>\n\n📊 <b>Status:</b> ${d.status}\n📞 <b>Nomor:</b> ${d.phone_number || '-'}`, { parse_mode: "HTML" });
    }

  } catch(e) {
    loading.stop();
    ctx.answerCbQuery("❌ Gagal refresh status", { show_alert: true });
  }
});

// Modifikasi check_sms action untuk notifikasi lebih menarik
bot.action(/check_sms_(.+)/, async (ctx) => {
  const orderId = ctx.match[1];
  const apiKey = config.RUMAHOTP;
  const loading = await showNokosLoading(ctx, "🔍 Mencari SMS masuk...");
  
  try {
    const res = await axios.get(`https://www.rumahotp.com/api/v1/orders/get_status?order_id=${orderId}`, {
       headers: { "x-apikey": apiKey }
    });

    const d = res.data.data;
    loading.stop();
    try { await ctx.deleteMessage(loading.message.message_id); } catch (e) {}
    
    if (d.status === "completed" || (d.otp_code && d.otp_code !== "-")) {
       
       // PERBAIKAN: MATIKAN TIMER AUTO REFUND KARENA OTP SUDAH MASUK
       if (globalNokos.activeOrders[orderId]?.autoRefundTimer) {
         clearTimeout(globalNokos.activeOrders[orderId].autoRefundTimer);
         console.log(`[INFO] Auto Refund dimatikan untuk Order ID: ${orderId} (OTP Masuk)`);
       }

       await ctx.editMessageCaption(`🎉 <b>OTP DITEMUKAN!</b>\n━━━━━━━━━━━━━━━━━━━━━\n📞 <b>Nomor:</b> <code>${d.phone_number}</code>\n🔐 <b>OTP Code:</b> <code>${d.otp_code}</code>\n━━━━━━━━━━━━━━━━━━━━━`, { 
         parse_mode: "HTML",
         reply_markup: { inline_keyboard: [[{ text: "🏠 Menu", callback_data: `back_home` }]] }
       });
       
       delete globalNokos.activeOrders[orderId];
       
    } else {
       await ctx.editMessageCaption(`⏳ <b>MASIH MENUNGGU SMS</b>\n━━━━━━━━━━━━━━━━━━━━━\n📞 <b>Nomor:</b> <code>${d.phone_number}</code>\n💡 <i>Coba lagi dalam beberapa saat...</i>`, {
         parse_mode: "HTML",
         reply_markup: { inline_keyboard: [[{ text: "🔄 Cek Lagi", callback_data: `check_sms_${orderId}` }]] }
       });
    }
  } catch(e) { loading.stop(); }
});

bot.action(/cancel_sms_(.+)/, async (ctx) => {
  const orderId = ctx.match[1];
  const apiKey = config.RUMAHOTP;
  const userId = ctx.from.id;

  const orderInfo = globalNokos.activeOrders[orderId];
  if (orderInfo && (Date.now() - orderInfo.startTime < 300000)) {
      return ctx.answerCbQuery("⏳ Tunggu 5 menit baru bisa cancel!", { show_alert: true });
  }

  try {
    const res = await axios.get(`https://www.rumahotp.com/api/v1/orders/set_status?order_id=${orderId}&status=cancel`, {
       headers: { "x-apikey": apiKey }
    });

    if (res.data.success) {
       if (orderInfo) {
          const saldoData = JSON.parse(fs.readFileSync("./database/saldoOtp.json", "utf8"));
          saldoData[userId] = (saldoData[userId] || 0) + orderInfo.price;
          fs.writeFileSync("./database/saldoOtp.json", JSON.stringify(saldoData, null, 2));
          delete globalNokos.activeOrders[orderId];
       }
       await ctx.editMessageCaption("✅ <b>Order Dibatalkan & Saldo Direfund.</b>", { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{text:"🔙 Menu", callback_data:"choose_service"}]] } });
    } else {
       ctx.answerCbQuery("Gagal cancel: " + res.data.message);
    }
  } catch(e) {
    ctx.answerCbQuery("Error cancel");
  }
});

bot.action("topup_nokos", async (ctx) => {
    if (ctx.chat.type !== 'private') {
        return ctx.reply("❌ Menu deposit hanya bisa diakses via Private Chat (PC).", {
            reply_markup: {
                inline_keyboard: [[{ text: "📩 𝗖𝗵𝗮𝘁 𝗕𝗼𝘁 𝗦𝗲𝗸𝗮𝗿𝗮𝗻𝗴", url: `https://t.me/${ctx.botInfo.username}` }]]
            }
        });
    }

    const userId = ctx.from.id;
    userState[userId] = { step: "WAITING_TOPUP_PAKASIR" };

    await editMenuMessage(ctx, 
        `💰 <b>𝗗𝗘𝗣𝗢𝗦𝗜𝗧 𝗦𝗔𝗟𝗗𝗢 𝗣𝗔𝗞𝗔𝗦𝗜𝗥</b>\n\nSilakan masukkan nominal deposit (Hanya Angka).\nMinimal: Rp 2.000\n\nContoh: <code>2000</code>`, 
        {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "❌ 𝗕𝗮𝘁𝗮𝗹 𝗗𝗲𝗽𝗼𝘀𝗶𝘁", callback_data: "shop_menu" }]
                ]
            }
        }
    );
});

bot.action(/batal_depo_rumahotp_(.+)/, async (ctx) => {
   const depoId = ctx.match[1];
   const apiKey = config.RUMAHOTP;
   try {
     await axios.get(`https://www.rumahotp.com/api/v1/deposit/cancel?deposit_id=${depoId}`, { headers: { "x-apikey": apiKey } });
     await ctx.deleteMessage();
     await ctx.reply("✅ Deposit dibatalkan.", {reply_markup: {inline_keyboard: [[{text:"🔙 Menu", callback_data:"shop_menu"}]]}});
   } catch(e) {
     ctx.answerCbQuery("Gagal batal");
   }
});

bot.action(/smm_services_(\d+)/, async (ctx) => {
    const page = parseInt(ctx.match[1]);
    const perPage = 12;
    
    await ctx.answerCbQuery("⏳ Memuat layanan...", { show_alert: false });
    
    let services = [];
    try {
        const res = await callSmmApi('/services');
        console.log("[DEBUG] API Response structure:", Object.keys(res));
        
        // Handle berbagai format response
        if (res.status === true && res.data) {
            services = res.data;
        } else if (res.services) {
            services = res.services;
        } else if (Array.isArray(res)) {
            services = res;
        } else if (res.data && Array.isArray(res.data)) {
            services = res.data;
        } else {
            console.error("[ERROR] Unknown response format:", res);
            return ctx.reply("❌ Format response API tidak dikenal.");
        }
        
        console.log(`[DEBUG] Total services loaded: ${services.length}`);
        
        // Debug: Tampilkan 5 service pertama
        if (services.length > 0) {
            console.log("[DEBUG] Sample services:", services.slice(0, 3).map(s => ({ 
                id: s.id, 
                name: s.name, 
                category: s.category,
                price: s.price 
            })));
        }
        
        // Filter hanya layanan yang valid
        services = services.filter(s => {
            if (!s || typeof s !== 'object') return false;
            const hasId = s.id !== undefined && s.id !== null;
            const hasName = s.name && typeof s.name === 'string';
            const hasCategory = s.category && typeof s.category === 'string';
            return hasId && hasName && hasCategory;
        });
        
    } catch (error) {
        console.error("[SMM] Gagal load services:", error.message, error.stack);
        await ctx.answerCbQuery("❌ Gagal memuat layanan", { show_alert: true });
        return;
    }

    if (services.length === 0) {
        return ctx.reply("❌ Tidak ada layanan tersedia atau API tidak merespon.");
    }

    // Ekstrak kategori unik
    const categories = [...new Set(services
        .map(s => s.category)
        .filter(cat => cat && typeof cat === 'string')
        .map(cat => cat.trim())
    )].sort();
    
    console.log(`[DEBUG] Total categories found: ${categories.length}`);
    console.log("[DEBUG] Categories:", categories.slice(0, 5));

    const totalPages = Math.ceil(categories.length / perPage);
    const startIndex = page * perPage;
    const endIndex = startIndex + perPage;
    const paginated = categories.slice(startIndex, endIndex);

    // Validasi halaman
    if (paginated.length === 0 && page > 0) {
        return ctx.answerCbQuery("❌ Tidak ada halaman sebelumnya", { show_alert: true });
    }

    // Buat buttons
    const buttons = paginated.map((cat) => {
        const count = services.filter(s => s.category === cat).length;
        return [{
            text: `📂 ${cat} (${count})`,
            callback_data: `smm_cat_${categories.indexOf(cat)}_0`
        }];
    });

    // Navigation buttons
    const nav = [];
    if (page > 0) {
        nav.push({ 
            text: "⬅️ Sebelumnya", 
            callback_data: `smm_services_${page - 1}` 
        });
    }
    
    if (page < totalPages - 1) {
        nav.push({ 
            text: "Selanjutnya ➡️", 
            callback_data: `smm_services_${page + 1}` 
        });
    }
    
    if (nav.length > 0) {
        buttons.push(nav);
    }
    
    // Action buttons
    buttons.push([
        { text: "💰 Deposit Cepat", callback_data: "topup_nokos" },
        { text: "📋 Cek Saldo", callback_data: "cek_saldo_user" }
    ]);
    
    buttons.push([
        { text: "🔙 Menu SMM", callback_data: "smm_menu" }
    ]);

    const caption = `
<b>📂 𝗞𝗔𝗧𝗘𝗚𝗢𝗥𝗜 𝗟𝗔𝗬𝗔𝗡𝗔𝗡 𝗦𝗠𝗠</b>
━━━━━━━━━━━━━━━━━━━━━

📊 <b>Statistik:</b>
├─ 📈 Total Layanan: ${services.length}
├─ 🗂️ Total Kategori: ${categories.length}
├─ 📄 Halaman: ${page + 1}/${totalPages || 1}
└─ ⚡ Status: <code>READY</code>

🎯 <b>Pilih kategori:</b>
• Klik kategori untuk melihat layanan
• Angka dalam kurung = jumlah layanan
• Halaman berikutnya ada tombol "Selanjutnya"

━━━━━━━━━━━━━━━━━━━━━
📌 <i>${paginated.length} kategori ditampilkan</i>`;

    try {
        await editMenuMessage(ctx, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: buttons }
        });
    } catch (error) {
        console.error("[ERROR] Failed to edit message:", error.message);
        // Fallback: kirim pesan baru
        await ctx.reply(caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: buttons }
        });
    }
});

bot.action(/pay_panel_(\d+)_(\d+)_(.+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'pay_panel')) return;
  
  const ram = parseInt(ctx.match[1]);
  const price = parseInt(ctx.match[2]);
  const username = ctx.match[3];

  await handlePayment(ctx, price, `Panel ${ram === 0 ? "Unlimited" : ram/1024 + "GB"}`, {
    type: "panel",
    username: username,
    ram: ram,
    price: price
  });
});

bot.action(/smm_cat_(\d+)_(\d+)/, async (ctx) => {
    const catIndex = parseInt(ctx.match[1]);
    const page = parseInt(ctx.match[2]);
    const perPage = 8; // Naikkan ke 8 layanan per halaman
    
    await ctx.answerCbQuery("⏳ Memuat layanan...", { show_alert: false });
    
    let allServices = [];
    try {
        const res = await callSmmApi('/services');
        
        // Parsing response
        if (res.status === true && res.data) {
            allServices = res.data;
        } else if (res.services) {
            allServices = res.services;
        } else if (Array.isArray(res)) {
            allServices = res;
        } else if (res.data && Array.isArray(res.data)) {
            allServices = res.data;
        }
        
    } catch (error) {
        console.error("[SMM] Error loading services:", error);
        return ctx.answerCbQuery("❌ Gagal memuat data", { show_alert: true });
    }
    
    // Get all unique categories
    const categories = [...new Set(allServices
        .filter(s => s && s.category)
        .map(s => s.category.trim())
    )].sort();
    
    const targetCat = categories[catIndex];
    
    if (!targetCat) {
        return ctx.answerCbQuery("❌ Kategori tidak ditemukan", { show_alert: true });
    }
    
    // Filter services by category
    const filtered = allServices
        .filter(s => s && s.category && s.category.trim() === targetCat)
        .sort((a, b) => {
            // Sort by ID
            const idA = parseInt(a.id) || 0;
            const idB = parseInt(b.id) || 0;
            return idA - idB;
        });
    
    if (filtered.length === 0) {
        return ctx.editMessageText(
            `❌ <b>Tidak ada layanan di kategori:</b> ${targetCat}`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "🔙 Kembali ke Kategori", callback_data: "smm_services_0" }]
                    ]
                }
            }
        );
    }
    
    const totalPages = Math.ceil(filtered.length / perPage);
    const currentPage = page;
    const startIndex = currentPage * perPage;
    const endIndex = startIndex + perPage;
    const paginated = filtered.slice(startIndex, endIndex);
    
    // Validasi halaman
    if (paginated.length === 0 && currentPage > 0) {
        return ctx.answerCbQuery("❌ Tidak ada halaman sebelumnya", { show_alert: true });
    }
    
    // Build informasi header singkat
    let text = `<b>📦 ${targetCat.toUpperCase()}</b>\n`;
    text += `📊 Total: ${filtered.length} layanan\n`;
    text += `📄 Halaman: ${currentPage + 1}/${totalPages}\n`;
    text += `━━━━━━━━━━━━━━━━━━━━━\n\n`;
    
    // Tampilkan daftar layanan secara ringkas
    text += `<b>📋 DAFTAR LAYANAN:</b>\n\n`;
    
    paginated.forEach((service, index) => {
        const serviceNumber = startIndex + index + 1;
        const serviceId = service.id || 'N/A';
        const serviceName = service.name || 'Tanpa Nama';
        const servicePrice = service.price ? toRupiah(service.price) : 'Rp 0';
        
        // Format ringkas
        text += `<b>${serviceNumber}. 🆔 ${serviceId}</b>\n`;
        text += `├─ ${serviceName}\n`;
        text += `└─ ${servicePrice}/1000\n\n`;
    });
    
    text += `━━━━━━━━━━━━━━━━━━━━━\n`;
    text += `<i>📌 Klik tombol untuk detail & order</i>`;
    
    // Build buttons - Satu tombol per layanan dengan format: ID - Harga
    const buttons = paginated.map(service => {
        const serviceId = service.id;
        const servicePrice = service.price ? toRupiah(service.price) : 'Rp 0';
        const serviceName = service.name || '';
        
        // Buat teks tombol yang singkat
        let buttonText = `🆔 ${serviceId}`;
        if (serviceName.length > 0) {
            // Ambil 2 kata pertama dari nama
            const shortName = serviceName.split(' ').slice(0, 2).join(' ');
            buttonText += ` - ${shortName}`;
        }
        buttonText += ` - ${servicePrice}`;
        
        // Potong jika terlalu panjang
        if (buttonText.length > 35) {
            buttonText = buttonText.substring(0, 32) + '...';
        }
        
        return [{
            text: buttonText,
            callback_data: `smm_buy_${serviceId}`
        }];
    });
    
    // Navigation buttons
    const nav = [];
    if (currentPage > 0) {
        nav.push({ 
            text: "⬅️ Prev", 
            callback_data: `smm_cat_${catIndex}_${currentPage - 1}` 
        });
    }
    
    if (nav.length < 2 && currentPage < totalPages - 1) {
        nav.push({ 
            text: "Next ➡️", 
            callback_data: `smm_cat_${catIndex}_${currentPage + 1}` 
        });
    }
    
    if (nav.length > 0) buttons.push(nav);
    
    // Action buttons
    buttons.push([
        { text: "💰 Deposit", callback_data: "topup_nokos" },
        { text: "📋 Cek Saldo", callback_data: "cek_saldo_user" }
    ]);
    
    buttons.push([
        { text: "🔙 Kategori", callback_data: "smm_services_0" },
        { text: "🏠 Menu", callback_data: "smm_menu" }
    ]);
    
    try { 
        await ctx.deleteMessage(); 
    } catch(e){
        console.log("[DEBUG] Tidak bisa hapus pesan, lanjut...");
    }
    
    await ctx.reply(text, { 
        parse_mode: "HTML", 
        reply_markup: { inline_keyboard: buttons },
        disable_web_page_preview: true
    });
});

bot.action(/smm_buy_(\d+)/, async (ctx) => {
    const serviceId = ctx.match[1];
    
    // Cek service info dengan cepat
    let serviceInfo = null;
    try {
        const res = await callSmmApi('/services');
        let services = [];
        
        if (res.status === true && res.data) {
            services = res.data;
        } else if (res.services) {
            services = res.services;
        } else if (Array.isArray(res)) {
            services = res;
        }
        
        serviceInfo = services.find(s => s.id == serviceId);
    } catch (error) {
        console.error("[SMM] Error getting service info:", error);
    }
    
    if (!serviceInfo) {
        return ctx.answerCbQuery("❌ Layanan tidak ditemukan", { show_alert: true });
    }
    
    // Format informasi layanan yang lengkap
    const infoText = `
<b>📋 𝗗𝗘𝗧𝗔𝗜𝗟 𝗟𝗔𝗬𝗔𝗡𝗔𝗡</b>
━━━━━━━━━━━━━━━━━━━━━

<b>🆔 ID Layanan:</b> <code>${serviceInfo.id}</code>
<b>🏷️ Nama:</b> ${serviceInfo.name || 'Tidak tersedia'}
<b>🗂️ Kategori:</b> ${serviceInfo.category || 'Tidak tersedia'}
<b>💰 Harga:</b> ${toRupiah(serviceInfo.price || 0)} / 1000 unit
━━━━━━━━━━━━━━━━━━━━━
<b>💡 Contoh Perhitungan:</b>
• Order 1000 unit = ${toRupiah(serviceInfo.price || 0)}
<i>📌 Pastikan saldo mencukupi sebelum order</i>`;

    // Set state dengan data yang lengkap
    userState[ctx.from.id] = { 
        step: "SMM_WAITING_LINK", 
        serviceId: serviceId,
        serviceInfo: serviceInfo
    };
    
    await editMenuMessage(ctx, 
        `${infoText}\n\n` +
        `<b>🔗 𝗠𝗔𝗦𝗨𝗞𝗞𝗔𝗡 𝗟𝗜𝗡𝗞 𝗧𝗔𝗥𝗚𝗘𝗧</b>\n\n` +
        `Silakan kirim link/username target untuk layanan di atas.\n\n` +
        `<i>Ketik /batal untuk membatalkan.</i>`, 
        {
            parse_mode: "HTML",
            reply_markup: { 
                inline_keyboard: [
                    [{ text: "💰 Cek Saldo Saya", callback_data: "cek_saldo_user" }],
                    [{ text: "❌ 𝗕𝗮𝘁𝗮𝗹𝗸𝗮𝗻", callback_data: `smm_cat_0_0` }]
                ] 
            },
            disable_web_page_preview: true
        }
    );
});

bot.action("smm_history", async (ctx) => {
    const history = getSmmHistory(ctx.from.id);
    
    if (history.length === 0) {
        return ctx.answerCbQuery("📭 Belum ada riwayat order.", { show_alert: true });
    }

    // Ambil 10 riwayat terbaru
    const recentHistory = history.slice(0, 10);
    
    let msg = "<b>📜 𝗥𝗜𝗪𝗔𝗬𝗔𝗧 𝗢𝗥𝗗𝗘𝗥 𝗧𝗘𝗥𝗔𝗞𝗛𝗜𝗥</b>\n";
    msg += `📊 <b>Total:</b> ${history.length} order\n`;
    msg += "━━━━━━━━━━━━━━━━━━━━━\n\n";
    
    recentHistory.forEach((h, i) => {
        const statusIcon = h.status === "success" ? "✅" : "⏳";
        msg += `${statusIcon} <b>Order #${i + 1}</b>\n`;
        msg += `├─ 🆔 <b>ID:</b> <code>${h.orderId || '-'}</code>\n`;
        msg += `├─ 📦 <b>Layanan:</b> ${h.serviceName || '-'}\n`;
        msg += `├─ 💰 <b>Harga:</b> ${h.price || '0'}\n`;
        if (h.quantity) msg += `├─ 🔢 <b>Jumlah:</b> ${h.quantity}\n`;
        msg += `└─ 📅 <b>Waktu:</b> ${h.date || '-'}\n\n`;
    });

    await editMenuMessage(ctx, msg, {
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [
                    { text: "🔄 Refresh", callback_data: "smm_history" },
                    { text: "📋 Cek Status", callback_data: "smm_check_status" }
                ],
                [
                    { text: "🔙 Menu SMM", callback_data: "smm_menu" }
                ]
            ]
        }
    });
});

bot.action("smm_check_status", (ctx) => {
    userState[ctx.from.id] = { step: "SMM_WAITING_STATUS_ID" };
    
    ctx.reply(
        `<b>🔍 𝗖𝗘𝗞 𝗦𝗧𝗔𝗧𝗨𝗦 𝗢𝗥𝗗𝗘𝗥</b>\n\n` +
        `Silakan kirim ID Order yang ingin dicek:\n\n` +
        `<i>Contoh: 123456789</i>\n` +
        `<i>ID Order bisa dilihat di riwayat order</i>`,
        {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "📜 Lihat Riwayat", callback_data: "smm_history" }],
                    [{ text: "❌ Batalkan", callback_data: "smm_menu" }]
                ]
            }
        }
    );
});

bot.action("smm_exec_order", async (ctx) => {
    const userId = ctx.from.id;
    const pending = userState[userId]?.pendingOrder;

    if (!pending) {
        return ctx.answerCbQuery("❌ Sesi habis, silakan ulangi dari awal.", { show_alert: true });
    }

    // Cek saldo dengan cepat
    const dbSaldoPath = "./database/saldoOtp.json";
    const saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8") || "{}");
    const userSaldo = saldoData[userId] || 0;

    if (userSaldo < pending.price) {
        return ctx.answerCbQuery(`❌ Saldo tidak cukup! Butuh ${toRupiah(pending.price)}, Saldo: ${toRupiah(userSaldo)}`, { 
            show_alert: true 
        });
    }

    // Loading indicator
    await ctx.editMessageText("⏳ <b>MEMPERSIAPKAN ORDER...</b>\n\n" +
        "📊 <b>Detail Order:</b>\n" +
        `├─ Layanan: ${pending.serviceName}\n` +
        `├─ Target: ${pending.target.substring(0, 30)}${pending.target.length > 30 ? '...' : ''}\n` +
        `├─ Jumlah: ${pending.quantity}\n` +
        `└─ Total: ${toRupiah(pending.price)}\n\n` +
        "<i>Mohon tunggu, proses maksimal 1 menit...</i>", { 
        parse_mode: "HTML" 
    });

    // Proses order dengan timeout
    const orderPromise = callSmmApi('/order', {
        service: pending.serviceId,
        target: pending.target,
        quantity: pending.quantity
    });

    // Timeout handling
    const timeoutPromise = new Promise((resolve) => {
        setTimeout(() => resolve({ status: false, msg: "Timeout: Server tidak merespon" }), 30000);
    });

    let orderRes;
    try {
        orderRes = await Promise.race([orderPromise, timeoutPromise]);
    } catch (error) {
        orderRes = { status: false, msg: error.message };
    }

    if (orderRes.status === true) {
        // Potong saldo
        saldoData[userId] = userSaldo - pending.price;
        fs.writeFileSync(dbSaldoPath, JSON.stringify(saldoData, null, 2));

        const orderId = orderRes.order;
        
        // Simpan history dengan data lengkap
        saveSmmHistory(userId, {
            orderId: orderId,
            serviceName: pending.serviceName,
            target: pending.target,
            quantity: pending.quantity,
            price: toRupiah(pending.price),
            date: new Date().toLocaleString("id-ID"),
            status: "success"
        });
        
        // TAMBAHKAN TESTIMONI SMM
        try {
          await sendTestimoniKeChannel(
            ctx.from.first_name || ctx.from.username || "User",
            ctx.from.id,
            pending.serviceName,
            pending.price,
            "smm",
            {
              orderId: orderId,
              quantity: pending.quantity,
              target: pending.target.substring(0, 50) + (pending.target.length > 50 ? '...' : ''),
              customerNote: `Order SMM ${pending.serviceName} berhasil diproses`
            }
          );
        } catch (error) {
          console.error("[TESTIMONI] Gagal kirim testimoni SMM:", error.message);
        }

        // Update UI dengan informasi lengkap
        const successText = `
✅ <b>𝗢𝗥𝗗𝗘𝗥 𝗦𝗨𝗞𝗦𝗘𝗦!</b>
━━━━━━━━━━━━━━━━━━━━━

<b>📋 𝗗𝗘𝗧𝗔𝗜𝗟 𝗢𝗥𝗗𝗘𝗥</b>
├─ 🆔 <b>ID Order:</b> <code>${orderId}</code>
├─ 📦 <b>Layanan:</b> ${pending.serviceName}
├─ 🔗 <b>Target:</b> ${pending.target.substring(0, 50)}${pending.target.length > 50 ? '...' : ''}
├─ 🔢 <b>Jumlah:</b> ${pending.quantity}
├─ 💰 <b>Harga:</b> ${toRupiah(pending.price)}
├─ 💳 <b>Sisa Saldo:</b> ${toRupiah(saldoData[userId])}
└─ ⏰ <b>Waktu:</b> ${new Date().toLocaleTimeString()}

<b>📌 𝗣𝗔𝗡𝗗𝗨𝗔𝗡</b>
• Order akan diproses dalam 1-10 menit
• Cek status dengan klik tombol di bawah
• Untuk masalah, hubungi owner
• Simpan ID order untuk tracking

━━━━━━━━━━━━━━━━━━━━━
🎉 <b>TERIMA KASIH TELAH ORDER!</b>`;

        await ctx.editMessageText(successText, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "🔍 Cek Status", callback_data: `smm_check_specific_${orderId}` },
                        { text: "📜 Riwayat", callback_data: "smm_history" }
                    ],
                    [
                        { text: "🔄 Order Lagi", callback_data: "smm_services_0" },
                        { text: "💰 Deposit", callback_data: "topup_nokos" }
                    ],
                    [
                        { text: "🔙 Menu Utama", callback_data: "shop_menu" }
                    ]
                ]
            }
        });

        // Notify owner
        try {
            await bot.telegram.sendMessage(
                config.ownerId,
                `📦 <b>ORDER SMM BARU</b>\n\n` +
                `👤 <b>User:</b> ${ctx.from.first_name || 'User'} (${userId})\n` +
                `🆔 <b>Order ID:</b> ${orderId}\n` +
                `📦 <b>Layanan:</b> ${pending.serviceName}\n` +
                `💰 <b>Total:</b> ${toRupiah(pending.price)}\n` +
                `⏰ <b>Waktu:</b> ${new Date().toLocaleString()}`,
                { parse_mode: "HTML" }
            );
        } catch (notifyErr) {
            console.error("[SMM] Gagal notify owner:", notifyErr.message);
        }

    } else {
        const errorMsg = orderRes.msg || "Gagal memproses order";
        
        await ctx.editMessageText(
            `❌ <b>𝗢𝗥𝗗𝗘𝗥 𝗚𝗔𝗚𝗔𝗟!</b>\n━━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Alasan:</b> ${errorMsg}\n\n` +
            `<i>Saldo tidak terpotong, silakan coba lagi.</i>`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "🔄 Coba Lagi", callback_data: "smm_services_0" }],
                        [{ text: "🔙 Menu SMM", callback_data: "smm_menu" }]
                    ]
                }
            }
        );
    }

    // Cleanup
    delete userState[userId];
});

// Tambahkan action untuk cek status spesifik
bot.action(/smm_check_specific_(.+)/, async (ctx) => {
    const orderId = ctx.match[1];
    await ctx.answerCbQuery("⏳ Mengecek status...", { show_alert: false });
    
    const res = await callSmmApi('/status', { id: orderId });
    
    if (res.status === true) {
        const statusText = `
<b>📊 𝗦𝗧𝗔𝗧𝗨𝗦 𝗢𝗥𝗗𝗘𝗥 #${orderId}</b>
━━━━━━━━━━━━━━━━━━━━━
📈 <b>Status:</b> ${res.data?.status || res.order_status || 'Unknown'}
▶️ <b>Start:</b> ${res.data?.start_count || '0'}
⏸️ <b>Remains:</b> ${res.data?.remains || '0'}
━━━━━━━━━━━━━━━━━━━━━
<i>Update terakhir: ${new Date().toLocaleTimeString()}</i>`;
        
        await ctx.editMessageText(statusText, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "🔄 Refresh", callback_data: `smm_check_specific_${orderId}` }],
                    [{ text: "🔙 Kembali", callback_data: "smm_menu" }]
                ]
            }
        });
    } else {
        ctx.answerCbQuery("❌ Order tidak ditemukan", { show_alert: true });
    }
});

bot.action("add_script", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  userState[ctx.from.id] = { step: "WAITING_SCRIPT_FILE" };
  safeReply(ctx, `<blockquote><b>📥 𝗖𝗔𝗥𝗔 𝗠𝗘𝗡𝗔𝗠𝗕𝗔𝗛𝗞𝗔𝗡 𝗦𝗖𝗥𝗜𝗣𝗧</b>\n<b>├⌑ 𝖪𝗂𝗋𝗂𝗆 𝖥𝗂𝗅𝖾 𝖲𝖼𝗋𝗂𝗉𝗍 (𝖶𝖺𝗃𝗂𝖻 .𝗓𝗂𝗉) </b>\n<b>└⌑ 𝖩𝗂𝗄𝖺 𝖲𝗎𝖽𝖺𝗁, 𝖡𝗈𝗍 𝖠𝗄𝖺𝗇 𝖬𝖾𝗆𝗂𝗇𝗍𝖺 𝖣𝖾𝗍𝖺𝗂𝗅 𝖲𝖼𝗋𝗂𝗉𝗍</b></blockquote>`,
    { parse_mode: "HTML", ...Markup.inlineKeyboard([[Markup.button.callback("🔙 𝗕𝗮𝘁𝗮𝗹 𝗠𝗲𝗻𝗮𝗺𝗯𝗮𝗵𝗸𝗮𝗻 𝗦𝗰𝗿𝗶𝗽𝘁", "menu_owner")]]) }
  );
});

bot.action("add_app", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  userState[ctx.from.id] = { step: "WAITING_APP_TEXT" };
  safeReply(ctx, "<blockquote><b>✏️ 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗞𝗶𝗿𝗶𝗺 𝗔𝗽𝗽𝘀 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗗𝗲𝗻𝗴𝗮𝗻 𝗙𝗼𝗿𝗺𝗮𝘁 :</b>\n<code>└⌑ 𝖭𝖺𝗆𝖺 | 𝖧𝖺𝗋𝗀𝖺 | 𝖣𝖾𝗌𝗄𝗋𝗂𝗉𝗌𝗂</code>\n\n<b>🍂 𝖤𝗑𝖺𝗆𝗉𝗅𝖾 :</b>\n<code>𝖢𝖠𝖭𝖵𝖠 𝖯𝖱𝖮 | 𝟥𝟢𝟢𝟢 | 𝖠𝗄𝗌𝖾𝗌 𝖯𝗋𝖾𝗆𝗂𝗎𝗆 𝖠𝖼𝗍𝗂𝗏𝖾</code></blockquote>", { parse_mode: "HTML" });
});

bot.action("del_script", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  const db = readDb();
  if (db.scripts.length === 0) return ctx.editMessageText("Belum ada produk script.", Markup.inlineKeyboard([[Markup.button.callback("🔙 Kembali", "menu_owner")]]));

  const buttons = db.scripts.map((sc, i) => [Markup.button.callback(`❌ ${sc.nama}`, `delete_sc_${i}`)]);
  buttons.push([Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "menu_owner")]);
  ctx.editMessageText("<blockquote><b>🗑️ 𝗣𝗶𝗹𝗶𝗵 𝗦𝗰𝗿𝗶𝗽𝘁 𝗬𝗮𝗻𝗴 𝗜𝗻𝗴𝗶𝗻 𝗔𝗻𝗱𝗮 𝗛𝗮𝗽𝘂𝘀 :</b></blockquote>", { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) })
    .catch(() => {
      safeReply(ctx, "<blockquote><b>🗑️ 𝗣𝗶𝗹𝗶𝗵 𝗦𝗰𝗿𝗶𝗽𝘁 𝗬𝗮𝗻𝗴 𝗜𝗻𝗴𝗶𝗻 𝗔𝗻𝗱𝗮 𝗛𝗮𝗽𝘂𝘀 :</b></blockquote>", { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
    });
});

bot.action("del_app", (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  const db = readDb();
  if ((db.apps || []).length === 0) return ctx.editMessageText("Belum ada app.", Markup.inlineKeyboard([[Markup.button.callback("🔙 Kembali", "menu_owner")]]));

  const buttons = db.apps.map((a, i) => [Markup.button.callback(`❌ ${a.nama}`, `delete_app_${i}`)]);
  buttons.push([Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "menu_owner")]);
  ctx.editMessageText("<blockquote><b>🗑️ 𝗣𝗶𝗹𝗶𝗵 𝗔𝗽𝗽𝘀 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗬𝗮𝗻𝗴 𝗜𝗻𝗴𝗶𝗻 𝗗𝗶𝗵𝗮𝗽𝘂𝘀 :</b></blockquote>", { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
});

bot.action("list_apps", (ctx) => {
  const db = readDb();
  if ((db.apps || []).length === 0) return safeReply(ctx, "Tidak ada app.");
  const isOwner = ctx.from.id === config.ownerId;
  db.apps.forEach((x, i) => {
    const stock = (x.accounts || []).length;
    const text = `<blockquote><b>📱 ${x.nama}</b>\n<b>├⌑ 💰 𝖧𝖺𝗋𝗀𝖺 :</b> ${toRupiah(x.harga)}\n<b>└⌑ 📦 𝖲𝗍𝗈𝖼𝗄 :</b> ${stock}\n${x.deskripsi || ''}</blockquote>`;
    const buttons = [];
    if (isOwner) {
      buttons.push([ Markup.button.callback("📄 𝗟𝗶𝘀𝘁 𝗔𝗰𝗰𝗼𝘂𝗻𝘁", `list_accounts_${i}`) ]);
    }
    safeReply(ctx, text, { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
  });
});

bot.action("buyvps_pay_qris", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buyvps_pay_qris')) return;
  
  const userId = ctx.from.id;
  
  if (!userState[userId]?.vpsData) {
    return ctx.answerCbQuery("❌ 𝗗𝗮𝘁𝗮 𝗩𝗽𝘀 𝗧𝗶𝗱𝗮𝗸 𝗗𝗶𝘁𝗲𝗺𝘂𝗸𝗮𝗻!", { show_alert: true });
  }

  const vpsData = userState[userId].vpsData;
  const nominal = vpsData.harga;
  const itemName = `VPS ${vpsData.paket.toUpperCase()} - ${vpsData.plan} - ${vpsData.region}`;

  await handlePayment(ctx, nominal, itemName, {
    type: "vps",
    vpsData: vpsData
  });
});

bot.action(/buy_sc_(\d+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buy_sc')) return;
  
  const index = parseInt(ctx.match[1]);
  const db = readDb();
  const item = db.scripts[index];
  if (!item || !item.file_id) return safeReply(ctx, "Script tidak ditemukan/file hilang.");
  
  await handlePayment(ctx, item.harga, "Script: " + item.nama, {
    type: "script",
    index: index
  });
});

bot.action(/buy_app_(\d+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buy_app')) return;
  
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  const app = db.apps[idx];
  if (!app) return ctx.answerCbQuery("❌ akun tidak ditemukan.");
  const stock = (app.accounts || []).length;
  if (stock <= 0) return ctx.answerCbQuery("❌ Stock habis.");

  userState[ctx.from.id] = {
    step: "PURCHASE_APP",
    appIndex: idx,
    qty: 1,
    message: null
  };

  const base = parseInt(app.harga) || 0;
  const qty = 1;
  const total = calcTotalPrice(base, qty);
  const caption = renderPurchaseText(app, qty, total);
  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [ 
          { text: "➖", callback_data: `app_qty_minus_${idx}` }, 
          { text: `${qty}`, callback_data: `app_qty_show_${idx}` }, 
          { text: "➕", callback_data: `app_qty_plus_${idx}` } 
        ],
        [ { text: "🛒 𝗢𝗿𝗱𝗲𝗿 𝗦𝗲𝗸𝗮𝗿𝗮𝗻𝗴", callback_data: `app_buy_now_${idx}` } ],
        [ { text: "🔙 𝗕𝗮𝘁𝗮𝗹 𝗢𝗿𝗱𝗲𝗿", callback_data: "back_home" } ]
      ]
    }
  };

  await editMenuMessage(ctx, caption, {
    parse_mode: "HTML",
    ...keyboard
  });
  
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/app_qty_minus_(\d+)/, async (ctx) => {
  const uid = ctx.from.id;
  const idx = parseInt(ctx.match[1]);
  if (!userState[uid] || userState[uid].step !== "PURCHASE_APP" || userState[uid].appIndex !== idx) {
    userState[uid] = { step: "PURCHASE_APP", appIndex: idx, qty: 1, message: null };
  }
  const db = readDb();
  const app = db.apps[idx];
  if (!app) {
    ctx.answerCbQuery("🚫 𝗮𝗸u𝗻 𝗱𝗶𝗴𝗶𝘁𝗮𝗹 𝗼𝗰𝗲𝗮𝗻 𝗯𝗹𝗺 𝘀𝘁𝗼𝗸.");
    return;
  }
  userState[uid].qty = Math.max(1, (userState[uid].qty || 1) - 1);
  const qty = userState[uid].qty;
  const base = parseInt(app.harga) || 0;
  const stock = (app.accounts || []).length;
  if (qty > stock) userState[uid].qty = stock;
  const total = calcTotalPrice(base, userState[uid].qty);
  const caption = renderPurchaseText(app, userState[uid].qty, total);

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [ 
          { text: "➖", callback_data: `app_qty_minus_${idx}` }, 
          { text: `${userState[uid].qty}`, callback_data: `app_qty_show_${idx}` }, 
          { text: "➕", callback_data: `app_qty_plus_${idx}` } 
        ],
        [ { text: "🛒 Buy Now", callback_data: `app_buy_now_${idx}` } ],
        [ { text: "🔙 Batal", callback_data: "back_home" } ]
      ]
    }
  };

  await editMenuMessage(ctx, caption, {
    parse_mode: "HTML",
    ...keyboard
  });
  
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/app_qty_plus_(\d+)/, async (ctx) => {
  const uid = ctx.from.id;
  const idx = parseInt(ctx.match[1]);
  if (!userState[uid] || userState[uid].step !== "PURCHASE_APP" || userState[uid].appIndex !== idx) {
    userState[uid] = { step: "PURCHASE_APP", appIndex: idx, qty: 1, message: null };
  }
  const db = readDb();
  const app = db.apps[idx];
  if (!app) {
    ctx.answerCbQuery("🚫 𝗽𝗿𝗼𝗱𝘂𝗸 𝗼𝗰𝗲𝗮𝗻 𝗧𝗶𝗱𝗮𝗸 𝗗𝗶𝘁𝗲𝗺𝘂𝗸𝗮𝗻");
    return;
  }
  const stock = (app.accounts || []).length;
  userState[uid].qty = (userState[uid].qty || 1) + 1;
  if (userState[uid].qty > stock) userState[uid].qty = stock;
  const total = calcTotalPrice(parseInt(app.harga) || 0, userState[uid].qty);
  const caption = renderPurchaseText(app, userState[uid].qty, total);

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [ 
          { text: "➖", callback_data: `app_qty_minus_${idx}` }, 
          { text: `${userState[uid].qty}`, callback_data: `app_qty_show_${idx}` }, 
          { text: "➕", callback_data: `app_qty_plus_${idx}` } 
        ],
        [ { text: "🛒 𝗢𝗿𝗱𝗲𝗿 𝗦𝗲𝗸𝗮𝗿𝗮𝗻𝗴", callback_data: `app_buy_now_${idx}` } ],
        [ { text: "🔙 𝗕𝗮𝘁𝗮𝗹 𝗢𝗿𝗱𝗲𝗿", callback_data: "back_home" } ]
      ]
    }
  };

  await editMenuMessage(ctx, caption, {
    parse_mode: "HTML",
    ...keyboard
  });
  
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/app_qty_show_(\d+)/, (ctx) => {
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/app_buy_now_(\d+)/, async (ctx) => {
  if (!await requirePrivateChat(ctx, 'app_buy_now')) return;
  
  const uid = ctx.from.id;
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  const app = db.apps[idx];
  if (!app) return ctx.answerCbQuery("🚫 𝗮𝗸𝘂𝗻 𝗧𝗶𝗱𝗮𝗸 𝗗𝗶𝘁𝗲𝗺𝘂𝗸𝗮𝗻.");
  const stock = (app.accounts || []).length;
  const st = userState[uid];
  if (!st || st.step !== "PURCHASE_APP" || st.appIndex !== idx) {
    userState[uid] = { step: "PURCHASE_APP", appIndex: idx, qty: 1, message: null };
  }
  const qty = Math.max(1, userState[uid].qty || 1);
  if (qty > stock) return ctx.answerCbQuery("🚫 𝗝𝘂𝗺𝗹𝗮𝗵 𝗗𝗲𝗽𝗼𝘀𝗶𝘁 𝗠𝗲𝗹𝗲𝗯𝗶𝗵𝗶 𝗦𝘁𝗼𝗰𝗸.");
  const total = calcTotalPrice(parseInt(app.harga) || 0, qty);

  await handlePayment(ctx, total, ` ${app.nama} x${qty}`, {
    type: "akun",
    idx: idx,
    qty: qty,
    total: total
  });

  ctx.answerCbQuery().catch(()=>{});
});

bot.action("buy_reseller_panel", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buy_reseller_panel')) return;

  const harga = config.hargaResellerPanel || 25000;

  await editMenuMessage(ctx,
    `<blockquote><b>🤝 𝗔𝗞𝗦𝗘𝗦 𝗥𝗘𝗦𝗘𝗟𝗟𝗘𝗥 𝗣𝗔𝗡𝗘𝗟</b>
━━━━━━━━━━━━━━━━━━━━━━━━
<b>💎 𝗞𝗲𝘂𝗻𝘁𝘂𝗻𝗴𝗮𝗻 𝗝𝗼𝗶𝗻 𝗥𝗲𝘀𝘀𝗲𝗹𝗲𝗿 𝗣𝗮𝗻𝗲𝗹:</b>
├≫ 𝖧𝖺𝗋𝗀𝖺 𝖳𝖾𝗋𝗃𝖺𝗇𝗀𝗄𝖺𝗎 𝖴𝗇𝗍𝗎𝗄 𝖯𝖾𝗆𝗎𝗅𝖺
├≫ 𝖡𝗂𝗌𝖺 𝖬𝖾𝗇𝗃𝗎𝖺𝗅 𝖯𝖺𝗇𝖾𝗅 𝖪𝖾𝗆𝖻𝖺𝗅𝗂
├≫ 𝖡𝗂𝗌𝖺 𝖮𝗉𝖾𝗇 𝖩𝖺𝗌𝖺 𝖲𝖾𝗐𝖺 𝖡𝗈𝗍
├≫ 𝖡𝗂𝗌𝖺 𝖮𝗉𝖾𝗇 𝖩𝖺𝗌𝖺 𝖱𝗎𝗇 𝖡𝗈𝗍
└≫ 𝖩𝖺𝗆𝗂𝗇 𝖡𝖺𝗅𝗆𝗈𝖽 𝖪𝖺𝗅𝗈 𝖠𝖽𝖺 𝖴𝗌𝖺𝗁𝖺

<b>💰 𝗛𝗮𝗿𝗴𝗮 𝗝𝗼𝗶𝗻 :</b> ${toRupiah(harga)}
<i>╰┈⸙ 𝖢𝗎𝗄𝗎𝗉 𝖡𝖺𝗒𝖺𝗋 𝖲𝖾𝗄𝖺𝗅𝗂 𝖲𝖺𝗃𝖺
𝖳𝖾𝗍𝖺𝗉𝗂 𝖣𝗎𝗋𝖺𝗌𝗂 𝖯𝖾𝗋𝗆𝖺𝗇𝖾𝗇</i>
━━━━━━━━━━━━━━━━━━━━━━
<b>🚀 𝖲𝗂𝗅𝖺𝗁𝗄𝖺𝗇 𝖳𝖾𝗄𝖺𝗇 𝖲𝖺𝗅𝖺𝗁 𝖲𝖺𝗍𝗎 𝖡𝗎𝗍𝗍𝗈𝗇
𝖣𝗂𝖻𝖺𝗐𝖺𝗁 𝖨𝗇𝗂 𝖴𝗇𝗍𝗎𝗄 𝖬𝖾𝗅𝖺𝗇𝗃𝗎𝗍𝗄𝖺𝗇 :</b></blockquote>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "✅ 𝗞𝗼𝗻𝗳𝗼𝗿𝗺𝗮𝘀𝗶 𝗢𝗿𝗱𝗲𝗿", callback_data: "pay_reseller_panel" }],
          [{ text: "❌ 𝗕𝗮𝘁𝗮𝗹 𝗢𝗿𝗱𝗲𝗿", callback_data: "shop_menu" }]
        ]
      }
    }
  );
});

bot.action("pay_reseller_panel", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'pay_reseller_panel')) return;

  const harga = config.hargaResellerPanel || 25000;

  try { await ctx.deleteMessage(); } catch (e) {}

  await handlePayment(ctx, harga, "Akses Reseller Panel", {
    type: "reseller_panel",
    price: harga
  });
});

bot.action("buy_admin_panel", async (ctx) => {
  if (!await requirePrivateChat(ctx, 'buy_admin_panel')) return;

  userState[ctx.from.id] = { step: "WAITING_USERNAME_ADMIN_PANEL" };

  await editMenuMessage(ctx,
    `<b>🛠️ 𝗕𝗘𝗟𝗜 𝗔𝗗𝗠𝗜𝗡 𝗣𝗔𝗡𝗘𝗟</b>\n\n` +
    `Harga: <b>${toRupiah(config.hargaAdminPanel)}</b>\n` +
    `Benefit: Akun Root Admin (Full Akses)\n\n` +
    `<i>Silahkan Kirim Username Untuk Akun Admin Kamu (Min 5 Huruf)...</i>`,
    {
      reply_markup: {
        inline_keyboard: [
          [{ text: "❌ 𝗕𝗮𝘁𝗮𝗹 𝗢𝗿𝗱𝗲𝗿", callback_data: "shop_menu" }]
        ]
      }
    }
  );
});

bot.on('audio', async (ctx) => {
  console.log('Audio File ID:', ctx.message.audio.file_id);
  console.log('Audio Metadata:', {
    title: ctx.message.audio.title,
    performer: ctx.message.audio.performer,
    duration: ctx.message.audio.duration
  });
});

bot.on("text", async (ctx, next) => {
  const userId = ctx.from.id;
  const text = ctx.message.text;

  if (["📁 ☇ 𝗦𝗰𝗿𝗶𝗽𝘁", "📱 ☇ 𝗔𝗽𝗽𝘀", "📡 ☇ 𝗣𝗮𝗻𝗲𝗹", "🛠 ☇ 𝗧𝗼𝗼𝗹𝘀", "🌸 ☇ 𝗢𝘄𝗻𝗲𝗿"].includes(text)) {
    return next();
  }
  if (userState[userId]?.step === "WAITING_USERNAME_ADMIN_PANEL") {
    if (ctx.chat.type !== 'private') return next();

    if (!/^[a-zA-Z0-9]+$/.test(text)) {
        return ctx.reply("<blockquote>⚠️ <b>Username hanya boleh huruf & angka!</b></blockquote>", { 
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "❌ Batalkan", callback_data: "shop_menu" }]] }
        });
    }

    const username = text;
    delete userState[userId].step;
    
    const harga = config.hargaAdminPanel;

    await handlePayment(ctx, harga, `Admin Panel (${username})`, {
        type: "admin_panel",
        username: username,
        price: harga
    });
    return;
  }
  
  if (userState[userId]?.step === "WAITING_USERNAME_PANEL") {
    if (ctx.chat.type !== 'private') return next();

    if (!/^[a-zA-Z0-9]+$/.test(text)) {
        return ctx.reply("<blockquote>⚠️ <b>Username hanya boleh huruf & angka!</b></blockquote>", { 
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "❌ Batalkan", callback_data: "back_home" }]] }
        });
    }

    const username = text;
    delete userState[userId].step;

    const hargaGb = config.hargaPanel.perGB;
    const hargaUnli = config.hargaPanel.unlimited;

    let listRam = [];

    for (let gb = 1; gb <= 10; gb++) {
        const ramMB = gb * 1024;
        const price = gb * hargaGb;

        listRam.push({
            label: `${gb}GB - ${toRupiah(price)}`,
            ram: ramMB,
            price
        });
    }

    listRam.push({
        label: `UNLIMITED (${toRupiah(hargaUnli)})`,
        ram: 0,
        price: hargaUnli
    });

    const buttons = listRam.map(p => {
        return [{ text: p.label, callback_data: `pay_panel_${p.ram}_${p.price}_${username}` }];
    });

    buttons.push([{ text: "🔙 𝗕𝗮𝘁𝗮𝗹", callback_data: "back_home" }]);

    return ctx.reply(
        `<blockquote><b>📡 𝗣𝗶𝗹𝗶𝗵 𝗦𝗽𝗲𝘀𝗶𝗳𝗶𝗸𝗮𝘀𝗶 𝗨𝗻𝘁𝘂𝗸 𝗣𝗮𝗻𝗲𝗹 ${username}</b></blockquote>`,
        {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: buttons }
        }
    );
  }

  if (userState[userId]?.step === "SMM_WAITING_LINK") {
    if (ctx.chat.type !== 'private') return next();

    const link = text;
    userState[userId].link = link;
    userState[userId].step = "SMM_WAITING_QTY";
    
    return ctx.reply("🔢 <b>𝗠𝗔𝗦𝗨𝗞𝗔𝗡 𝗝𝗨𝗠𝗟𝗔𝗛 :</b>\n\n└⌑ 𝖤𝗑𝖺𝗆𝗉𝗅𝖾 : 𝟣𝟢𝟢𝟢", {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[Markup.button.callback('❌ 𝗕𝗮𝘁𝗮𝗹𝗸𝗮𝗻', 'smm_menu')]] }
    });
  }

  if (userState[userId]?.step === "SMM_WAITING_QTY" && ctx.chat.type === 'private') {
    const qty = parseInt(text);
    if (isNaN(qty) || qty <= 0) return next();

    const state = userState[userId];
    const res = await callSmmApi('/services');
    let services = res.services || res.data || [];
    const service = services.find(s => s.id == state.serviceId);
    
    if (!service) return ctx.reply("❌ Layanan tidak ditemukan.");

    const totalPrice = (parseFloat(service.price) / 1000) * qty;
    
    // PERBAIKAN: Pastikan ID adalah string saat cek saldo SMM
    const dbSaldoPath = "./database/saldoOtp.json";
    const saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8") || "{}");
    const userSaldo = saldoData[String(userId)] || 0;

    if (userSaldo < totalPrice) {
        // Logika detail deteksi saldo diperbaiki di sini
        return ctx.reply(`<blockquote>❌ <b>SALDO TIDAK CUKUP!</b>\n\n💰 <b>Butuh:</b> ${toRupiah(totalPrice)}\n💳 <b>Saldo Kamu:</b> ${toRupiah(userSaldo)}\n\n<i>Silahkan deposit terlebih dahulu.</i></blockquote>`, { 
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: '➕ Isi Saldo', callback_data: 'topup_nokos' }]] }
        });
    }

    // ... (Sisa kode SMM tetap sama)
    userState[userId].pendingOrder = {
        serviceId: state.serviceId,
        serviceName: service.name,
        target: state.link,
        quantity: qty,
        price: totalPrice
    };

    await ctx.reply(
        `🚀 <b>𝗞𝗢𝗡𝗙𝗜𝗥𝗠𝗔𝗦𝗜 𝗣𝗘𝗦𝗔𝗡𝗔𝗡</b>\n\n` +
        `├⌑ 📦 <b>𝖫𝖺𝗒𝖺𝗇𝖺𝗇 :</b> ${service.name}\n` +
        `├⌑ 🔗 <b>𝖳𝖺𝗋𝗀𝖾𝗍 :</b> ${state.link}\n` +
        `├⌑ 🔢 <b>𝖩𝗎𝗆𝗅𝖺𝗁 :</b> ${qty}\n` +
        `└⌑ 💰 <b>𝖳𝗈𝗍𝖺𝗅 𝖧𝖺𝗋𝗀𝖺 :</b> ${toRupiah(totalPrice)}\n\n` +
        `<i>📝 𝖭𝗈𝗍𝖾 : 𝖲𝗂𝗅𝖺𝗁𝗄𝖺𝗇 𝖯𝖺𝗌𝗍𝗂𝗄𝖺𝗇 𝖯𝖾𝗌𝖺𝗇𝖺𝗇 𝖡𝖾𝗇𝖺𝗋 𝖲𝖾𝖻𝖾𝗅𝗎𝗆 𝖫𝖺𝗇𝗃𝗎𝗍!</i>`,
        {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "✅ 𝗞𝗼𝗻𝗳𝗶𝗿𝗺𝗮𝘀𝗶 𝗢𝗿𝗱𝗲𝗿", callback_data: "smm_exec_order" }],
                    [{ text: "❌ 𝗕𝗮𝘁𝗮𝗹𝗸𝗮𝗻", callback_data: "smm_menu" }]
                ]
            }
        }
    );
    return;
  }

  if (userState[userId]?.step === "SMM_WAITING_STATUS_ID") {
      if (ctx.chat.type !== 'private') return next();

      const orderId = text;
      const res = await callSmmApi('/status', { id: orderId });
      
      if (res.status === true) {
          ctx.reply(`📊 <b>𝗦𝗧𝗔𝗧𝗨𝗦 𝗢𝗥𝗗𝗘𝗥 #${orderId}</b>\n├⌑ 𝖲𝗍𝖺𝗍𝗎𝗌 :<b>${res.data?.status || res.order_status}</b>\n├⌑ 𝖲𝗍𝖺𝗋𝗍 : ${res.data?.start_count || '-'}\n└⌑ 𝖲𝗂𝗌𝖺 : ${res.data?.remains || '-'}`, { parse_mode: "HTML" });
      } else {
          ctx.reply("❌ 𝗗𝗮𝘁𝗮 𝗧𝗶𝗱𝗮𝗸 𝗗𝗶𝘁𝗲𝗺𝘂𝗸𝗮𝗻/𝗘𝗿𝗿𝗼𝗿.", { parse_mode: "HTML" });
      }
      delete userState[userId];
      return;
  }
  
  if (userState[userId]?.step === "WAITING_TOPUP_PAKASIR") {
    if (ctx.chat.type !== 'private') return next();

    const amount = parseInt(text);
    
    if (isNaN(amount) || amount < 2000) {
       return safeReply(ctx, "❌ <b>Minimal deposit Rp 2.000 dan harus angka!</b>", {
           parse_mode: "HTML",
           reply_markup: { inline_keyboard: [[{ text: "❌ 𝗕𝗮𝘁𝗮𝗹𝗸𝗮𝗻", callback_data: "shop_menu" }]] }
       });
    }
    
    delete userState[userId];

    const loading = await safeReply(ctx, "🔄 <b>𝗠𝗘𝗠𝗕𝗨𝗔𝗧 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𝗣𝗔𝗞𝗔𝗦𝗜𝗥...</b>", { parse_mode: "HTML" });
    
    try {
        // Konfigurasi Pakasir
        const pakasirConfig = {
            method: "pakasir",
            pakasir: {
                slug: config.payment?.pakasir?.slug || config.pakasir?.slug,
                apiKey: config.payment?.pakasir?.apiKey || config.pakasir?.apiKey
            }
        };
        
        // Tambah fee (untuk keuntungan)
        const fee = Math.floor(Math.random() * 0) + 0; // Random 500-600
        const totalBayar = amount + fee;
        
        // Buat transaksi Pakasir
        const qrisData = await createdQris(totalBayar, pakasirConfig);
        
        await ctx.deleteMessage(loading.message_id).catch(() => {});
        
        if (!qrisData) {
            return safeReply(ctx, "❌ <b>Gagal membuat pembayaran Pakasir. Silakan coba lagi.</b>", {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "shop_menu" }]] }
            });
        }
        
        // Debug info
        console.log("[DEBUG] Pakasir QRIS Data:", {
            hasImage: !!qrisData.imageqris,
            imageType: typeof qrisData.imageqris,
            isBuffer: qrisData.imageqris instanceof Buffer,
            isString: typeof qrisData.imageqris === 'string',
            hasQrString: !!qrisData.qr_string,
            qrisData: qrisData
        });
        
        let msgSent = null;
        
        // Coba tampilkan QRIS jika ada gambar
        if (qrisData.imageqris) {
            // Jika ada gambar QRIS
            if (qrisData.imageqris instanceof Buffer) {
                console.log("[DEBUG] QRIS adalah Buffer, size:", qrisData.imageqris.length);
                try {
                    msgSent = await ctx.replyWithPhoto({ source: qrisData.imageqris }, {
                        caption: `<blockquote><b>💳 TAGIHAN DEPOSIT </b>\n\n💰 <b>Total Bayar:</b> <b>${toRupiah(totalBayar)}</b>\n📥 <b>Saldo Masuk:</b> ${toRupiah(amount)}\n🔖 <b>Biaya Admin:</b> Free\n\n⚠️ <b>Bayar sesuai nominal TOTAL (sampai digit terakhir)!</b>\n<i>Otomatis cek status setiap 5 detik...</i></blockquote>`,
                        parse_mode: "HTML",
                        reply_markup: { 
                            inline_keyboard: [
                                [{ text: "❌ 𝗕𝗮𝘁𝗮𝗹𝗸𝗮𝗻", callback_data: `batal_deposit_pakasir_${qrisData.idtransaksi || qrisData.id}` }]
                            ]
                        }
                    });
                } catch (photoError) {
                    console.error("[ERROR] Failed to send photo:", photoError.message);
                }
                
            } else if (typeof qrisData.imageqris === 'string' && qrisData.imageqris.startsWith('http')) {
                // Download gambar dari URL
                console.log("[DEBUG] QRIS adalah URL:", qrisData.imageqris);
                try {
                    const { downloadQrisImage } = require("./lib/payment");
                    const qrBuffer = await downloadQrisImage(qrisData.imageqris);
                    if (qrBuffer) {
                        console.log("[DEBUG] QRIS downloaded successfully, size:", qrBuffer.length);
                        msgSent = await ctx.replyWithPhoto({ source: qrBuffer }, {
                            caption: `<blockquote><b>💳 TAGIHAN DEPOSIT </b>\n\n💰 <b>Total Bayar:</b> <b>${toRupiah(totalBayar)}</b>\n📥 <b>Saldo Masuk:</b> ${toRupiah(amount)}\n🔖 <b>Layanan Apikey:</b> ${toRupiah(fee)}\n\n⚠️ <b>Bayar sesuai nominal TOTAL (sampai digit terakhir)!</b>\n<i>Otomatis cek status setiap 5 detik...</i></blockquote>`,
                            parse_mode: "HTML",
                            reply_markup: { 
                                inline_keyboard: [
                                    [{ text: "❌ 𝗕𝗮𝘁𝗮𝗹𝗸𝗮𝗻", callback_data: `batal_deposit_pakasir_${qrisData.idtransaksi || qrisData.id}` }]
                                ]
                            }
                        });
                    }
                } catch (downloadErr) {
                    console.error("[ERROR] Failed to download QRIS image:", downloadErr.message);
                }
            }
        }
        
        // Jika tidak berhasil mengirim foto, coba dengan QR string
        if (!msgSent && qrisData.qr_string && qrisData.qr_string.trim().length > 0) {
            console.log("[DEBUG] Using QR string for display");
            try {
                // Coba buat QR lokal
                const qrBuffer = await generateLocalQr(qrisData.qr_string);
                if (qrBuffer) {
                    msgSent = await ctx.replyWithPhoto({ source: qrBuffer }, {
                        caption: `<blockquote><b>💳 TAGIHAN DEPOSIT PAKASIR</b>\n\n💰 <b>Total Bayar:</b> <b>${toRupiah(totalBayar)}</b>\n📥 <b>Saldo Masuk:</b> ${toRupiah(amount)}\n🔖 <b>Biaya Admin:</b> ${toRupiah(fee)}\n\n⚠️ <b>Bayar sesuai nominal TOTAL (sampai digit terakhir)!</b>\n<i>Otomatis cek status setiap 5 detik...</i></blockquote>`,
                        parse_mode: "HTML",
                        reply_markup: { 
                            inline_keyboard: [
                                [{ text: "❌ 𝗕𝗮𝘁𝗮𝗹𝗸𝗮𝗻", callback_data: `batal_deposit_pakasir_${qrisData.idtransaksi || qrisData.id}` }]
                            ]
                        }
                    });
                }
            } catch (qrErr) {
                console.error("[ERROR] Failed to generate local QR:", qrErr.message);
            }
        }
        
        // Jika masih tidak berhasil, tampilkan teks saja
        if (!msgSent) {
            console.log("[DEBUG] Falling back to text message");
            const qrDisplay = qrisData.qr_string ? 
                `<b>QR String:</b>\n<code>${qrisData.qr_string}</code>\n\n` : 
                "";
            
            msgSent = await safeReply(ctx, 
                `<blockquote><b>💳 TAGIHAN DEPOSIT PAKASIR</b>\n\n💰 <b>Total Bayar:</b> <b>${toRupiah(totalBayar)}</b>\n📥 <b>Saldo Masuk:</b> ${toRupiah(amount)}\n🔖 <b>Biaya Admin:</b> ${toRupiah(fee)}\n\n${qrDisplay}⚠️ <b>Bayar sesuai nominal TOTAL!</b>\n<i>Otomatis cek status setiap 5 detik...</i></blockquote>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { 
                        inline_keyboard: [
                            [{ text: "❌ 𝗕𝗮𝘁𝗮𝗹𝗸𝗮𝗻", callback_data: `batal_deposit_pakasir_${qrisData.idtransaksi || qrisData.id}` }]
                        ]
                    }
                }
            );
        }
        
        if (msgSent) {
            activeTransactions[userId] = { 
                id: qrisData.idtransaksi || qrisData.id, 
                amount: totalBayar,
                depositAmount: amount,
                status: 'pending',
                messageId: msgSent.message_id,
                paymentMethod: "pakasir",
                paymentConfig: pakasirConfig,
                type: "deposit"
            };
            
            // Mulai pengecekan status pembayaran
            startDepositCheck(ctx, userId, qrisData, pakasirConfig, amount);
        } else {
            throw new Error("Failed to create payment message");
        }
        
    } catch (error) {
        console.error("[ERROR] Pakasir deposit error:", error);
        await ctx.deleteMessage(loading.message_id).catch(() => {});
        safeReply(ctx, `❌ <b>Gagal membuat pembayaran Pakasir:</b> ${error.message}\n\nSilakan coba lagi atau hubungi owner.`, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "shop_menu" }]] }
        });
    }
    return;
}
  
      if (userState[userId]?.step === "WAITING_PANEL_USERNAME") {
      if (ctx.chat.type !== 'private') return next();
    
      const username = text.trim();
      
      // Validasi username
      if (!/^[a-zA-Z0-9]{5,20}$/.test(username)) {
        return safeReply(ctx, `<b>❌ USERNAME TIDAK VALID!</b>\n\nHarus 5-20 karakter, hanya huruf dan angka.\n\n<i>Contoh: botpanel01, mypaneluser</i>\n\nSilakan coba lagi:`, {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [[{ text: "❌ Batalkan", callback_data: "menu_panel" }]]
          }
        });
      }
      
      // Simpan username
      userState[userId].panelUsername = username;
      delete userState[userId].step;
      
      // Ambil data paket
      const panelOrder = userState[userId]?.panelOrder;
      if (!panelOrder) {
        return safeReply(ctx, "❌ Data paket tidak ditemukan.", {
          parse_mode: "HTML"
        });
      }
      
      // Tampilkan konfirmasi final
      const pkg = config.panel?.packages?.[panelOrder.pkgIndex];
      const isUnlimited = pkg?.ram === 0;
      const ramText = isUnlimited ? "♾️ UNLIMITED" : `${Math.floor(pkg.ram / 1024)} GB`;
      const diskText = isUnlimited ? "♾️ UNLIMITED" : `${Math.floor(pkg.disk / 1024)} GB`;
      const cpuText = isUnlimited ? "♾️ UNLIMITED" : `${pkg.cpu}%`;
      
      await ctx.replyWithPhoto(
        config.panel?.menuPhoto || config.startPhoto,
        {
          caption: `
    <b>✅ KONFIRMASI ORDER PANEL</b>
    ━━━━━━━━━━━━━━━━━━━━━
    
    <b>👤 DATA AKUN:</b>
    ├─ Username: <code>${username}</code>
    ├─ Email: <code>${username.toLowerCase()}@gmail.com</code>
    
    <b>📦 PAKET:</b> ${pkg?.name || '-'}
    <b>💰 HARGA:</b> ${toRupiah(panelOrder.price)}
    
    <b>⚙️ SPESIFIKASI:</b>
    ├─ 🎮 RAM: ${ramText}
    ├─ 💾 Disk: ${diskText}
    ├─ ⚡ CPU: ${cpuText}
    └─ 🔌 Network: 1 Gbps
    
    <b>📝 PROSES ORDER:</b>
    1. Klik tombol "💰 Bayar Sekarang"
    2. Selesaikan pembayaran
    3. Panel otomatis dibuat (2-5 menit)
    4. Detail login dikirim ke chat ini
    
    ━━━━━━━━━━━━━━━━━━━━━
    <i>Lanjutkan ke pembayaran?</i>`,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "💰 Bayar Sekarang", callback_data: `pay_panel_${panelOrder.ram}_${panelOrder.price}_${username}` },
                { text: "❌ Batalkan", callback_data: "menu_panel" }
              ],
              [
                { text: "💰 Deposit Saldo", callback_data: "topup_nokos" },
                { text: "📋 Cek Saldo", callback_data: "cek_saldo_user" }
              ]
            ]
          }
        }
      );
      
      return;
    }

  if (userState[userId]?.step === "WAITING_SCRIPT_DETAIL") {
    if (ctx.chat.type !== 'private') return next();

    const state = userState[userId];
    const parts = text.split("|").map(x => x.trim());
    
    if (parts.length !== 3) {
        return safeReply(ctx, "<blockquote>❌ Format detail salah! Gunakan: Nama | Harga (angka) | Deskripsi</blockquote>", { 
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "❌ Batalkan", callback_data: "menu_owner" }]] }
        });
    }
    
    const [nama, hargaStr, deskripsi] = parts;
    const harga = parseInt(hargaStr);
    
    if (isNaN(harga) || harga <= 0) {
        return safeReply(ctx, "<blockquote>❌ Harga harus angka positif!</blockquote>", { 
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "❌ Batalkan", callback_data: "menu_owner" }]] }
        });
    }
    
    try {
        const db = readDb();
        const scriptData = {
        nama: nama,
        harga: harga,
        deskripsi: deskripsi,
        file_id: state.file_id, 
        fileName: state.temp_fileName 
        };
        
        db.scripts.push(scriptData);
        saveDb(db);
        
        // 🔔 KIRIM NOTIFIKASI KE CHANNEL DAN SEMUA USER
    const newScriptIndex = db.scripts.length - 1;
    await sendScriptNotificationToChannel(newScriptIndex);
    await sendScriptNotificationToAllUsers(newScriptIndex);
    
        const addedBy = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
        
        
        safeReply(ctx, `<blockquote><b>✅ Sukses Menambah Script!</b>\n\n<b>📂 Nama:</b> <code>${nama}</code>\n<b>💰 Harga:</b> <code>${toRupiah(harga)}</code>\n<b>📄 File:</b> <code>${state.temp_fileName}</code>\n\n</blockquote>`, { 
        parse_mode: "HTML" 
        });
        
    } catch (e) {
        console.error(e);
        safeReply(ctx, "❌ Gagal menyimpan data script ke database.");
    }
    
    delete userState[userId];
    return;
  }

  if (userState[userId]?.step === "WAITING_APP_TEXT") {
    if (userId !== config.ownerId) return next();
    if (ctx.chat.type !== 'private') return next();
    
    const parts = text.split("|").map(x => x.trim());
    
    if (parts.length !== 3) {
        return safeReply(ctx, "<blockquote>❌ Format salah! Gunakan: Nama | Harga | Deskripsi</blockquote>", { 
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "❌ Batalkan", callback_data: "menu_owner" }]] }
        });
    }
    
    const [nama, hargaStr, deskripsi] = parts;
    const harga = parseInt(hargaStr);
    
    if (isNaN(harga) || harga <= 0) {
        return safeReply(ctx, "<blockquote>❌ Harga harus angka positif!</blockquote>", { 
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "❌ Batalkan", callback_data: "menu_owner" }]] }
        });
    }
    
    try {
        const db = readDb();
        const newApp = {
        nama,
        harga,
        deskripsi,
        accounts: [] 
        };
        
        db.apps.push(newApp);
        saveDb(db);
        const idx = db.apps.length - 1;
        
        const addedBy = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
        
        
        await safeReply(ctx, `<blockquote><b>✅ App Premium ditambahkan!</b>\n<b>📱 ${nama}</b>\n<b>Stock:</b> 0\n\n</blockquote>`, {
        parse_mode: "HTML",
        ...Markup.inlineKeyboard([
            [ Markup.button.callback("📄 List Account", `list_accounts_${idx}`) ],
            [ Markup.button.callback("🔙 Kembali ke Owner Menu", "menu_owner") ]
        ])
        });
        
    } catch (e) {
        console.error(e);
        safeReply(ctx, "❌ Gagal menyimpan data app ke database.");
    }
    
    delete userState[userId];
    return;
  }

  if (userState[userId]?.step === "WAITING_ADD_ACCOUNT") {
    if (userId !== config.ownerId) return next();
    if (ctx.chat.type !== 'private') return next();
    
    const st = userState[userId];
    const parts = text.split("|").map(x => x.trim());
    
    if (parts.length !== 4) {
        return safeReply(ctx, "<blockquote>❌ Format salah! Gunakan: username|password|link akses|deskripsi</blockquote>", { 
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "❌ Batalkan", callback_data: "menu_owner" }]] }
        });
    }
    
    const [usernameA, passwordA, linkA, descA] = parts;
    
    try {
        const db = readDb();
        const app = db.apps[st.appIndex];
        
        if (!app) {
        return safeReply(ctx, "❌ App tidak ditemukan / sudah dihapus.");
        }
        
        app.accounts = app.accounts || [];
        app.accounts.push({ 
        user: usernameA, 
        pass: passwordA, 
        link: linkA, 
        desc: descA 
        });
        
        saveDb(db);
        const stockNow = app.accounts.length;
        
        const addedBy = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
        const accountData = {
        appName: app.nama,
        username: usernameA,
        password: passwordA,
        link: linkA,
        desc: descA,
        newStock: stockNow
        };
        
        
        safeReply(ctx, `<blockquote><b>✅ Akun ditambahkan!</b>\n<b>Stock sekarang:</b> ${stockNow}\n\n</blockquote>`, {
        parse_mode: "HTML",
        ...Markup.inlineKeyboard([
            [ Markup.button.callback("➕ Tambah lagi", `owner_add_account`) ],
            [ Markup.button.callback("📃 List App Premium", "list_apps") ],
            [ Markup.button.callback("🔙 Kembali ke Owner Menu", "menu_owner") ]
        ])
        });
        
    } catch (e) {
        console.error(e);
        safeReply(ctx, "❌ Gagal menambahkan akun ke database.");
    }
    
    delete userState[userId];
    return;
  }

  if (userState[ctx.from.id]?.step === "WAITING_BROADCAST" && ctx.from.id === config.ownerId) {
    if (ctx.chat.type !== 'private') return next();

    const users = loadUsers();
    let sent = 0;
    for (const uid of users) {
      try {
        if (ctx.message.photo) {
          await bot.telegram.sendPhoto(uid, ctx.message.photo[0].file_id, { caption: ctx.message.caption || "", parse_mode: "HTML" });
        } else if (ctx.message.document) {
          await bot.telegram.sendDocument(uid, ctx.message.document.file_id, { caption: ctx.message.caption || "", parse_mode: "HTML" });
        } else {
          await bot.telegram.sendMessage(uid, ctx.message.text);
        }
        sent++;
      } catch (e) {}
    }
    delete userState[ctx.from.id];
    return safeReply(ctx, `<blockquote>📢 <b>Broadcast selesai!</b> <b>Terkirim:</b> ${sent}</blockquote>`, { parse_mode: "HTML" });
  }

  return next();
});

async function startDepositCheck(ctx, userId, qrisData, paymentConfig, depositAmount) {
  console.log(`[DEBUG] Starting deposit check for user ${userId}:`, qrisData.idtransaksi || qrisData.id);
  
  let attempts = 0;
  const maxAttempts = 72; // 6 menit (72 * 5 detik)
  
  const interval = setInterval(async () => {
    attempts++;
    
    if (!activeTransactions[userId]) {
      console.log(`[DEBUG] Deposit ${userId} cancelled, stopping check`);
      clearInterval(interval);
      return;
    }
    
    if (attempts > maxAttempts) {
      console.log(`[DEBUG] Deposit timeout for user ${userId} after ${attempts} attempts`);
      clearInterval(interval);
      
      if (activeTransactions[userId]) {
        try {
          if (activeTransactions[userId].messageId) {
            await ctx.deleteMessage(activeTransactions[userId].messageId).catch(() => {});
          }
        } catch (e) {}
        
        delete activeTransactions[userId];
        await safeReply(ctx, "<blockquote>❌ <b>Waktu deposit habis.</b> Silakan ulangi transaksi.</blockquote>", { 
          parse_mode: "HTML" 
        });
      }
      return;
    }
    
    try {
      console.log(`[DEBUG] Checking deposit status for user ${userId}, attempt ${attempts}`);
      
      const isPaid = await cekStatus(
        qrisData.idtransaksi || qrisData.id, 
        activeTransactions[userId].amount, 
        paymentConfig
      );
      
      if (isPaid) {
        console.log(`[DEBUG] Deposit confirmed for user ${userId}`);
        clearInterval(interval);
        
        // Hapus pesan pembayaran
        try {
          if (activeTransactions[userId]?.messageId) {
            await ctx.deleteMessage(activeTransactions[userId].messageId).catch(() => {});
          }
        } catch (e) {}
        
        // Tambah saldo ke database
        const dbPath = "./database/saldoOtp.json";
        let saldoDB = {};
        try { 
          saldoDB = JSON.parse(fs.readFileSync(dbPath, "utf8")); 
        } catch(e){ 
          saldoDB = {}; 
        }
        
        saldoDB[userId] = (saldoDB[userId] || 0) + depositAmount;
        fs.writeFileSync(dbPath, JSON.stringify(saldoDB, null, 2));
        
        // Kirim notifikasi ke owner
        const userName = `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim();
        const userUsername = ctx.from.username ? `@${ctx.from.username}` : "-";
        
        try {
          await bot.telegram.sendMessage(
            config.ownerId,
            `<b>💰 DEPOSIT SUKSES (PAKASIR)</b>\n\n` +
            `<b>👤 User:</b> ${userName} (${userId})\n` +
            `<b>📛 Username:</b> ${userUsername}\n` +
            `<b>💵 Jumlah:</b> ${toRupiah(depositAmount)}\n` +
            `<b>💰 Total Bayar:</b> ${toRupiah(activeTransactions[userId].amount)}\n` +
            `<b>⏰ Waktu:</b> ${new Date().toLocaleString()}`,
            { parse_mode: "HTML" }
          );
        } catch (ownerErr) {
          console.error("[ERROR] Failed to notify owner:", ownerErr.message);
        }
        
        // Kirim testimoni deposit
        sendTestimoniKeChannel(userName, userId, "Deposit Saldo", depositAmount, "deposit");
        
        // Hapus transaksi dari daftar aktif
        delete activeTransactions[userId];
        
        // Kirim konfirmasi ke user
        await safeReply(ctx, 
          `<blockquote>✅ <b>DEPOSIT SUKSES!</b></blockquote>\n\n` +
          `<blockquote>💰 <b>Diterima:</b> ${toRupiah(depositAmount)}\n` +
          `<b>💼 Total Saldo:</b> ${toRupiah(saldoDB[userId])}\n\n` +
          `<i>📝 Saldo sudah bisa digunakan untuk order nokos, SMM, dan layanan lainnya.</i></blockquote>`, 
          {
            parse_mode: "HTML",
            reply_markup: {
              inline_keyboard: [
                [{ text: "📱 Order Nokos", callback_data: "nokos_guide" }],
                [{ text: "💰 Cek Saldo", callback_data: "cek_saldo_user" }],
                [{ text: "🛒 Menu Layanan", callback_data: "shop_menu" }]
              ]
            }
          }
        );
        
      } else {
        console.log(`[DEBUG] Deposit not yet confirmed for user ${userId}`);
      }
      
    } catch (error) {
      console.error(`[ERROR] Error checking deposit status for user ${userId}:`, error.message);
      
      if (attempts > 10) {
        clearInterval(interval);
        console.error(`[ERROR] Too many errors, stopping check for user ${userId}`);
        
        if (activeTransactions[userId]) {
          delete activeTransactions[userId];
          await safeReply(ctx, "<blockquote>⚠️ <b>Terjadi gangguan sistem deposit.</b> Silakan hubungi owner.</blockquote>", { 
            parse_mode: "HTML" 
          });
        }
      }
    }
  }, 5000); // Cek setiap 5 detik
}

async function processPaymentWithSaldo(ctx, userId, nominal, itemName, extraData) {
    const dbSaldoPath = "./database/saldoOtp.json";
    const saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8") || "{}");
    const userSaldo = saldoData[userId] || 0;
    
    if (userSaldo < nominal) {
        return ctx.answerCbQuery(`❌ Saldo tidak cukup! Butuh ${toRupiah(nominal)}, Saldo: ${toRupiah(userSaldo)}`, { 
            show_alert: true 
        });
    }
    
    // Potong saldo
    saldoData[userId] = userSaldo - nominal;
    fs.writeFileSync(dbSaldoPath, JSON.stringify(saldoData, null, 2));
    
    // Proses transaksi berdasarkan tipe
    return await processTransaction(ctx, userId, nominal, itemName, extraData, "saldo");
}

async function processTransaction(ctx, userId, nominal, itemName, extraData, paymentMethod) {
    const { type } = extraData;
    
    switch(type) {
        case "panel":
            // Proses pembuatan panel
            const username = userState[userId]?.panelOrder?.username;
            const pkgIndex = userState[userId]?.panelOrder?.pkgIndex;
            const packages = config.panel?.packages || [];
            const pkg = packages[pkgIndex];
            
            if (!username || !pkg) {
                // Refund saldo jika data tidak lengkap
                const saldoData = JSON.parse(fs.readFileSync("./database/saldoOtp.json", "utf8") || "{}");
                saldoData[userId] = (saldoData[userId] || 0) + nominal;
                fs.writeFileSync("./database/saldoOtp.json", JSON.stringify(saldoData, null, 2));
                
                return ctx.reply("❌ Data tidak lengkap. Saldo dikembalikan.");
            }
            
            // Lanjutkan dengan pembuatan panel
            const result = await createPanelAccount(
                username, 
                pkg.ram, 
                pkg.disk, 
                pkg.cpu
            );
            
            if (result.success) {
                // Kirim detail panel
                await ctx.replyWithPhoto(
                    config.panel?.menuPhoto || config.startPhoto,
                    {
                        caption: `🎉 <b>PANEL BERHASIL DIBUAT!</b>\n\n` +
                                `<b>Login Detail:</b>\n` +
                                `URL: ${result.data.login}\n` +
                                `Username: ${result.data.username}\n` +
                                `Password: ${result.data.password}\n\n` +
                                `<i>Simpan informasi ini dengan aman!</i>`,
                        parse_mode: "HTML"
                    }
                );
                
                // TAMBAHKAN TESTIMONI PANEL
                try {
                  await sendTestimoniKeChannel(
                    username,
                    userId,
                    `Panel ${pkg?.name || "Hosting"}`,
                    panelOrder.price,
                    "panel",
                    {
                      orderId: serverRes.data.attributes.id,
                      domain: config.panel.domain,
                      username: username.toLowerCase(),
                      customerNote: "Panel berhasil diaktifkan dengan spesifikasi lengkap"
                    }
                  );
                } catch (error) {
                  console.error("[TESTIMONI] Gagal kirim testimoni panel:", error.message);
                }
                
            } else {
                // Refund jika gagal
                const saldoData = JSON.parse(fs.readFileSync("./database/saldoOtp.json", "utf8") || "{}");
                saldoData[userId] = (saldoData[userId] || 0) + nominal;
                fs.writeFileSync("./database/saldoOtp.json", JSON.stringify(saldoData, null, 2));
                
                await ctx.reply(`❌ Gagal membuat panel: ${result.msg}\n\nSaldo telah dikembalikan.`);
            }
            
            // Cleanup
            delete userState[userId];
            break;
            
        case "vps":
            // Proses pembuatan VPS
            const vpsData = userState[userId]?.vpsData;
            
            if (!vpsData) {
                // Refund saldo
                const saldoData = JSON.parse(fs.readFileSync("./database/saldoOtp.json", "utf8") || "{}");
                saldoData[userId] = (saldoData[userId] || 0) + nominal;
                fs.writeFileSync("./database/saldoOtp.json", JSON.stringify(saldoData, null, 2));
                
                return ctx.reply("❌ Data VPS tidak ditemukan. Saldo dikembalikan.");
            }
            
            // Proses pembuatan VPS
            const vpsResult = await createVPSDroplet(userId, vpsData);
            
            if (vpsResult.success) {
                // Kirim detail VPS
                await ctx.reply(
                    `🎉 <b>VPS BERHASIL DIBUAT!</b>\n\n` +
                    `<b>Detail VPS:</b>\n` +
                    `Hostname: ${vpsResult.data.hostname}\n` +
                    `IP: ${vpsResult.data.ip}\n` +
                    `Password: ${vpsResult.data.password}\n` +
                    `Region: ${vpsResult.data.region}\n` +
                    `OS: ${vpsResult.data.os}\n\n` +
                    `<i>Simpan informasi ini dengan aman!</i>`,
                    { parse_mode: "HTML" }
                );
                
                // TAMBAHKAN TESTIMONI VPS
                try {
                  const user = await bot.telegram.getChat(userId);
                  await sendTestimoniKeChannel(
                    user.first_name || user.username || "User",
                    userId,
                    `VPS ${vpsData.paket} - ${vpsData.plan}`,
                    vpsData.harga,
                    "vps",
                    {
                      orderId: dropletId,
                      region: vpsData.region,
                      os: vpsData.os,
                      plan: vpsData.plan,
                      garansi: paketInfo[vpsData.paket]?.garansi || 7
                    }
                  );
                } catch (error) {
                  console.error("[TESTIMONI] Gagal kirim testimoni VPS:", error.message);
                }
                
            } else {
                // Refund jika gagal
                const saldoData = JSON.parse(fs.readFileSync("./database/saldoOtp.json", "utf8") || "{}");
                saldoData[userId] = (saldoData[userId] || 0) + nominal;
                fs.writeFileSync("./database/saldoOtp.json", JSON.stringify(saldoData, null, 2));
                
                await ctx.reply(`❌ Gagal membuat VPS: ${vpsResult.msg}\n\nSaldo telah dikembalikan.`);
            }
            
            // Cleanup
            delete userState[userId];
            break;
            
        // Tambahkan case lain sesuai kebutuhan...
    }
}

async function handlePayment(ctx, nominal, itemName, productData) {
  if (!isPrivateChat(ctx)) {
    await ctx.answerCbQuery?.();
    return safeReply(ctx, "❌ <b>Pembayaran hanya bisa dilakukan di Private Chat!</b>\n\n💬 Silakan chat saya di private: https://t.me/" + bot.botInfo.username, { parse_mode: "HTML" });
  }
  
  const userId = ctx.from.id;
  if (activeTransactions[userId]) return safeReply(ctx, "<blockquote>⚠️ <b>Ada transaksi pending.</b> Ketik /cancel.</blockquote>", { parse_mode: "HTML" });
  
  const activePaymentMethod = getActivePaymentMethod();
  
  if (activePaymentMethod === "manual") {
    if (!config.manualQrisPhoto) {
      return safeReply(ctx, "<blockquote>❌ <b>QRIS manual belum diatur oleh owner.</b> Silakan hubungi owner.</blockquote>", { parse_mode: "HTML" });
    }
    
    const fee = Math.floor(Math.random() * 50);
    const totalBayar = nominal + fee;
    
    await ctx.replyWithPhoto(config.manualQrisPhoto, {
      caption: `<blockquote><b>🧾 TAGIHAN MANUAL</b>\n\n<b>Item:</b> <code>${itemName}</code>\n<b>Total:</b> ${toRupiah(totalBayar)}\n\n<i>Silakan transfer sesuai nominal di atas</i>\n<i>Lalu kirim foto bukti transfer ke bot ini</i>\n<i>Bot akan otomatis mengirim ke owner</i></blockquote>`,
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("❌ Batalkan", "cancel_trx")]
      ])
    });
    
    userState[userId] = {
      step: "PAYMENT_MANUAL_PENDING",
      itemName: itemName,
      amount: totalBayar,
      productData: productData,
      nominal: nominal
    };
    
    return;
  }
  
  const fee = Math.floor(Math.random() * 100);
  const totalBayar = nominal + fee;
  const msgLoading = await safeReply(ctx, "<blockquote>🔄 <b>Membuat QRIS...</b></blockquote>", { parse_mode: "HTML" });
  
  let paymentConfig = {};
  if (activePaymentMethod === "atlantic") {
    paymentConfig = { 
      method: "atlantic", 
      apiAtlantic: config.payment?.apiAtlantic || config.apikeyAtlantic || config.ApikeyAtlantic || config.apiAtlantic 
    };
  } else if (activePaymentMethod === "pakasir") {
    // ===== TAMBAH KONFIGURASI PAKASIR =====
    paymentConfig = { 
      method: "pakasir",
      pakasir: {
        slug: config.payment?.pakasir?.slug || config.pakasir?.slug,
        apiKey: config.payment?.pakasir?.apiKey || config.pakasir?.apiKey
      }
    };
    // ======================================
  } else {
    paymentConfig = Object.assign({ method: "orkut" }, config.payment || {});
  }
  
  const qrisData = await createdQris(totalBayar, paymentConfig);
  
  try {
    await ctx.deleteMessage(msgLoading.message_id);
  } catch (e) {}
  
  if (!qrisData) {
    return safeReply(ctx, "<blockquote>❌ <b>Gagal membuat QRIS.</b></blockquote>", { parse_mode: "HTML" });
  }
  
  console.log("[DEBUG] QRIS Data:", {
    hasImage: !!qrisData.imageqris,
    imageType: typeof qrisData.imageqris,
    isBuffer: qrisData.imageqris instanceof Buffer,
    isString: typeof qrisData.imageqris === 'string',
    hasQrString: !!qrisData.qr_string,
    fullData: qrisData
  });
  
  let photoToSend = null;
  let useLocalQR = false;
  
  if (qrisData.imageqris instanceof Buffer) {
    console.log("[DEBUG] QRIS adalah Buffer, size:", qrisData.imageqris.length);
    photoToSend = { source: qrisData.imageqris };
    
  } else if (qrisData.imageqris && typeof qrisData.imageqris === 'string') {
    if (qrisData.imageqris.startsWith('data:image')) {
      try {
        console.log("[DEBUG] QRIS adalah Base64");
        const base64Data = qrisData.imageqris.replace(/^data:image\/\w+;base64,/, '');
        photoToSend = { source: Buffer.from(base64Data, 'base64') };
      } catch (e) {
        console.error("[ERROR] Failed to parse base64 image:", e.message);
      }
      
    } else if (qrisData.imageqris.startsWith('http')) {
      console.log("[DEBUG] QRIS adalah URL:", qrisData.imageqris);
      
      try {
        const { downloadQrisImage } = require("./lib/payment");
        const qrBuffer = await downloadQrisImage(qrisData.imageqris);
        
        if (qrBuffer) {
          console.log("[DEBUG] QRIS downloaded successfully, size:", qrBuffer.length);
          photoToSend = { source: qrBuffer };
        } else {
          console.log("[DEBUG] Failed to download QRIS, will use qr_string");
          useLocalQR = true;
        }
      } catch (downloadErr) {
        console.error("[ERROR] Failed to download QRIS image:", downloadErr.message);
        useLocalQR = true;
      }
    } else {
      console.log("[DEBUG] QRIS adalah string biasa");
      useLocalQR = true;
    }
  }
  
  if (!photoToSend && (useLocalQR || !qrisData.imageqris)) {
    if (qrisData.qr_string && qrisData.qr_string.trim().length > 0) {
      console.log("[DEBUG] Generating local QR from qr_string");
      try {
        const qrBuffer = await generateLocalQr(qrisData.qr_string);
        if (qrBuffer) {
          photoToSend = { source: qrBuffer };
          console.log("[DEBUG] Local QR generated successfully");
        } else {
          console.log("[DEBUG] Failed to generate local QR");
        }
      } catch (qrErr) {
        console.error("[ERROR] Failed to generate local QR:", qrErr.message);
      }
    }
  }
  
  if (!photoToSend) {
    console.error("[ERROR] No valid QRIS data available");
    return safeReply(ctx, 
      `<b>❌ GAGAL MEMBUAT QRIS</b>\n\n` +
      `<b>Item:</b> ${itemName}\n` +
      `<b>Total:</b> ${toRupiah(totalBayar)}\n\n` +
      `<i>Silakan hubungi owner untuk pembayaran manual.</i>`,
      { parse_mode: "HTML" }
    );
  }
  
  try {
    console.log("[DEBUG] Sending QRIS to user");
    
    const msgQris = await ctx.replyWithPhoto(photoToSend, {
      caption: `<blockquote><b>🧾 TAGIHAN</b>\n\n<b>Item:</b> <code>${itemName}</code>\n<b>Total:</b> ${toRupiah(qrisData.jumlah)}\n\n<i>Bayar pas sesuai nominal!</i>\n<i>Transaksi akan otomatis terverifikasi setelah pembayaran.</i></blockquote>`,
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("❌ Batalkan", "cancel_trx")]
      ])
    });
    
    activeTransactions[userId] = { 
      id: qrisData.idtransaksi || qrisData.id, 
      amount: qrisData.jumlah, 
      status: 'pending',
      messageId: msgQris.message_id,
      paymentMethod: activePaymentMethod,
      paymentConfig: paymentConfig
    };
    
    console.log(`[DEBUG] Transaction started for user ${userId}:`, activeTransactions[userId].id);
    
    let attempts = 0;
    const maxAttempts = 72;
    
    const interval = setInterval(async () => {
      attempts++;
      
      if (!activeTransactions[userId]) {
        console.log(`[DEBUG] Transaction ${userId} cancelled, stopping check`);
        clearInterval(interval);
        return;
      }
      
      if (attempts > maxAttempts) {
        console.log(`[DEBUG] Payment timeout for user ${userId} after ${attempts} attempts`);
        clearInterval(interval);
        
        if (activeTransactions[userId]) {
          try {
            if (activeTransactions[userId].messageId) {
              await ctx.deleteMessage(activeTransactions[userId].messageId).catch(() => {});
            }
          } catch (e) {}
          
          delete activeTransactions[userId];
          await safeReply(ctx, "<blockquote>❌ <b>Waktu pembayaran habis.</b> Silakan ulangi transaksi.</blockquote>", { 
            parse_mode: "HTML" 
          });
        }
        return;
      }
      
      try {
        console.log(`[DEBUG] Checking payment status for user ${userId}, attempt ${attempts}`);
        
        const isPaid = await cekStatus(
          qrisData.idtransaksi || qrisData.id, 
          qrisData.jumlah, 
          paymentConfig
        );
        
        if (isPaid) {
          console.log(`[DEBUG] Payment confirmed for user ${userId}`);
          clearInterval(interval);
          
          try {
            if (activeTransactions[userId]?.messageId) {
              await ctx.deleteMessage(activeTransactions[userId].messageId).catch(() => {});
            }
          } catch (e) {}
          
          delete activeTransactions[userId];
          
          const userName = `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim();
          sendTestimoniKeChannel(userName, userId, itemName, nominal);
          
          try {
            await bot.telegram.sendMessage(
              config.ownerId,
              `<b>💰 PEMBAYARAN SUKSES</b>\n\n` +
              `<b>👤 User:</b> ${ctx.from.first_name} (${ctx.from.id})\n` +
              `<b>🛒 Item:</b> ${itemName}\n` +
              `<b>💵 Harga:</b> ${toRupiah(nominal)}\n` +
              `<b>📊 Status:</b> QRIS Payment (${activePaymentMethod.toUpperCase()})\n` +
              `<b>⏰ Waktu:</b> ${new Date().toLocaleString()}`,
              { parse_mode: "HTML" }
            );
          } catch (ownerErr) {
            console.error("[ERROR] Failed to notify owner:", ownerErr.message);
          }
          
          await sendProductToUser(ctx, productData);
        } else {
          console.log(`[DEBUG] Payment not yet confirmed for user ${userId}`);
        }
        
      } catch (error) {
        console.error(`[ERROR] Error checking payment status for user ${userId}:`, error.message);
        
        if (attempts > 10) {
          clearInterval(interval);
          console.error(`[ERROR] Too many errors, stopping check for user ${userId}`);
          
          if (activeTransactions[userId]) {
            delete activeTransactions[userId];
            await safeReply(ctx, "<blockquote>⚠️ <b>Terjadi gangguan sistem pembayaran.</b> Silakan hubungi owner.</blockquote>", { 
              parse_mode: "HTML" 
            });
          }
        }
      }
    }, 5000);
    
  } catch (error) {
    console.error("[ERROR] Failed to send QRIS photo:", error.message);
    
    if (activeTransactions[userId]) {
      delete activeTransactions[userId];
    }
    
    let errorMessage = `<b>⚠️ GAGAL MENAMPILKAN QRIS</b>\n\n`;
    errorMessage += `<b>Item:</b> ${itemName}\n`;
    errorMessage += `<b>Total:</b> ${toRupiah(qrisData.jumlah)}\n`;
    errorMessage += `<b>ID Transaksi:</b> ${qrisData.idtransaksi || qrisData.id || '-'}\n`;
    
    if (qrisData.qr_string && qrisData.qr_string.length < 500) {
      errorMessage += `<b>QR String:</b>\n<code>${qrisData.qr_string}</code>\n\n`;
    }
    
    errorMessage += `<i>Silakan hubungi owner untuk pembayaran manual.</i>`;
    
    await safeReply(ctx, errorMessage, { parse_mode: "HTML" });
  }
}

bot.action(/delete_sc_(\d+)/, async (ctx) => {
  try {
    const idx = parseInt(ctx.match[1]);
    const db = readDb();
    const sc = db.scripts[idx];

    if (!sc) {
      await ctx.answerCbQuery("❌ Script tidak ditemukan.");
      return;
    }

    db.scripts.splice(idx, 1);
    saveDb(db);

    await ctx.answerCbQuery("✅ Script berhasil dihapus!");
    await ctx.editMessageText("✔️ Script berhasil dihapus.", Markup.inlineKeyboard([[Markup.button.callback("🔙 Kembali", "menu_owner")]]))
      .catch(()=>{ safeReply(ctx, "✔️ Script berhasil dihapus."); });

  } catch (e) {
    console.error("delete_sc error:", e);
  }
});

bot.action(/delete_app_(\d+)/, (ctx) => {
  if (ctx.from.id !== config.ownerId) return;
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  const app = db.apps[idx];
  if (!app) {
    ctx.answerCbQuery("❌ App tidak ditemukan.");
    return showOwnerMenu(ctx);
  }
  db.apps.splice(idx, 1);
  saveDb(db);
  ctx.answerCbQuery(`✅ App ${app?.nama || 'Item'} berhasil dihapus.`);
  showOwnerMenu(ctx);
});

bot.action(/list_accounts_(\d+)/, (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  const app = db.apps[idx];
  if (!app) return ctx.answerCbQuery("❌ App tidak ditemukan.");
  const accounts = app.accounts || [];
  let txt = `<b>📄 List Accounts - ${app.nama}</b>\n<b>Stock:</b> ${accounts.length}\n\n`;
  if (!accounts.length) txt += "<i>Belum ada akun.</i>\n";
  accounts.forEach((a, i) => {
    txt += `<b>${i+1}.</b> ${a.user} | ${a.pass} | ${a.link} | ${a.desc || '-'}\n`;
  });
  safeReply(ctx, txt, { parse_mode: "HTML" });
  ctx.answerCbQuery().catch(()=>{});
});

bot.action("owner_add_account", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const db = readDb();
  if (!db.apps || db.apps.length === 0) return safeReply(ctx, "<blockquote>❌ <b>Belum ada app yang terdaftar.</b> Tambahkan app terlebih dahulu.</blockquote>", { parse_mode: "HTML" });
  const buttons = db.apps.map((a, i) => [ Markup.button.callback(`${a.nama} (${(a.accounts||[]).length} stok)`, `owner_add_account_to_${i}`) ]);
  buttons.push([ Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "menu_owner") ]);
  safeReply(ctx, "<blockquote><b>Pilih aplikasi untuk menambah akun:</b></blockquote>", { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/owner_add_account_to_(\d+)/, (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  if (!db.apps[idx]) return ctx.answerCbQuery("❌ App tidak ditemukan.");
  userState[ctx.from.id] = { step: "WAITING_ADD_ACCOUNT", appIndex: idx };
  safeReply(ctx, "<blockquote><b>✏️ Kirim akun dengan format:</b>\n<code>username|password|link akses|deskripsi</code></blockquote>", { parse_mode: "HTML" });
  ctx.answerCbQuery().catch(()=>{});
});

bot.action("owner_del_account", (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const db = readDb();
  if (!db.apps || db.apps.length === 0) return safeReply(ctx, "<blockquote>❌ <b>Belum ada app yang terdaftar.</b></blockquote>", { parse_mode: "HTML" });
  const buttons = db.apps.map((a, i) => [ Markup.button.callback(`${a.nama} (${(a.accounts||[]).length} stok)`, `owner_del_account_choose_${i}`) ]);
  buttons.push([ Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "menu_owner") ]);
  safeReply(ctx, "<blockquote><b>Pilih aplikasi untuk menghapus akun:</b></blockquote>", { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/owner_del_account_choose_(\d+)/, (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const idx = parseInt(ctx.match[1]);
  const db = readDb();
  const app = db.apps[idx];
  if (!app) return ctx.answerCbQuery("❌ App tidak ditemukan.");
  const accounts = app.accounts || [];
  if (!accounts.length) return safeReply(ctx, "<blockquote>❌ <b>Tidak ada akun pada aplikasi ini.</b></blockquote>", { parse_mode: "HTML" });
  const buttons = accounts.map((acc, i) => [ Markup.button.callback(`🗑 ${i+1}. ${acc.user} - ${acc.desc || '-'}`, `owner_delete_acc_${idx}_${i}`) ]);
  buttons.push([ Markup.button.callback("🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", "menu_owner") ]);
  safeReply(ctx, `<blockquote><b>Pilih akun yang ingin dihapus dari ${app.nama}:</b></blockquote>`, { parse_mode: "HTML", ...Markup.inlineKeyboard(buttons) });
  ctx.answerCbQuery().catch(()=>{});
});

bot.action(/owner_delete_acc_(\d+)_(\d+)/, (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("❌ Bukan Owner!");
  const appIndex = parseInt(ctx.match[1]);
  const accIndex = parseInt(ctx.match[2]);
  const db = readDb();
  const app = db.apps[appIndex];
  if (!app) return ctx.answerCbQuery("❌ App tidak ditemukan.");
  if (!app.accounts || !app.accounts[accIndex]) return ctx.answerCbQuery("❌ Akun tidak ditemukan.");
  const removed = app.accounts.splice(accIndex, 1);
  saveDb(db);
  ctx.answerCbQuery("✅ Akun dihapus.");
  safeReply(ctx, `<blockquote><b>✅ Akun ${removed[0].user} telah dihapus dari ${app.nama}</b></blockquote>`, { parse_mode: "HTML" });
});

async function sendProductToUser(ctx, productData) {
  try {
    const userId = ctx.from.id;
    const username = ctx.from.username || ctx.from.first_name;
    const userNameFull = `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim();

    if (productData.type === "script") {
      const db = readDb();
      const item = db.scripts[productData.index];
      
      if (!item) {
        return safeReply(ctx, "<blockquote>❌ <b>Script tidak ditemukan!</b> Silakan hubungi owner.</blockquote>", { parse_mode: "HTML" });
      }
      
      if (!item.file_id) {
        return safeReply(ctx, "<blockquote>❌ <b>File script tidak tersedia!</b> Silakan hubungi owner.</blockquote>", { parse_mode: "HTML" });
      }
      
      await safeReply(ctx, "<blockquote>✅ <b>Pembayaran valid! Mengirim file...</b></blockquote>", { parse_mode: "HTML" });
      
      await ctx.replyWithDocument(item.file_id, { 
        caption: `<b>📦 ${item.nama}</b>\n\n` +
                 `<b>├⌑ 💰 𝖧𝖺𝗋𝗀𝖺 :</b> ${toRupiah(item.harga)}\n` +
                 `<b>├⌑ 📝 𝖣𝖾𝗌𝗄𝗋𝗂𝗉𝗌𝗂 :</b>\n${item.deskripsi || 'Tidak ada deskripsi'}\n` +
                 `<b>└⌑ 🍂 𝖳𝖾𝗋𝗂𝗆𝖺𝗄𝖺𝗌𝗂𝗁 𝖲𝗎𝖽𝖺𝗁 𝖮𝗋𝖽𝖾𝗋!</b>`, 
        filename: item.fileName || `${item.nama}.zip`,
        parse_mode: "HTML"
      });

      sendTestimoniKeChannel(userNameFull, userId, `Script: ${item.nama}`, item.harga);
    } 

    else if (productData.type === "app") {
      const db = readDb();
      const app = db.apps[productData.idx];
      
      if (!app) {
        return safeReply(ctx, "<blockquote>❌ <b>Aplikasi tidak ditemukan!</b> Silakan hubungi owner.</blockquote>", { parse_mode: "HTML" });
      }
      
      app.accounts = app.accounts || [];
      
      if (app.accounts.length < productData.qty) {
        return safeReply(ctx, `<blockquote>❌ <b>Stok tidak mencukupi!</b>\nStok tersedia: ${app.accounts.length}\nYang dibeli: ${productData.qty}</blockquote>`, { parse_mode: "HTML" });
      }
      
      const taken = [];
      for (let i = 0; i < productData.qty; i++) {
        const acc = app.accounts.shift();
        if (acc) taken.push(acc);
      }
      
      saveDb(db);
      
      let msg = `<blockquote><b>✅ Transaksi Sukses</b>\n\n<b>» Produk :</b> ${app.nama}\n<b>» Jumlah Beli :</b> ${productData.qty}\n<b>» Total Harga :</b> ${toRupiah(productData.total)}\n<b>» Deskripsi Produk :</b> ${app.deskripsi || '-'}\n\n</blockquote>`;
      
      taken.forEach((a, i) => {
        msg += `<blockquote><b>— Akun ${i+1} —</b>\n<b>Username:</b> ${a.user}\n<b>Password:</b> ${a.pass}\n<b>Link Akses:</b> ${a.link}\n<b>Deskripsi:</b> ${a.desc || '-'}\n\n</blockquote>`;
      });
      
      safeReply(ctx, msg, { parse_mode: "HTML" });
      sendTestimoniKeChannel(userNameFull, userId, `App: ${app.nama} x${productData.qty}`, productData.total);
    } 

    else if (productData.type === "panel") {
      ctx.reply("<blockquote>⏳ <b>Sedang membuat akun panel...</b></blockquote>", { parse_mode: "HTML" });
      
      let disk, cpu;
      if (productData.ram === 0) {
        disk = 0;
        cpu = 0;
      } else {
        const gb = productData.ram / 1024;
        disk = gb * 2048;
        cpu = gb * 50;
      }
      
      const result = await createPanelAccount(productData.username, productData.ram, disk, cpu);
      
      if (result.success) {
        const d = result.data;
        ctx.reply(
          `<blockquote><b>✅ PANEL BERHASIL DIBUAT</b>\n\n<b>👤 User:</b> ${productData.username}\n<b>🆔 ID:</b> <code>${d.username}</code>\n<b>🔑 PW:</b> <code>${d.password}</code>\n<b>🌐 Login:</b> ${d.login}</blockquote>`,
          { parse_mode: "HTML" }
        );

        sendTestimoniKeChannel(userNameFull, userId, `Panel ${productData.ram === 0 ? "Unlimited" : productData.ram/1024 + "GB"}`, productData.price);
      } else {
        ctx.reply(`<blockquote>⚠️ <b>Gagal:</b> ${result.msg}</blockquote>`, { parse_mode: "HTML" });
      }
    } 

    else if (productData.type === "admin_panel") {
      await ctx.reply("<blockquote>⏳ <b>Sedang membuat akun Admin Panel...</b></blockquote>", { parse_mode: "HTML" });

      const result = await createAdminAccount(productData.username);

      if (result.success) {
          const d = result.data;
          const msg = `<blockquote><b>🛠️ 𝗔𝗗𝗠𝗜𝗡 𝗣𝗔𝗡𝗘𝗟 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗗𝗜𝗕𝗨𝗔𝗧</b>
━━━━━━━━━━━━━━━━━━━━━━━━━⨳
<b>👤 𝖴𝗌𝖾𝗋 :</b> ${productData.username}
<b>🆔 𝖴𝗌𝖾𝗋𝗇𝖺𝗆𝖾 :</b> <code>${d.username}</code>
<b>🔑 𝖯𝖺𝗌𝗌𝗐𝗈𝗋𝖽 :</b> <code>${d.password}</code>
<b>📧 𝖤𝗆𝖺𝗂𝗅 :</b> ${d.email}
<b>🌐 𝖫𝗈𝗀𝗂𝗇 :</b> ${d.login}
<b>🛡️ 𝖠𝖼𝖼𝖾𝗌𝗌 :</b> ROOT ADMIN (Full Control)
━━━━━━━━━━━━━━━━━━━━━━━━━⨳
<i>📝 𝖭𝗈𝗍𝖾 : 𝖲𝗂𝗆𝗉𝖺𝗇 𝖣𝖺𝗍𝖺 𝖨𝗇𝗂 𝖣𝖺𝗇 𝖩𝖺𝗇𝗀𝖺𝗇
𝖣𝗂𝗌𝖾𝖻𝖺𝗋𝗄𝖺𝗇 𝖲𝖾𝖼𝖺𝗋𝖺 𝖦𝗋𝖺𝗍𝗂𝗌!</i></blockquote>`;

          await ctx.reply(msg, { parse_mode: "HTML" });
          sendTestimoniKeChannel(userNameFull, userId, `Admin Panel (${d.username})`, productData.price);
      } else {
          await ctx.reply(`<blockquote>⚠️ <b>Gagal membuat Admin Panel:</b> ${result.msg}\nSilakan hubungi owner.</blockquote>`, { parse_mode: "HTML" });
      }
    }

    else if (productData.type === "reseller_panel") {
      const link = config.linkResellerPanel || "https://t.me/LinkBelumDiset";
      
      const msg = `<blockquote><b>🤝 𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗡𝗘𝗪 𝗥𝗘𝗦𝗘𝗟𝗟𝗘𝗥 𝗣𝗔𝗡𝗘𝗟</b>
━━━━━━━━━━━━━━━━━━━━━━━⨳
<b>🚀 𝖳𝖾𝗋𝗂𝗆𝖺𝗄𝖺𝗌𝗂𝗁 𝖲𝗎𝖽𝖺𝗁 𝖬𝖾𝗆𝖻𝖾𝗅𝗂 𝖱𝖾𝗌𝖾𝗅𝗅𝖾𝗋
𝖯𝖺𝗇𝖾𝗅 𝖪𝖺𝗆𝗂!</b>
<b>🔗 𝖡𝖾𝗋𝗂𝗄𝗎𝗍 𝖫𝗂𝗇𝗄 𝖦𝗋𝗎𝖻 𝖱𝖾𝗌𝖾𝗅𝗅𝖾𝗋 𝖯𝖺𝗇𝖾𝗅 :</b>
${link}

🍂 <i>𝖲𝗂𝗅𝖺𝗁𝗄𝖺𝗇 𝖡𝖾𝗋𝗀𝖺𝖻𝗎𝗇𝗀 𝖦𝗋𝗎𝖻 𝖱𝖾𝗌𝖾𝗅𝗅𝖾𝗋
𝖯𝖺𝗇𝖾𝗅 𝖣𝗂𝖺𝗍𝖺𝗌 𝖣𝖺𝗇 𝖪𝗈𝗇𝖿𝗂𝗆𝖺𝗌𝗂 𝖪𝖾 𝖮𝗐𝗇𝖾𝗋.</i>
━━━━━━━━━━━━━━━━━━━━━━━⨳</blockquote>`;

      await ctx.reply(msg, { 
          parse_mode: "HTML",
          disable_web_page_preview: true 
      });

      sendTestimoniKeChannel(userNameFull, userId, "Join Reseller Panel", productData.price);
    }

    else if (productData.type === "vps") {
      const loadingMsg = await ctx.reply("<blockquote>⏳ <b>Sedang membuat VPS DigitalOcean...</b>\nProses membutuhkan waktu ±60 detik.</blockquote>", { 
        parse_mode: "HTML" 
      });
      
      try {
        productData.vpsData.username = username;
        
        const result = await createVPSDroplet(userId, productData.vpsData);
        
        try { await ctx.deleteMessage(loadingMsg.message_id); } catch (e) {}
        
        if (result.success) {
          const data = result.data;
          const paketInfo = {
            low: { garansi: 7, replace: 1 },
            medium: { garansi: 15, replace: 2 },
            high: { garansi: 30, replace: -1 }
          };
          
          const paket = productData.vpsData.paket;
          
          const detailVPS = `<blockquote>✅ <b>𝗩𝗣𝗦 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗗𝗜𝗕𝗨𝗔𝗧!</b></blockquote>

<blockquote>🖥️ <b>𝗕𝗘𝗥𝗜𝗞𝗨𝗧 𝗗𝗘𝗧𝗔𝗜𝗟 𝗩𝗣𝗦</b>
━━━━━━━━━━━━━━━━━━━━━━━━━⨳
<b>🌐 𝖨𝖯 𝖠𝖣𝖣𝖱𝖤𝖲𝖲:</b> <code>${data.ip}</code>
<b>🆔 𝖴𝖲𝖤𝖱𝖭𝖠𝖬𝖤 :</b> <code>root</code>
<b>🔐 𝖯𝖠𝖲𝖲𝖶𝖮𝖱𝖣 :</b> <code>${data.password}</code>
<b>🧩 𝖧𝖮𝖲𝖳𝖭𝖠𝖬𝖤 :</b> ${data.hostname}
<b>🌍 𝖱𝖤𝖦𝖨𝖮𝖭 :</b> ${data.region.toUpperCase()}
<b>💿 𝖮𝖲 :</b> ${data.os.toUpperCase()}</blockquote>

<blockquote>🛍️ <b>𝗗𝗘𝗧𝗔𝗜𝗟 𝗣𝗘𝗠𝗕𝗘𝗟𝗜𝗔𝗡</b>
━━━━━━━━━━━━━━━━━━━━━━━━━⨳
<b>📦 𝖯𝖠𝖪𝖤𝖳 :</b> ${paket.toUpperCase()}
<b>💾 𝖲𝖯𝖤𝖲𝖨𝖥𝖨𝖪𝖠𝖲𝖨 :</b> ${productData.vpsData.plan}
<b>💰 𝖧𝖠𝖱𝖦𝖠 :</b> ${toRupiah(productData.vpsData.harga)}
<b>🛡️ 𝖦𝖠𝖱𝖠𝖭𝖲𝖨 :</b> ${paketInfo[paket].garansi} Hari
<b>♻️ 𝖱𝖤𝖯𝖫𝖠𝖢𝖤 :</b> ${paketInfo[paket].replace === -1 ? "Unlimited" : paketInfo[paket].replace + "x"}
<b>📅 𝖳𝖠𝖭𝖦𝖦𝖠𝖫 :</b> ${data.created}
<b>👤 𝖯𝖤𝖬𝖡𝖤𝖫𝖨 :</b> ${username}
<b>🤝 𝖯𝖤𝖭𝖩𝖴𝖠𝖫 :</b> @${bot.botInfo.username}</blockquote>`;
          
          await ctx.reply(detailVPS, { parse_mode: "HTML" });
          
          await ctx.reply(
            `<blockquote>📌 <b>𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗣𝗘𝗡𝗧𝗜𝗡𝗚</b>
━━━━━━━━━━━━━━━━━━━━━━━━⨳
• Gunakan IP <code>${data.ip}</code> untuk akses VPS
• Login dengan username <code>root</code> dan password di atas
• VPS sudah ready untuk digunakan
• Jika ada masalah, silakan hubungi admin</blockquote>`,
            { parse_mode: "HTML" }
          );

          try {
             const testiText = `🖥️ <b>𝗩𝗣𝗦 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗗𝗜𝗕𝗘𝗟𝗜!</b>\n\n` +
              `👤 <b>𝖯𝖾𝗆𝖻𝖾𝗅𝗂 :</b> ${username}\n` +
              `📦 <b>𝖯𝖺𝗄𝖾𝗍 :</b> ${paket.toUpperCase()}\n` +
              `💾 <b>𝖲𝗉𝖾𝗄 :</b> ${productData.vpsData.plan}\n` +
              `💰 <b>𝖧𝖺𝗋𝗀𝖺 :</b> ${toRupiah(productData.vpsData.harga)}\n` +
              `🕒 <b>𝖶𝖺𝗄𝗍𝗎 :</b> ${new Date().toLocaleString("id-ID")}\n\n` +
              `🎉 <b>𝖳𝗋𝖺𝗇𝗌𝖺𝗄𝗌𝗂 𝖲𝗎𝖼𝖼𝖾𝗌𝗌𝖿𝗎𝗅!</b>`;
            
            if(config.testimoniChannel) {
                await bot.telegram.sendMessage(config.testimoniChannel, testiText, {
                  parse_mode: "HTML",
                  reply_markup: {
                    inline_keyboard: [[{ text: "🛒 𝗢𝗿𝗱𝗲𝗿 𝗩𝗣𝗦", url: `https://t.me/${bot.botInfo.username}?start=shop` }]]
                  }
                });
            }
          } catch (e) {}
          
          sendTestimoniKeChannel(userNameFull, userId, `VPS ${paket.toUpperCase()} - ${productData.vpsData.plan}`, productData.vpsData.harga);
          
        } else {
          await ctx.reply(`<blockquote>❌ <b>Gagal membuat VPS:</b> ${result.msg}</blockquote>`, { parse_mode: "HTML" });
          await ctx.reply(
            `<blockquote>⚠️ <b>TRANSAKSI GAGAL</b>\n\nMaaf, terjadi kesalahan saat membuat VPS Anda.\n\nSilakan:\n1. Hubungi admin untuk bantuan\n2. Atau minta refund melalui admin</blockquote>`,
            { parse_mode: "HTML" }
          );
          
          try {
            await bot.telegram.sendMessage(config.ownerId, 
              `<b>🚨 ERROR BUAT VPS!</b>\nUser: ${username}\nError: ${result.msg}\nPaket: ${productData.vpsData.paket}`, {parse_mode: "HTML"}
            );
          } catch(e){}
        }
        
        if (userState[userId]?.vpsData) delete userState[userId].vpsData;
        
      } catch (error) {
        try { await ctx.deleteMessage(loadingMsg.message_id); } catch (e) {}
        await ctx.reply(`<blockquote>❌ <b>Error sistem VPS:</b> ${error.message}</blockquote>`, { parse_mode: "HTML" });
      }
    }

  } catch (error) {
    console.error("[ERROR] Error sending product:", error);
    safeReply(ctx, "<blockquote>❌ <b>Gagal mengirim produk.</b> Silakan hubungi owner.</blockquote>", { parse_mode: "HTML" });
  }
}

bot.on("photo", async (ctx) => {
  try {
    const userId = ctx.from.id;
    const state = userState[userId];
    
    if (state?.step === "PAYMENT_MANUAL_PENDING") {
      const photos = ctx.message.photo || [];
      if (photos.length === 0) {
        await ctx.reply("❌ Foto tidak ditemukan. Silakan kirim ulang.");
        return;
      }
      
      const bestPhoto = photos[photos.length - 1];
      
      const paymentData = {
        userId: userId,
        userName: `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim(),
        userUsername: ctx.from.username ? `@${ctx.from.username}` : '-',
        itemName: state.itemName,
        amount: state.amount,
        nominal: state.nominal,
        proofPhotoId: bestPhoto.file_id,
        timestamp: Date.now(),
        status: "pending",
        productData: state.productData
      };
      
      const payments = readManualPayments();
      const paymentIndex = payments.length;
      payments.push(paymentData);
      saveManualPayments(payments);
      
      delete userState[userId];
      
      try {
        await bot.telegram.sendPhoto(config.ownerId, paymentData.proofPhotoId, {
          caption: `<blockquote><b>🧾 BUKTI PEMBAYARAN MANUAL</b>\n\n<b>👤 User:</b> ${paymentData.userName}\n<b>🆔 ID:</b> ${paymentData.userId}\n<b>📛 Username:</b> ${paymentData.userUsername}\n\n<b>🛒 Item:</b> ${paymentData.itemName}\n<b>💰 Amount:</b> ${toRupiah(paymentData.amount)}\n<b>⏰ Time:</b> ${new Date(paymentData.timestamp).toLocaleString()}\n\n<i>Verifikasi pembayaran ini:</i></blockquote>`,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "✅ Terima & Kirim Produk", callback_data: `approve_payment_${paymentIndex}` },
                { text: "❌ Tolak", callback_data: `reject_payment_${paymentIndex}` }
              ]
            ]
          }
        });
        
        await ctx.reply("<blockquote>✅ <b>Bukti pembayaran telah dikirim ke owner!</b>\nSilakan tunggu verifikasi. Status akan diberitahu.</blockquote>", { parse_mode: "HTML" });
        
      } catch (ownerError) {
        console.error("[ERROR] Error sending to owner:", ownerError);
        await ctx.reply("<blockquote>❌ <b>Gagal mengirim bukti ke owner.</b> Silakan coba lagi atau hubungi owner langsung.</blockquote>", { parse_mode: "HTML" });
        userState[userId] = state;
      }
      
      return;
    }
    
  } catch (e) {
    console.error("[ERROR] Payment proof error:", e);
    try {
      await ctx.reply("<blockquote>❌ <b>Terjadi kesalahan saat memproses bukti pembayaran.</b> Silakan coba lagi.</blockquote>", { parse_mode: "HTML" });
    } catch (replyError) {
      console.error("[ERROR] Cannot send error message:", replyError);
    }
  }
});

bot.action(/approve_payment_(\d+)/, async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    await ctx.answerCbQuery("❌ Hanya owner yang boleh verifikasi!", { show_alert: true });
    return;
  }
  
  const paymentIndex = parseInt(ctx.match[1]);
  const payments = readManualPayments();
  const payment = payments[paymentIndex];
  
  if (!payment) {
    await ctx.answerCbQuery("❌ Pembayaran tidak ditemukan/terhapus!", { show_alert: true });
    return;
  }
  
  if (payment.status !== "pending") {
    await ctx.answerCbQuery("❌ Pembayaran ini sudah diproses sebelumnya!", { show_alert: true });
    return;
  }
  
  payment.status = "approved";
  payment.approvedBy = ctx.from.id;
  payment.approvedAt = Date.now();
  saveManualPayments(payments);
  
  try {
    await ctx.editMessageCaption(
      `<blockquote><b>✅ PEMBAYARAN DITERIMA</b>\n\n` +
      `<b>👤 User:</b> ${payment.userName}\n` +
      `<b>🛒 Item:</b> ${payment.itemName}\n` +
      `<b>💰 Amount:</b> ${toRupiah(payment.amount)}\n` +
      `<b>⏰ Approved:</b> ${new Date(payment.approvedAt).toLocaleString()}</blockquote>`,
      { parse_mode: "HTML" }
    );
  } catch (e) {
    console.error("[ERROR] Failed to edit message caption:", e.message);
  }
  
  try {
    const fakeCtx = {
      from: { 
        id: payment.userId, 
        first_name: payment.userName.split(' ')[0] || payment.userName,
        last_name: payment.userName.split(' ').slice(1).join(' ') || ''
      },
      reply: (text, extra) => bot.telegram.sendMessage(payment.userId, text, extra),
      replyWithDocument: (file_id, extra) => bot.telegram.sendDocument(payment.userId, file_id, extra),
      telegram: bot.telegram
    };
    
    if (payment.productData) {
      
      if (payment.productData.type === "topup_saldo") {
          const dbSaldoPath = "./database/saldoOtp.json";
          let saldoData = {};
          
          try {
            if (fs.existsSync(dbSaldoPath)) {
                saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
            }
          } catch(err) { saldoData = {}; }
          
          const saldoMasuk = payment.productData.amount || payment.amount;
          
          saldoData[payment.userId] = (saldoData[payment.userId] || 0) + saldoMasuk;
          fs.writeFileSync(dbSaldoPath, JSON.stringify(saldoData, null, 2));
          
          await bot.telegram.sendMessage(
            payment.userId, 
            `✅ <b>DEPOSIT SUKSES!</b>\n\n💰 Saldo Masuk: <b>${toRupiah(saldoMasuk)}</b>\n💼 Total Saldo: <b>${toRupiah(saldoData[payment.userId])}</b>`, 
            {parse_mode:"HTML"}
          );
          
          sendTestimoniKeChannel(payment.userName, payment.userId, "Deposit Saldo", saldoMasuk);
      } 
      
      else {
          await sendProductToUser(fakeCtx, payment.productData);
          
          sendTestimoniKeChannel(payment.userName, payment.userId, payment.itemName, payment.amount);
      }
      
      await bot.telegram.sendMessage(config.ownerId,
        `<blockquote><b>📦 TRANSAKSI SELESAI</b>\n\n` +
        `<b>👤 User:</b> ${payment.userName}\n` +
        `<b>🆔 ID:</b> ${payment.userId}\n` +
        `<b>🛒 Item:</b> ${payment.itemName}\n` +
        `<b>💰 Amount:</b> ${toRupiah(payment.amount)}\n` +
        `<b>✅ Status:</b> Sukses dikirim/ditambahkan</blockquote>`,
        { parse_mode: "HTML" }
      );
    }
    
    await ctx.answerCbQuery("✅ Pembayaran diterima & diproses!");
    
  } catch (error) {
    console.error("[ERROR] Error in payment approval:", error);
    await bot.telegram.sendMessage(config.ownerId, 
      `<blockquote><b>⚠️ ERROR PROSES TRANSAKSI</b>\n\n` +
      `<b>User:</b> ${payment.userName} (${payment.userId})\n` +
      `<b>Error:</b> ${error.message}\n\n` +
      `<i>Saldo/Produk mungkin belum masuk. Cek manual!</i></blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});

bot.action(/reject_payment_(\d+)/, async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    await ctx.answerCbQuery("❌ Hanya owner yang boleh verifikasi!", { show_alert: true });
    return;
  }
  
  const paymentIndex = parseInt(ctx.match[1]);
  const payments = readManualPayments();
  const payment = payments[paymentIndex];
  
  if (!payment) {
    await ctx.answerCbQuery("❌ Pembayaran tidak ditemukan!", { show_alert: true });
    return;
  }
  
  if (payment.status !== "pending") {
    await ctx.answerCbQuery("❌ Pembayaran sudah diverifikasi!", { show_alert: true });
    return;
  }
  
  payment.status = "rejected";
  payment.rejectedBy = ctx.from.id;
  payment.rejectedAt = Date.now();
  saveManualPayments(payments);
  
  try {
    await ctx.editMessageCaption(`<blockquote><b>❌ PEMBAYARAN DITOLAK</b>\n\n<b>👤 User:</b> ${payment.userName}\n<b>🛒 Item:</b> ${payment.itemName}\n<b>💰 Amount:</b> ${toRupiah(payment.amount)}\n<b>⏰ Rejected:</b> ${new Date(payment.rejectedAt).toLocaleString()}</blockquote>`,
      { parse_mode: "HTML" });
  } catch (e) {
    console.error("[ERROR] Failed to edit message caption:", e);
  }
  
  try {
    await bot.telegram.sendMessage(payment.userId, 
      `<blockquote><b>❌ Pembayaran Anda ditolak!</b>\n\n<b>Alasan:</b> Bukti transfer tidak valid / nominal tidak sesuai.\n<i>Silakan hubungi owner untuk informasi lebih lanjut.</i></blockquote>`,
      { parse_mode: "HTML" }
    );
  } catch (e) {
    console.error("[ERROR] Failed to send rejection message to user:", e);
  }
  
  await ctx.answerCbQuery("❌ Pembayaran ditolak!");
});

bot.command(["withdraw", "wd"], async (ctx) => {
  if (ctx.from.id !== config.ownerId) return;

  const args = ctx.message.text.split(" ");
  const nominal = parseInt(args[1]);

  if (!nominal || isNaN(nominal) || nominal < 1000) {
    return ctx.reply("<blockquote>💰 <b>Gunakan:</b> <code>/withdraw [nominal]</code>\nMinimal Rp 1.000</blockquote>", { parse_mode: "HTML" });
  }

  try {
    const waitMsg = await ctx.reply("⏳ <b>Memproses withdraw...</b>", { parse_mode: "HTML" });
    
    const atlConfig = {
      apiAtlantic: config.ApikeyAtlantic,
      wd_balance: config.wd_balance
    };

    const res = await atlanticTransfer(nominal, atlConfig);

    if (!res.status) throw new Error(res.message);

    const data = res.data;
    const caption = `<blockquote>✅ <b>PERMINTAAN WITHDRAW DIBUAT</b>\n\n` +
      `<b>Reff ID:</b> <code>${data.reff_id}</code>\n` +
      `<b>Transfer ID:</b> <code>${data.id}</code>\n` +
      `<b>Tujuan:</b> ${data.nomor_tujuan} (${data.nama})\n` +
      `<b>Nominal:</b> ${toRupiah(data.nominal)}\n` +
      `<b>Fee:</b> ${toRupiah(data.fee)}\n\n` +
      `<i>Menunggu konfirmasi transfer...</i></blockquote>`;

    await ctx.telegram.editMessageText(ctx.chat.id, waitMsg.message_id, null, caption, {
      parse_mode: "HTML",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("🔄 Cek Status WD", `check_wd_${data.id}`)]
      ])
    });

  } catch (err) {
    ctx.reply(`❌ <b>Error:</b> ${err.message}`, { parse_mode: "HTML" });
  }
});

bot.action(/check_wd_(.+)/, async (ctx) => {
  if (ctx.from.id !== config.ownerId) return ctx.answerCbQuery("Bukan Owner!");
  const wdId = ctx.match[1];
  
  try {
    const res = await atlanticTransferStatus(wdId, config.ApikeyAtlantic);
    const status = res.data?.status || "processing";
    
    await ctx.answerCbQuery(`Status: ${status.toUpperCase()}`);
    
    if (status === "success") {
      await ctx.editMessageCaption(`<blockquote>✅ <b>WD BERHASIL!</b>\nID: <code>${wdId}</code>\nStatus: <b>SUCCESS</b></blockquote>`, { parse_mode: "HTML" });
    }
  } catch (e) {
    ctx.answerCbQuery("Gagal cek status.");
  }
});

bot.action(/batal_deposit_pakasir_(.+)/, async (ctx) => {
   const transId = ctx.match[1];
   const userId = ctx.from.id;
   
   // Cek apakah transaksi ini milik user
   if (activeTransactions[userId] && activeTransactions[userId].id === transId) {
       delete activeTransactions[userId];
       await ctx.deleteMessage().catch(() => {});
       await ctx.reply("✅ <b>Deposit dibatalkan.</b>", {
           parse_mode: "HTML",
           reply_markup: { inline_keyboard: [[{text:"🔙 Menu", callback_data:"shop_menu"}]] }
       });
   } else {
       ctx.answerCbQuery("❌ Transaksi tidak ditemukan atau sudah diproses.");
   }
});

bot.action("menu_wd_info", (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return ctx.answerCbQuery("❌ Hanya owner yang bisa melihat info WD!", { show_alert: true });
  }
  
  function sensorString(input, visibleCount = 3, maskChar = 'X') {
    if (!input || input.length <= visibleCount) return input || "Tidak tersedia";
    const visiblePart = input.slice(0, visibleCount);
    const maskedPart = maskChar.repeat(input.length - visibleCount);
    return visiblePart + maskedPart;
  }
  
  function sensorWithSpace(str, visibleCount = 3, maskChar = 'X') {
    if (!str) return "Tidak tersedia";
    let result = '';
    let count = 0;
    for (let char of str) {
      if (char === ' ') {
        result += char;
      } else if (count < visibleCount) { 
        result += char; 
        count++; 
      } else {
        result += maskChar;
      }
    }
    return result;
  }
  
  const wdInfo = config.wd_balance || {};
  
  const infoText = `<blockquote><b>💰 𝗜𝗡𝗙𝗢 𝗪𝗜𝗧𝗛𝗗𝗥𝗔𝗪</b>\n\n` +
    `<b>├⌑ 𝖡𝖺𝗇𝗄/𝖤-𝖶𝖺𝗅𝗅𝖾𝗍 :</b> ${wdInfo.bank_code || "Belum diatur"}\n` +
    `<b>├⌑ 𝖳𝗎𝗃𝗎𝖺𝗇 :</b> ${sensorString(wdInfo.destination_number)}\n` +
    `<b>└⌑ 𝖭𝖺𝗆𝖺 :</b> ${sensorWithSpace(wdInfo.destination_name)}\n\n` +
    `𝖪𝖾𝗍𝗂𝗄 <code>/withdraw [jumlah]</code> untuk menarik saldo.\n` +
    `<b>𝖢𝗈𝗇𝗍𝗈𝗁 :</b> <code>/withdraw 50000</code>\n` +
    `<b>𝖬𝗂𝗇𝗂𝗆𝖺𝗅 :</b> Rp 1.000</blockquote>`;
  
  ctx.editMessageText(infoText, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "menu_owner" }]
      ]
    }
  }).catch(() => {
    ctx.reply(infoText, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔙 𝗞𝗲𝗺𝗯𝗮𝗹𝗶", callback_data: "menu_owner" }]
        ]
      }
    });
  });
  
  ctx.answerCbQuery();
});

bot.command("cancel", (ctx) => cancelTransaction(ctx));
bot.action("cancel_trx", (ctx) => cancelTransaction(ctx));
async function cancelTransaction(ctx) {
  const userId = ctx.from.id;
  
  if (activeTransactions[userId]) {
    try {
      if (activeTransactions[userId].messageId) {
        await ctx.deleteMessage(activeTransactions[userId].messageId).catch(() => {});
      }
    } catch (e) {}
    
    delete activeTransactions[userId];
    
    if (userState[userId]) {
      delete userState[userId];
    }
    
    await safeReply(ctx, "<blockquote>✅ <b>Transaksi dibatalkan.</b></blockquote>", { parse_mode: "HTML" });
  } else {
    await safeReply(ctx, "<blockquote>⚠️ <b>Tidak ada transaksi aktif.</b></blockquote>", { parse_mode: "HTML" });
  }
  
  if (ctx.updateType === 'callback_query') {
    try {
      await ctx.answerCbQuery();
    } catch (e) {}
  }
}

// Tambahkan command baru
bot.command("guide", async (ctx) => {
    await showFullGuide(ctx);
});

bot.command("panduan", async (ctx) => {
    await showFullGuide(ctx);
});

bot.command("deposithelp", async (ctx) => {
    await showDepositGuide(ctx);
});

bot.command("nokoshelp", async (ctx) => {
    await showNokosGuide(ctx);
});

bot.command("ytsearch", async (ctx) => {
  const query = ctx.message.text.split(" ").slice(1).join(" ");
  if (!query) return safeReply(ctx, "<blockquote>❌ <b>Gunakan:</b> <code>/ytsearch judul lagu / keyword</code></blockquote>", { parse_mode: "HTML" });

  try {
    await safeReply(ctx, "<blockquote>🔍 <b>Mencari video di YouTube...</b></blockquote>", { parse_mode: "HTML" });

    const api = `https://api-ralzz.vercel.app/search/youtube?apikey=ubot&q=${encodeURIComponent(query)}`;
    const res = await axios.get(api);

    if (!res.data || !res.data.result || res.data.result.length === 0) {
      return safeReply(ctx, "<blockquote>❌ <b>Tidak ada hasil ditemukan.</b></blockquote>", { parse_mode: "HTML" });
    }

    const results = res.data.result.slice(0, 10); 

    results.forEach((vid, i) => {
      const text =
`<b>🎬 ${vid.title}</b>
<b>👤 Channel:</b> ${vid.author?.name || "-"}
<b>⏱ Durasi:</b> ${vid.duration?.timestamp || "-"}
<b>👁 Views:</b> ${vid.views?.toLocaleString() || "-"}

<b>🔗</b> ${vid.url}`;

      safeReply(ctx, text, { parse_mode: "HTML" });
    });

  } catch (err) {
    console.error(err);
    safeReply(ctx, "<blockquote>❌ <b>Error mengambil data pencarian YouTube.</b></blockquote>", { parse_mode: "HTML" });
  }
});

// Perbaiki command /batal untuk menangani panel juga
bot.command("batal", (ctx) => {
  const userId = ctx.from.id;
  
  // Cancel panel order
  if (userState[userId]?.step === "PANEL_WAITING_USERNAME") {
    delete userState[userId];
    return safeReply(ctx, "❌ 𝗣𝗲𝗺𝗲𝘀𝗮𝗻𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗗𝗶𝗯𝗮𝘁𝗮𝗹𝗸𝗮𝗻.");
  }
  
  // ... kode lainnya tetap sama
  if (liveChatState[ctx.from.id]?.step === "WAITING_MESSAGE") {
    delete liveChatState[ctx.from.id];
    return safeReply(ctx, "❌ 𝗣𝗲𝗻𝗴𝗶𝗿𝗶𝗺𝗮𝗻 𝗣𝗲𝘀𝗮𝗻 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗗𝗶𝗯𝗮𝘁𝗮𝗹𝗸𝗮𝗻.");
  }
  if (ownerReplyState[ctx.from.id]) {
    delete ownerReplyState[ctx.from.id];
    return safeReply(ctx, "❌ 𝗠𝗼𝗱𝗲 𝗕𝗮𝗹𝗮𝘀𝗮𝗻 𝗢𝘄𝗻𝗲𝗿 𝗗𝗶𝗵𝗲𝗻𝘁𝗶𝗸𝗮𝗻.");
  }
  if (userState[ctx.from.id]?.step === "WAITING_BROADCAST" && ctx.from.id === config.ownerId) {
    delete userState[ctx.from.id];
    return safeReply(ctx, "❌ 𝗕𝗿𝗼𝗮𝗱𝗰𝗮𝘀𝘁 𝗗𝗶𝗯𝗮𝘁𝗮𝗹𝗸𝗮𝗻.");
  }
  return; 
});

bot.command("ssweb", async (ctx) => {
  const url = ctx.message.text.split(" ")[1];
  if (!url) return safeReply(ctx, "<blockquote>❌ <b>Gunakan:</b> <code>/ssweb url</code></blockquote>", { parse_mode: "HTML" });

  try {
    safeReply(ctx, "<blockquote>⏳ <b>Mengambil screenshot...</b></blockquote>", { parse_mode: "HTML" });

    const api = `https://api-ralzz.vercel.app/tools/ssweb?apikey=ubot&url=${encodeURIComponent(url)}`;
    const res = await axios.get(api);

    if (!res.data || !res.data.result) {
      return safeReply(ctx, "<blockquote>❌ <b>Gagal mengambil screenshot.</b></blockquote>", { parse_mode: "HTML" });
    }

    await ctx.replyWithPhoto(res.data.result, {
      caption: "<blockquote>✅ <b>Screenshot berhasil!</b></blockquote>",
      parse_mode: "HTML"
    });

  } catch (err) {
    console.error(err);
    safeReply(ctx, "<blockquote>❌ <b>Error: tidak bisa mengambil screenshot.</b></blockquote>", { parse_mode: "HTML" });
  }
});

bot.command("makeqr", async(ctx) => {
  const txt = ctx.message.text.replace("/makeqr", "").trim();
  if (!txt) return safeReply(ctx, "<blockquote><b>Gunakan:</b> <code>/makeqr teks</code></blockquote>", { parse_mode: "HTML" });
  ctx.replyWithPhoto(`https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(txt)}`);
});

bot.command("tiktokmp4", async (ctx) => {
  const url = ctx.message.text.split(" ")[1];
  if (!url) return safeReply(ctx, "<blockquote>❌ <b>Gunakan:</b> <code>/tiktok url</code></blockquote>", { parse_mode: "HTML" });
  try {
    safeReply(ctx, "<blockquote>⏳ <b>Mengambil video TikTok...</b></blockquote>", { parse_mode: "HTML" });
    const res = await axios.get(`https://api-ralzz.vercel.app/download/tiktok?apikey=ubot&url=${encodeURIComponent(url)}`);
    if (!res.data.result.video_sd) return safeReply(ctx, "<blockquote>❌ <b>Gagal mengambil video!</b></blockquote>", { parse_mode: "HTML" });
    await ctx.replyWithVideo(res.data.video_sd, { caption: "<blockquote>✅ <b>TikTok Tanpa Watermark</b></blockquote>", parse_mode: "HTML" });
  } catch (e) { console.log(e); safeReply(ctx, "<blockquote>❌ <b>Error: tidak bisa download TikTok.</b></blockquote>", { parse_mode: "HTML" }); }
});

bot.command("ytmp3", async (ctx) => {
  const url = ctx.message.text.split(" ")[1];
  if (!url) return safeReply(ctx, "<blockquote><b>Gunakan:</b> <code>/ytmp3 url</code></blockquote>", { parse_mode: "HTML" });
  safeReply(ctx, "<blockquote>⏳ <b>Mengambil audio...</b></blockquote>", { parse_mode: "HTML" });
  try {
    const res = await axios.get(`https://api-ralzz.vercel.app/download/ytmp3v2?apikey=ubot&url=${encodeURIComponent(url)}`);
    await ctx.replyWithAudio(res.data.result, { caption: "<blockquote>🎵 <b>YouTube Audio Downloaded</b></blockquote>", parse_mode: "HTML" });
  } catch (e) { safeReply(ctx, "<blockquote>❌ <b>Gagal mengambil audio.</b></blockquote>", { parse_mode: "HTML" }); }
});

bot.command("shorten", async (ctx) => {
  const url = ctx.message.text.split(" ")[1];
  if (!url) return safeReply(ctx, "<blockquote><b>Gunakan:</b> <code>/shorten url</code></blockquote>", { parse_mode: "HTML" });
  try {
    const res = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
    safeReply(ctx, `<blockquote><b>🔗 Shortened URL:</b>\n${res.data}</blockquote>`, { parse_mode: "HTML" });
  } catch (e) { safeReply(ctx, "<blockquote>❌ <b>Gagal memendekkan URL.</b></blockquote>", { parse_mode: "HTML" }); }
});

bot.command("checkerror", async (ctx) => {
    if (!ctx.message.reply_to_message?.document)
        return safeReply(ctx, "<blockquote>❌ <b>Reply file untuk dianalisa!</b></blockquote>", { parse_mode: "HTML" });

    const file = ctx.message.reply_to_message.document;
    const fileId = file.file_id;
    const fileName = file.file_name;

    const limit = updateUserLimit(ctx.from.id);
    if (limit < 0) return safeReply(ctx, "<blockquote>❌ <b>Limit habis!</b> Upgrade ke premium.</blockquote>", { parse_mode: "HTML" });

    try {
        safeReply(ctx, "<blockquote>📥 <b>Mengunduh & menganalisa file...</b></blockquote>", { parse_mode: "HTML" });

        const buff = await downloadFile(fileId);
        const content = getFileContent(buff);

        const analysis = await analyzeErrorWithGemini(content, fileName);

        safeReply(ctx, `<b>📄 Hasil Analisis:</b>\n\n${analysis}\n\n<b>Sisa limit:</b> ${getUserLimit(ctx.from.id)}`,
            { parse_mode: "HTML" }
        );
    } catch (err) {
        safeReply(ctx, "<blockquote>❌ <b>Error:</b></blockquote>" + err.message, { parse_mode: "HTML" });
    }
});

bot.command("fixerror", async (ctx) => {
    if (!ctx.message.reply_to_message?.document)
        return safeReply(ctx, "❌ <b>Reply file untuk diperbaiki!</b>", { parse_mode: "HTML" });

    const file = ctx.message.reply_to_message.document;
    const fileId = file.file_id;
    const fileName = file.file_name;

    const limit = updateUserLimit(ctx.from.id);
    if (limit < 0) return safeReply(ctx, "❌ <b>Limit habis!</b> Upgrade ke premium.", { parse_mode: "HTML" });

    try {
        safeReply(ctx, "🔧 <b>Memperbaiki error dengan Gemini...</b>", { parse_mode: "HTML" });

        const buff = await downloadFile(fileId);
        const content = getFileContent(buff);

        const fixed = await fixErrorWithGemini(content, fileName);

        ctx.replyWithDocument(
            { source: Buffer.from(fixed), filename: `fixed_${fileName}` },
            { caption: `✔ <b>Error berhasil diperbaiki!</b>\n<b>Sisa limit:</b> ${getUserLimit(ctx.from.id)}`, parse_mode: "HTML" }
        );
    } catch (err) {
        safeReply(ctx, "❌ <b>Error:</b> " + err.message, { parse_mode: "HTML" });
    }
});

bot.command("qc", async (ctx) => {
  try {
    const reply = ctx.message.reply_to_message;

    if (!reply) {
      return ctx.reply(
        "❌ <b>Contoh penggunaan:</b> <code>/qc (reply pesan)</code>",
        { parse_mode: "HTML" }
      );
    }

    const target = reply.forward_from || reply.from;
    const username = target.first_name || "User";

    let avatarUrl = "https://files.catbox.moe/nwvkbt.png";

    try {
      const photos = await ctx.telegram.getUserProfilePhotos(target.id, 0, 1);

      if (photos.total_count > 0) {
        const file = await ctx.telegram.getFileLink(photos.photos[0][0].file_id);
        avatarUrl = file.href;
      }
    } catch (err) {
      console.log("Avatar fetch error:", err);
    }

    const messageText = reply.text || reply.caption || "(pesan tidak berisi teks)";

    const payload = {
      type: "quote",
      format: "png",
      backgroundColor: "#000000",
      width: 512,
      height: 768,
      scale: 2,
      messages: [
        {
          entities: [],
          avatar: true,
          from: {
            id: target.id,
            name: username,
            photo: { url: avatarUrl },
          },
          text: messageText,
          replyMessage: {},
        },
      ],
    };

    const loading = await ctx.reply(
      `<blockquote>⏳ <b>Membuat sticker quote...</b></blockquote>`,
      { parse_mode: "HTML" }
    );

    const result = await axios.post(
      "https://bot.lyo.su/quote/generate",
      payload,
      { headers: { "Content-Type": "application/json" } }
    );

    const buffer = Buffer.from(result.data.result.image, "base64");

    await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id);

    await ctx.replyWithSticker({ source: buffer });
  } catch (err) {
    console.error("QC ERROR:", err);
    return ctx.reply(
      `<blockquote>❌ <b>Terjadi kesalahan saat membuat sticker.</b></blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});

bot.command("brat", async (ctx) => {
  const text = ctx.message.text.split(" ").slice(1).join(" ");

  if (!text) {
    return ctx.reply("❌ <b>Contoh:</b> <code>/brat (kata-kata)</code>", {
      parse_mode: "HTML"
    });
  }

  const chatId = ctx.chat.id;
  const tempFilePath = "./brat_temp.webp";

  try {
    await ctx.reply("<blockquote>⏳ <b>Membuat sticker, tunggu sebentar...</b></blockquote>", { parse_mode: "HTML" });

    const imageUrl = `https://kepolu-brat.hf.space/brat?q=${encodeURIComponent(text)}`;

    const downloadFile = async (url, dest) => {
      const writer = fs.createWriteStream(dest);

      const response = await axios({
        url,
        method: "GET",
        responseType: "stream",
      });

      response.data.pipe(writer);

      return new Promise((resolve, reject) => {
        writer.on("finish", resolve);
        writer.on("error", reject);
      });
    };

    await downloadFile(imageUrl, tempFilePath);

    await ctx.replyWithSticker({ source: tempFilePath });

    fs.unlinkSync(tempFilePath);

  } catch (err) {
    console.error(err);
    ctx.reply("<blockquote>❌ <b>Terjadi kesalahan saat membuat sticker. Coba lagi nanti.</b></blockquote>", { parse_mode: "HTML" });
  }
});

async function uploadToCatbox(buffer, filename) {
  try {
    const form = new FormData();
    form.append('fileToUpload', buffer, { filename: filename });
    form.append('reqtype', 'fileupload');
    
    const response = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: {
        ...form.getHeaders()
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Upload error:', error);
    throw error;
  }
}


bot.command("tourl", async (ctx) => {
  try {
    const chatId = ctx.chat.id;
    const userId = ctx.from.id;

    const replyMsg = ctx.message.reply_to_message;
    if (!replyMsg) {
      return ctx.reply(
        `<blockquote>❌ <b>Balas sebuah pesan yang berisi file/audio/video dengan perintah /tourl</b></blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    if (
      !replyMsg.document &&
      !replyMsg.photo &&
      !replyMsg.video &&
      !replyMsg.audio &&
      !replyMsg.voice
    ) {
      return ctx.reply(
        `<blockquote>❌ <b>Pesan yang kamu balas tidak mengandung file/audio/video yang bisa diupload.</b></blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    let fileId, filename;

    if (replyMsg.document) {
      fileId = replyMsg.document.file_id;
      filename = replyMsg.document.file_name;
    } else if (replyMsg.photo) {
      const photoArray = replyMsg.photo;
      fileId = photoArray[photoArray.length - 1].file_id;
      filename = "photo.jpg";
    } else if (replyMsg.video) {
      fileId = replyMsg.video.file_id;
      filename = replyMsg.video.file_name || "video.mp4";
    } else if (replyMsg.audio) {
      fileId = replyMsg.audio.file_id;
      filename = replyMsg.audio.file_name || "audio.mp3";
    } else if (replyMsg.voice) {
      fileId = replyMsg.voice.file_id;
      filename = "voice.ogg";
    }

    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${config.botToken}/${file.file_path}`;

    const res = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const buffer = Buffer.from(res.data);

    const catboxUrl = await uploadToCatbox(buffer, filename);

    await ctx.reply(
      `<blockquote>✅ <b>File berhasil diupload ke Catbox:</b>\n<code>${catboxUrl}</code></blockquote>`,
      { parse_mode: "HTML" }
    );
  } catch (err) {
    console.error("tourl error:", err);
    
    const cleanError = err.message.replace(/</g, '&lt;').replace(/>/g, '&gt;');
    
    ctx.reply(
      `<blockquote>❌ <b>Gagal upload file:</b> ${cleanError}</blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});

// Command untuk menambah saldo manual oleh owner
bot.command("addsaldo", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return safeReply(ctx, "<blockquote>❌ <b>Hanya owner yang bisa menggunakan perintah ini!</b></blockquote>", { 
      parse_mode: "HTML" 
    });
  }

  const args = ctx.message.text.split(" ");
  if (args.length < 3) {
    return safeReply(ctx, 
      "<blockquote>💰 <b>Format:</b> <code>/addsaldo [user_id] [jumlah]</code>\n\n" +
      "<b>Contoh:</b> <code>/addsaldo 123456789 50000</code>\n" +
      "<b>Note:</b> Jumlah dalam angka tanpa titik/koma</blockquote>", 
      { parse_mode: "HTML" }
    );
  }

  const targetUserId = args[1];
  const amount = parseInt(args[2]);

  if (isNaN(amount) || amount <= 0) {
    return safeReply(ctx, "<blockquote>❌ <b>Jumlah harus angka positif!</b></blockquote>", { 
      parse_mode: "HTML" 
    });
  }

  try {
    // Path database saldo
    const dbSaldoPath = "./database/saldoOtp.json";
    let saldoData = {};
    
    // Load data saldo
    if (fs.existsSync(dbSaldoPath)) {
      try {
        saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
      } catch (err) {
        saldoData = {};
      }
    }

    // Tambah saldo
    const oldBalance = saldoData[targetUserId] || 0;
    saldoData[targetUserId] = oldBalance + amount;
    
    // Simpan ke database
    fs.writeFileSync(dbSaldoPath, JSON.stringify(saldoData, null, 2));
    
    // Kirim notifikasi ke owner
    await safeReply(ctx, 
      `<blockquote>✅ <b>SALDO BERHASIL DITAMBAHKAN</b>\n\n` +
      `<b>👤 User ID:</b> <code>${targetUserId}</code>\n` +
      `<b>💰 Jumlah:</b> ${toRupiah(amount)}\n` +
      `<b>📊 Saldo Lama:</b> ${toRupiah(oldBalance)}\n` +
      `<b>💳 Saldo Baru:</b> ${toRupiah(saldoData[targetUserId])}</blockquote>`, 
      { parse_mode: "HTML" }
    );

    // Coba kirim notifikasi ke user
    try {
      await bot.telegram.sendMessage(
        targetUserId,
        `<blockquote>💰 <b>SALDO ANDA DITAMBAHKAN OLEH OWNER</b>\n\n` +
        `<b>🔔 Status:</b> Deposit Manual\n` +
        `<b>💸 Jumlah:</b> ${toRupiah(amount)}\n` +
        `<b>📊 Saldo Sekarang:</b> ${toRupiah(saldoData[targetUserId])}\n\n` +
        `<i>Terima kasih telah menggunakan layanan kami!</i></blockquote>`,
        { parse_mode: "HTML" }
      );
    } catch (userErr) {
      console.log(`Tidak bisa mengirim notifikasi ke user ${targetUserId}:`, userErr.message);
    }

  } catch (error) {
    console.error("[ERROR] addsaldo:", error);
    safeReply(ctx, `<blockquote>❌ <b>Gagal menambah saldo:</b> ${error.message}</blockquote>`, { 
      parse_mode: "HTML" 
    });
  }
});

// Command untuk cek saldo user oleh owner
bot.command("ceksaldo", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return safeReply(ctx, "<blockquote>❌ <b>Hanya owner yang bisa menggunakan perintah ini!</b></blockquote>", { 
      parse_mode: "HTML" 
    });
  }

  const args = ctx.message.text.split(" ");
  let targetUserId;
  
  if (args.length > 1) {
    // Cek saldo user tertentu
    targetUserId = args[1];
  } else if (ctx.message.reply_to_message) {
    // Cek saldo user yang di-reply
    targetUserId = ctx.message.reply_to_message.from.id;
  } else {
    return safeReply(ctx, 
      "<blockquote>👤 <b>Format:</b>\n" +
      "<code>/ceksaldo [user_id]</code>\n" +
      "atau\n" +
      "<b>Reply pesan user dengan</b> <code>/ceksaldo</code></blockquote>", 
      { parse_mode: "HTML" }
    );
  }

  try {
    // Path database saldo
    const dbSaldoPath = "./database/saldoOtp.json";
    let saldoData = {};
    
    if (fs.existsSync(dbSaldoPath)) {
      try {
        saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
      } catch (err) {
        saldoData = {};
      }
    }

    const userBalance = saldoData[targetUserId] || 0;
    
    // Coba dapatkan info user
    let userInfo = `ID: <code>${targetUserId}</code>`;
    try {
      const user = await bot.telegram.getChat(targetUserId);
      const username = user.username ? `@${user.username}` : '-';
      const name = `${user.first_name || ""} ${user.last_name || ""}`.trim();
      userInfo = `<b>👤 Nama:</b> ${name}\n<b>📛 Username:</b> ${username}\n<b>🆔 ID:</b> <code>${targetUserId}</code>`;
    } catch (infoErr) {
      // Jika gagal mendapatkan info user, tetap lanjut
    }

    await safeReply(ctx,
      `<blockquote>💰 <b>INFO SALDO USER</b>\n\n` +
      `${userInfo}\n` +
      `<b>💳 Saldo:</b> ${toRupiah(userBalance)}</blockquote>`,
      { parse_mode: "HTML" }
    );

  } catch (error) {
    console.error("[ERROR] ceksaldo:", error);
    safeReply(ctx, `<blockquote>❌ <b>Gagal cek saldo:</b> ${error.message}</blockquote>`, { 
      parse_mode: "HTML" 
    });
  }
});

// Command untuk user cek saldo sendiri
bot.command("saldo", async (ctx) => {
  const userId = ctx.from.id;
  
  try {
    // Path database saldo
    const dbSaldoPath = "./database/saldoOtp.json";
    let saldoData = {};
    
    if (fs.existsSync(dbSaldoPath)) {
      try {
        saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
      } catch (err) {
        saldoData = {};
      }
    }

    const userBalance = saldoData[userId] || 0;
    const username = ctx.from.username ? `@${ctx.from.username}` : '-';
    const name = `${ctx.from.first_name || ""} ${ctx.from.last_name || ""}`.trim();

    const message = 
      `<blockquote>💰 <b>INFO SALDO ANDA</b>\n\n` +
      `<b>👤 Nama:</b> ${name}\n` +
      `<b>📛 Username:</b> ${username}\n` +
      `<b>🆔 ID:</b> <code>${userId}</code>\n\n` +
      `<b>💳 Saldo Tersedia:</b> ${toRupiah(userBalance)}\n\n` +
      `<i>💡 Gunakan saldo untuk order nokos, SMM, atau layanan lainnya!</i></blockquote>`;

    const keyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: "➕ Deposit Saldo", callback_data: "topup_nokos" }],
          [{ text: "🛒 Order Nokos", callback_data: "choose_service" }],
          [{ text: "🔥 Order SMM", callback_data: "smm_menu" }],
          [{ text: "🔙 Menu Utama", callback_data: "back_home" }]
        ]
      }
    };

    await safeReply(ctx, message, {
      parse_mode: "HTML",
      ...keyboard
    });

  } catch (error) {
    console.error("[ERROR] saldo command:", error);
    safeReply(ctx, "<blockquote>❌ <b>Gagal mengambil data saldo. Silakan coba lagi.</b></blockquote>", { 
      parse_mode: "HTML" 
    });
  }
});

// Command untuk mengurangi/hapus saldo manual oleh owner
bot.command("delsaldo", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return safeReply(ctx, "<blockquote>❌ <b>Hanya owner yang bisa menggunakan perintah ini!</b></blockquote>", { 
      parse_mode: "HTML" 
    });
  }

  const args = ctx.message.text.split(" ");
  if (args.length < 3) {
    return safeReply(ctx, 
      "<blockquote>💰 <b>Format:</b> <code>/delsaldo [user_id] [jumlah]</code>\n\n" +
      "<b>Contoh:</b>\n" +
      "<code>/delsaldo 123456789 50000</code> - Kurangi 50k\n" +
      "<code>/delsaldo 123456789 all</code> - Hapus semua saldo\n" +
      "<code>/delsaldo 123456789 reset</code> - Reset ke 0\n\n" +
      "<b>Note:</b> Jumlah dalam angka tanpa titik/koma</blockquote>", 
      { parse_mode: "HTML" }
    );
  }

  const targetUserId = args[1];
  const amountArg = args[2].toLowerCase();

  try {
    // Path database saldo
    const dbSaldoPath = "./database/saldoOtp.json";
    let saldoData = {};
    
    // Load data saldo
    if (fs.existsSync(dbSaldoPath)) {
      try {
        saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
      } catch (err) {
        saldoData = {};
      }
    }

    const oldBalance = saldoData[targetUserId] || 0;
    let newBalance = oldBalance;
    let amount = 0;
    let actionType = "";
    let reason = "";

    // Proses berdasarkan parameter
    if (amountArg === "all" || amountArg === "reset") {
      // Hapus semua saldo
      amount = oldBalance;
      newBalance = 0;
      actionType = "reset";
      reason = "Reset saldo oleh owner";
    } else {
      // Kurangi saldo dengan jumlah tertentu
      amount = parseInt(amountArg);
      
      if (isNaN(amount) || amount <= 0) {
        return safeReply(ctx, "<blockquote>❌ <b>Jumlah harus angka positif atau 'all/reset'!</b></blockquote>", { 
          parse_mode: "HTML" 
        });
      }

      if (amount > oldBalance) {
        // Jika jumlah lebih besar dari saldo, set ke 0
        amount = oldBalance;
        newBalance = 0;
        actionType = "force_reset";
        reason = `Pengurangan paksa (lebih dari saldo) oleh owner`;
      } else {
        newBalance = oldBalance - amount;
        actionType = "reduce";
        reason = `Pengurangan saldo oleh owner`;
      }
    }

    // Update saldo
    saldoData[targetUserId] = newBalance;
    
    // Simpan ke database
    fs.writeFileSync(dbSaldoPath, JSON.stringify(saldoData, null, 2));
    
    // Log ke file khusus untuk tracking
    const logPath = "./database/saldo_logs.json";
    let logs = [];
    
    if (fs.existsSync(logPath)) {
      try {
        logs = JSON.parse(fs.readFileSync(logPath, "utf8"));
      } catch (err) {
        logs = [];
      }
    }
    
    logs.push({
      userId: targetUserId,
      amount: -amount, // Negatif karena pengurangan
      oldBalance: oldBalance,
      newBalance: newBalance,
      reason: reason,
      timestamp: new Date().toISOString(),
      type: actionType
    });
    
    fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));
    
    // Kirim notifikasi ke owner
    let message = `<blockquote>✅ <b>SALDO BERHASIL DI${actionType === 'reset' ? 'RESET' : 'DIKURANGI'}</b>\n\n` +
      `<b>👤 User ID:</b> <code>${targetUserId}</code>\n` +
      `<b>💰 Jumlah:</b> ${toRupiah(amount)} (${actionType})\n` +
      `<b>📊 Saldo Lama:</b> ${toRupiah(oldBalance)}\n` +
      `<b>💳 Saldo Baru:</b> ${toRupiah(newBalance)}</blockquote>`;
    
    await safeReply(ctx, message, { parse_mode: "HTML" });

    // Coba kirim notifikasi ke user
    try {
      let userMessage = "";
      
      if (actionType === "reset") {
        userMessage = `<blockquote>⚠️ <b>SALDO ANDA DIRESET OLEH OWNER</b>\n\n` +
          `<b>🔔 Status:</b> Reset Saldo\n` +
          `<b>💸 Jumlah Dihapus:</b> ${toRupiah(amount)}\n` +
          `<b>📊 Saldo Sekarang:</b> ${toRupiah(newBalance)}\n\n` +
          `<i>Hubungi owner jika ada kesalahan.</i></blockquote>`;
      } else {
        userMessage = `<blockquote>⚠️ <b>SALDO ANDA DIKURANGI OLEH OWNER</b>\n\n` +
          `<b>🔔 Status:</b> Pengurangan Saldo\n` +
          `<b>💸 Jumlah Dikurangi:</b> ${toRupiah(amount)}\n` +
          `<b>📊 Saldo Sekarang:</b> ${toRupiah(newBalance)}\n\n` +
          `<i>Hubungi owner jika ada kesalahan.</i></blockquote>`;
      }
      
      await bot.telegram.sendMessage(targetUserId, userMessage, { parse_mode: "HTML" });
    } catch (userErr) {
      console.log(`Tidak bisa mengirim notifikasi ke user ${targetUserId}:`, userErr.message);
    }

  } catch (error) {
    console.error("[ERROR] delsaldo:", error);
    safeReply(ctx, `<blockquote>❌ <b>Gagal mengurangi saldo:</b> ${error.message}</blockquote>`, { 
      parse_mode: "HTML" 
    });
  }
});

// Command untuk menghapus user dari database saldo
bot.command("removeuser", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return safeReply(ctx, "<blockquote>❌ <b>Hanya owner yang bisa menggunakan perintah ini!</b></blockquote>", { 
      parse_mode: "HTML" 
    });
  }

  const args = ctx.message.text.split(" ");
  if (args.length < 2) {
    return safeReply(ctx, 
      "<blockquote>🗑️ <b>Format:</b> <code>/removeuser [user_id]</code>\n\n" +
      "<b>Contoh:</b>\n" +
      "<code>/removeuser 123456789</code>\n\n" +
      "<b>Perhatian:</b> Aksi ini akan menghapus user dari database saldo sepenuhnya!</blockquote>", 
      { parse_mode: "HTML" }
    );
  }

  const targetUserId = args[1];

  try {
    // Path database saldo
    const dbSaldoPath = "./database/saldoOtp.json";
    let saldoData = {};
    
    // Load data saldo
    if (fs.existsSync(dbSaldoPath)) {
      try {
        saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
      } catch (err) {
        saldoData = {};
      }
    }

    const oldBalance = saldoData[targetUserId] || 0;
    
    if (typeof saldoData[targetUserId] === 'undefined') {
      return safeReply(ctx, `<blockquote>❌ <b>User tidak ditemukan dalam database saldo!</b></blockquote>`, { 
        parse_mode: "HTML" 
      });
    }

    // Hapus user dari database
    delete saldoData[targetUserId];
    
    // Simpan ke database
    fs.writeFileSync(dbSaldoPath, JSON.stringify(saldoData, null, 2));
    
    // Log ke file khusus untuk tracking
    const logPath = "./database/saldo_logs.json";
    let logs = [];
    
    if (fs.existsSync(logPath)) {
      try {
        logs = JSON.parse(fs.readFileSync(logPath, "utf8"));
      } catch (err) {
        logs = [];
      }
    }
    
    logs.push({
      userId: targetUserId,
      amount: -oldBalance,
      oldBalance: oldBalance,
      newBalance: 0,
      reason: "User dihapus dari database oleh owner",
      timestamp: new Date().toISOString(),
      type: "delete_user"
    });
    
    fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));
    
    // Kirim notifikasi ke owner
    await safeReply(ctx, 
      `<blockquote>✅ <b>USER BERHASIL DIHAPUS DARI DATABASE</b>\n\n` +
      `<b>👤 User ID:</b> <code>${targetUserId}</code>\n` +
      `<b>💰 Saldo Dihapus:</b> ${toRupiah(oldBalance)}\n` +
      `<b>📊 Status:</b> User dihapus sepenuhnya dari database</blockquote>`, 
      { parse_mode: "HTML" }
    );

  } catch (error) {
    console.error("[ERROR] removeuser:", error);
    safeReply(ctx, `<blockquote>❌ <b>Gagal menghapus user:</b> ${error.message}</blockquote>`, { 
      parse_mode: "HTML" 
    });
  }
});

// Command untuk melihat top user dengan saldo terbanyak
bot.command("topbalance", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return safeReply(ctx, "<blockquote>❌ <b>Hanya owner yang bisa menggunakan perintah ini!</b></blockquote>", { 
      parse_mode: "HTML" 
    });
  }

  const args = ctx.message.text.split(" ");
  const limit = args.length > 1 ? parseInt(args[1]) : 10;

  if (isNaN(limit) || limit <= 0 || limit > 50) {
    return safeReply(ctx, "<blockquote>❌ <b>Limit harus angka 1-50!</b></blockquote>", { 
      parse_mode: "HTML" 
    });
  }

  try {
    // Path database saldo
    const dbSaldoPath = "./database/saldoOtp.json";
    let saldoData = {};
    
    if (fs.existsSync(dbSaldoPath)) {
      try {
        saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
      } catch (err) {
        saldoData = {};
      }
    }

    // Konversi ke array dan sort by balance
    const usersArray = Object.entries(saldoData)
      .map(([userId, balance]) => ({ userId, balance }))
      .filter(user => user.balance > 0) // Hanya user dengan saldo > 0
      .sort((a, b) => b.balance - a.balance)
      .slice(0, limit);

    if (usersArray.length === 0) {
      return safeReply(ctx, "<blockquote>📭 <b>Tidak ada user dengan saldo positif.</b></blockquote>", { 
        parse_mode: "HTML" 
      });
    }

    let message = `<blockquote>🏆 <b>TOP ${limit} USER BERDASARKAN SALDO</b>\n\n`;
    let totalAllBalance = 0;

    for (let i = 0; i < usersArray.length; i++) {
      const user = usersArray[i];
      totalAllBalance += user.balance;
      
      // Coba dapatkan info user
      let userInfo = `ID: <code>${user.userId}</code>`;
      try {
        const userData = await bot.telegram.getChat(user.userId);
        const username = userData.username ? `@${userData.username}` : '-';
        const name = `${userData.first_name || ""} ${userData.last_name || ""}`.trim();
        userInfo = `${name} (${username})`;
      } catch (infoErr) {
        // Jika gagal mendapatkan info user, tetap lanjut
      }

      const rankEmoji = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i+1}.`;
      
      message += `<b>${rankEmoji} ${userInfo}</b>\n`;
      message += `<code>   Saldo:</code> ${toRupiah(user.balance)}\n\n`;
    }

    message += `<b>📊 TOTAL SEMUA SALDO:</b> ${toRupiah(totalAllBalance)}\n`;
    message += `<b>👥 TOTAL USER:</b> ${usersArray.length}</blockquote>`;

    await safeReply(ctx, message, { 
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔄 Refresh", callback_data: "refresh_top_balance" }],
          [{ text: "📋 Export", callback_data: "export_top_balance" }],
          [{ text: "🔙 Menu Owner", callback_data: "menu_owner" }]
        ]
      }
    });

  } catch (error) {
    console.error("[ERROR] topbalance:", error);
    safeReply(ctx, `<blockquote>❌ <b>Gagal mengambil data top balance:</b> ${error.message}</blockquote>`, { 
      parse_mode: "HTML" 
    });
  }
});

// Command untuk statistik saldo
bot.command("statssaldo", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return safeReply(ctx, "<blockquote>❌ <b>Hanya owner yang bisa menggunakan perintah ini!</b></blockquote>", { 
      parse_mode: "HTML" 
    });
  }

  try {
    // Path database saldo
    const dbSaldoPath = "./database/saldoOtp.json";
    let saldoData = {};
    
    if (fs.existsSync(dbSaldoPath)) {
      try {
        saldoData = JSON.parse(fs.readFileSync(dbSaldoPath, "utf8"));
      } catch (err) {
        saldoData = {};
      }
    }

    // Hitung statistik
    const totalUsers = Object.keys(saldoData).length;
    const usersWithBalance = Object.values(saldoData).filter(balance => balance > 0).length;
    const usersZeroBalance = Object.values(saldoData).filter(balance => balance === 0).length;
    const totalBalance = Object.values(saldoData).reduce((sum, balance) => sum + balance, 0);
    
    // Top 3 user
    const topUsers = Object.entries(saldoData)
      .map(([userId, balance]) => ({ userId, balance }))
      .sort((a, b) => b.balance - a.balance)
      .slice(0, 3);

    let message = `<blockquote>📊 <b>STATISTIK SALDO SISTEM</b>\n\n`;
    message += `<b>👥 Total User dalam DB:</b> ${totalUsers}\n`;
    message += `<b>💰 User dengan Saldo > 0:</b> ${usersWithBalance}\n`;
    message += `<b>📭 User dengan Saldo 0:</b> ${usersZeroBalance}\n`;
    message += `<b>💵 Total Saldo Semua User:</b> ${toRupiah(totalBalance)}\n\n`;

    if (topUsers.length > 0) {
      message += `<b>🏆 TOP 3 SALDO TERTINGGI:</b>\n`;
      
      for (let i = 0; i < topUsers.length; i++) {
        const user = topUsers[i];
        const rankEmoji = i === 0 ? "🥇" : i === 1 ? "🥈" : "🥉";
        
        try {
          const userData = await bot.telegram.getChat(user.userId);
          const username = userData.username ? `@${userData.username}` : '-';
          const name = `${userData.first_name || ""}`;
          message += `${rankEmoji} <b>${name}</b> (${username}): ${toRupiah(user.balance)}\n`;
        } catch (infoErr) {
          message += `${rankEmoji} <code>${user.userId}</code>: ${toRupiah(user.balance)}\n`;
        }
      }
    }

    message += `\n<i>Update: ${new Date().toLocaleString('id-ID')}</i></blockquote>`;

    await safeReply(ctx, message, { 
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🔄 Refresh", callback_data: "refresh_stats_saldo" }],
          [{ text: "📋 Detail", callback_data: "detail_stats_saldo" }],
          [{ text: "🔙 Menu Owner", callback_data: "menu_owner" }]
        ]
      }
    });

  } catch (error) {
    console.error("[ERROR] statssaldo:", error);
    safeReply(ctx, `<blockquote>❌ <b>Gagal mengambil statistik:</b> ${error.message}</blockquote>`, { 
      parse_mode: "HTML" 
    });
  }
});

// Command untuk melihat log saldo (owner only)
bot.command("logsaldo", async (ctx) => {
  if (ctx.from.id !== config.ownerId) {
    return safeReply(ctx, "<blockquote>❌ <b>Akses ditolak!</b></blockquote>", { 
      parse_mode: "HTML" 
    });
  }

  try {
    const logPath = "./database/saldo_logs.json";
    
    if (!fs.existsSync(logPath)) {
      return safeReply(ctx, "<blockquote>📭 <b>Belum ada log saldo.</b></blockquote>", { 
        parse_mode: "HTML" 
      });
    }
    
    const logs = JSON.parse(fs.readFileSync(logPath, "utf8"));
    
    if (logs.length === 0) {
      return safeReply(ctx, "<blockquote>📭 <b>Belum ada log saldo.</b></blockquote>", { 
        parse_mode: "HTML" 
      });
    }
    
    // Tampilkan 10 log terakhir
    const recentLogs = logs.slice(-10).reverse();
    
    let message = "<blockquote>📊 <b>10 LOG SALDO TERAKHIR</b>\n\n";
    
    recentLogs.forEach((log, index) => {
      const date = new Date(log.timestamp).toLocaleString("id-ID");
      message += `<b>${index + 1}.</b> <code>${log.userId}</code>\n`;
      message += `   💰: ${toRupiah(log.amount)} (${log.type})\n`;
      message += `   ⏰: ${date}\n`;
      message += `   📝: ${log.reason}\n\n`;
    });
    
    message += `<i>Total log: ${logs.length}</i></blockquote>`;
    
    await safeReply(ctx, message, { 
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🗑️ Hapus Log", callback_data: "clear_saldo_logs" }],
          [{ text: "📋 Export Log", callback_data: "export_saldo_logs" }],
          [{ text: "🔙 Menu Owner", callback_data: "menu_owner" }]
        ]
      }
    });
    
  } catch (error) {
    console.error("[ERROR] logsaldo:", error);
    safeReply(ctx, `<blockquote>❌ <b>Gagal membaca log:</b> ${error.message}</blockquote>`, { 
      parse_mode: "HTML" 
    });
  }
});


// PERBAIKAN: Handler untuk cek pembayaran QRIS panel
bot.action(/^check_payment_panel_(.+)$/, async (ctx) => {
    try {
        await ctx.answerCbQuery("🔍 Memeriksa status pembayaran...");
        
        const paymentId = ctx.match[1];
        const userId = ctx.from.id;
        const state = userState[userId];
        
        if (!state || !state.panelOrder) {
            return await ctx.answerCbQuery("❌ Sesi kadaluarsa!", { show_alert: true });
        }
        
        const pkg = config.panel.packages[state.panelOrder.pkgIndex];
        if (!pkg) {
            return await ctx.answerCbQuery("❌ Paket tidak ditemukan!", { show_alert: true });
        }
        
        // Cek status pembayaran
        const isPaid = await cekStatus(paymentId, pkg.price);
        
        if (!isPaid) {
            return await ctx.answerCbQuery(
                "⏳ Pembayaran belum diterima.\n\nSilahkan scan QRIS dan coba lagi dalam beberapa saat.", 
                { show_alert: true }
            );
        }
        
        // PEMBAYARAN SUKSES - BUAT PANEL
        await ctx.editMessageCaption(
            "✅ <b>PEMBAYARAN TERVERIFIKASI!</b>\n\n" +
            "⏳ Sedang membuat panel Anda...\n" +
            "<i>Proses membutuhkan 30-60 detik</i>",
            { parse_mode: "HTML" }
        ).catch(() => {});
        
        // Buat panel
        const panelResult = await createPanelAccount(
            state.panelOrder.username,
            pkg.ram,
            pkg.disk,
            pkg.cpu
        );
        
        if (panelResult.success) {
            // Hapus state
            delete userState[userId];
            
            // Kirim detail panel
            const successMsg = `<blockquote>✅ <b>PANEL BERHASIL DIBUAT!</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━━\n` +
                `<b>📊 DETAIL AKUN PANEL</b>\n` +
                `━━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<b>🌐 URL Login:</b>\n` +
                `<code>${panelResult.data.login}</code>\n\n` +
                `<b>👤 Username:</b>\n` +
                `<code>${panelResult.data.username}</code>\n\n` +
                `<b>🔐 Password:</b>\n` +
                `<code>${panelResult.data.password}</code>\n\n` +
                `<b>📧 Email:</b>\n` +
                `<code>${panelResult.data.email}</code>\n\n` +
                `<b>💾 Spesifikasi Server:</b>\n` +
                `• RAM: ${pkg.ram} MB\n` +
                `• Disk: ${pkg.disk} MB\n` +
                `• CPU: ${pkg.cpu}%\n` +
                `• Server ID: ${panelResult.data.serverId}\n\n` +
                `━━━━━━━━━━━━━━━━━━━━━\n` +
                `<b>⚠️ PENTING - SIMPAN DATA INI!</b>\n\n` +
                `<i>Terima kasih telah membeli! 🎉</i></blockquote>`;
            
            await ctx.reply(successMsg, { 
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "🌐 Login Panel", url: panelResult.data.login }],
                        [{ text: "📱 Menu Utama", callback_data: "shop_menu" }]
                    ]
                }
            });
            
            // Kirim testimoni
            try {
                if (typeof sendTestimoniKeChannel === 'function') {
                    await sendTestimoniKeChannel(
                        ctx.from.first_name || ctx.from.username || "User",
                        userId,
                        `Panel ${pkg.name}`,
                        pkg.price,
                        "panel",
                        {
                            orderId: panelResult.data.serverId,
                            domain: panelResult.data.login,
                            customerNote: "Panel berhasil dibuat via QRIS"
                        }
                    );
                }
            } catch (e) {
                console.log("[TESTIMONI] Error:", e.message);
            }
            
        } else {
            await ctx.reply(
                `<blockquote>❌ <b>PEMBAYARAN SUKSES TAPI GAGAL MEMBUAT PANEL!</b>\n\n` +
                `<b>Error:</b> ${panelResult.msg}\n\n` +
                `⚠️ <b>PENTING:</b>\n` +
                `Pembayaran Anda sudah kami terima, namun terjadi kesalahan saat membuat panel.\n\n` +
                `<b>Silakan hubungi admin dengan info berikut:</b>\n` +
                `• User ID: <code>${userId}</code>\n` +
                `• Username Panel: ${state.panelOrder.username}\n` +
                `• Paket: ${pkg.name}\n` +
                `• Payment ID: ${paymentId}\n\n` +
                `Panel akan dibuat manual untuk Anda.</blockquote>`,
                {
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "💬 Hubungi Admin", callback_data: "menu_owner_contact" }]
                        ]
                    }
                }
            );
            
            // Notif owner
            try {
                await bot.telegram.sendMessage(
                    config.ownerId,
                    `⚠️ <b>PANEL CREATION FAILED AFTER PAYMENT</b>\n\n` +
                    `User: ${userId}\n` +
                    `Username Panel: ${state.panelOrder.username}\n` +
                    `Package: ${pkg.name}\n` +
                    `Payment ID: ${paymentId}\n` +
                    `Error: ${panelResult.msg}\n\n` +
                    `BUTUH MANUAL CREATION!`,
                    { parse_mode: "HTML" }
                );
            } catch (e) {}
        }
        
    } catch (error) {
        console.error("[ERROR] check_payment_panel:", error);
        await ctx.answerCbQuery("❌ Terjadi kesalahan! Coba lagi.", { show_alert: true });
    }
});

bot.catch((err, ctx) => {
    console.error("Bot Error:", err);
    safeReply(ctx, "<blockquote>❌ <b>Terjadi kesalahan.</b></blockquote>", { parse_mode: "HTML" });
});

/**
 * Fungsi untuk membersihkan cache & state secara berkala
 */
function startCleanupInterval() {
  if (globalNokos.cleanupInterval) {
    clearInterval(globalNokos.cleanupInterval);
  }
  
  globalNokos.cleanupInterval = setInterval(() => {
    const now = Date.now();
    
    // Bersihkan cache yang sudah expired (30 detik)
    for (const orderId in globalNokos.apiCache) {
      if (now - globalNokos.apiCache[orderId].timestamp > 30000) {
        delete globalNokos.apiCache[orderId];
      }
    }
    
    // Bersihkan lastCheckTime yang sudah lama (1 jam)
    for (const orderId in globalNokos.lastCheckTime) {
      if (now - globalNokos.lastCheckTime[orderId] > 3600000) {
        delete globalNokos.lastCheckTime[orderId];
      }
    }
    
    // Hapus active orders yang sudah sangat lama (15 menit)
    for (const orderId in globalNokos.activeOrders) {
      const order = globalNokos.activeOrders[orderId];
      if (now - order.startTime > 900000) { // 15 menit
        delete globalNokos.activeOrders[orderId];
        delete globalNokos.apiCache[orderId];
        delete globalNokos.lastCheckTime[orderId];
      }
    }
    
  }, 60000); // Jalankan setiap 1 menit
}

// Jalankan cleanup saat bot start
startCleanupInterval();

// Fungsi untuk membersihkan order yang sudah expired
function cleanupExpiredOrders() {
    const now = Date.now();
    for (const orderId in globalNokos.activeOrders) {
        const order = globalNokos.activeOrders[orderId];
        if (now - order.startTime > 10 * 60 * 1000) { // 10 menit
            // Clear timer
            if (order.autoRefundTimer) {
                clearTimeout(order.autoRefundTimer);
            }
            delete globalNokos.activeOrders[orderId];
        }
    }
}

function startAutoCheckPayment(ctx, userId) {
    const trx = activeTransactions[userId];
    const interval = setInterval(async () => {
        if (!activeTransactions[userId]) return clearInterval(interval);

        const isPaid = await cekStatus(trx.id, trx.amount, trx.paymentConfig);
        if (isPaid) {
            clearInterval(interval);
            const productData = activeTransactions[userId].productData;
            delete activeTransactions[userId];
            
            await ctx.reply("✅ Pembayaran Berhasil Terverifikasi!");
            // Kirim produk otomatis setelah pembayaran sukses
            await sendProductToUser(ctx, productData);
        }
    }, 5000); // Cek setiap 5 detik
}

// Jalankan cleanup setiap 5 menit
setInterval(cleanupExpiredOrders, 5 * 60 * 1000);

bot.launch().catch((err) => {
  console.error("❌ Gagal connect ke Telegram:", err.message);
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));