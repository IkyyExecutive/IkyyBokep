module.exports = {
    // --- TELEGRAM SETTINGS ---
    botToken: "",
    ownerId: 1267554581,
    ownerName: "fiffonemsg market",
    ownerWa: "Tidak ada",
    ownerUser: "@fifonemsg",
    grubName: "-", // isi tanpa @ dan https://t.me/
    channelName: "fiffxxyzch", // isi tanpa @
    channelId: "@fiffxxyzch", // Contoh: "@botv8_channel"
    botName: "𝗔𝘂𝘁𝗼 𝗢𝗿𝗱𝗲𝗿 - 𝗙𝗶𝗳𝗳𝗼𝗻𝗲𝗺𝘀𝗴",
    startPhoto: "https://files.catbox.moe/gz4cf0.jpg",
    shopPhoto: "https://files.catbox.moe/t6msus.jpg",
    startAudio: "https://files.catbox.moe/lm61p4.mp3",
    startAudioCaption: "Welcome Auto order Fifonemsg",
    testimoniChannel: "@fiftestimoni",

    // --- NOTIFIKASI STOK KE CHANNEL ---
    stockChannelId: "@fiffxxyzch",
    stockNotificationPhoto: "https://files.catbox.moe/mognz6.jpg", // bisa pakai foto yang sama atau ganti

    // --- Nokos Setting ( Rumah Otp )
    RUMAHOTP: "otp_csklpXwCyFvDLPZu",
    UNTUNG_NOKOS: 1000,
    UNTUNG_DEPOSIT: 200,
    ppthumb: "https://files.catbox.moe/8tb93i.jpg",

    // --- Suntik Sosmed Setting ( FayuPedia )
    smm: {
        apiId: "177160",
        apiKey: "jtisrb-ldrskp-keujwa-pwfqwa-kltfue",
        baseUrl: "https://fayupedia.id/api",
    },

    // --- PAYMENT (ORKUT + PAKASIR) ---
    payment: {
        // --- PAYMENT ORKUT ---
        apikey: "jekk", // jan ganti nnti eror
        username: "tidak tersedia",
        token: "-",

        // --- PAYMENT PAKASIR ---
        pakasir: {
            slug: "",
            apiKey: "",
        },
    },

    // --- PAYMENT ATLANTIC ---
    ApikeyAtlantic: "-",
    wd_balance: {
        bank_code: "DANA", // DANA, BCA, BRI, dll
        destination_number: "082256765922",
        destination_name: "RAFIIF ZAKY MUSYAFA",
    },

    // --- Qris Manual Setting ---
    manualQrisPhoto: "https://files.catbox.moe/t4t4fl.jpg",

    // --- Vps Setting ---
    ApiDO1: "", // ganti api do lu
    hargaVPS: {
        high: {
            "2c2": 5000,
            "4c2": 7000,
            "8c4": 10000,
            "16c4": 13000,
            "16c8": 15000,
        },
    },

    // --- Fix Error Setting
    USER_LIMIT: 10,
    GEMINI_API_KEY: "AIzaSyB47adRUMkO-Yn_MOcOZBDV0PFIpzqKBy4",

    // --- PTERODACTYL PANEL ---
    panel: {
        domain: "https://cloudamd.dekzymarket-host.my.id",
        apikey: "ptla_FT2H9IGyi5w21PGyKqgdJm4qWDOHKHlbUKZ4RJp1zwt",
        nestId: 5,
        eggId: 15,
        locationId: 1,
        startup: "npm start",
        image: "ghcr.io/parkervcp/yolks:nodejs_18",
    },

    // --- HARGA PANEL ---
    hargaAdminPanel: 25000,
    hargaResellerPanel: 20000,
    linkResellerPanel: "https://t.me/+arG1fqN9lvMxNGE1",
    hargaPanel: {
        unlimited: 13000,
        perGB: 1000,
    },
};