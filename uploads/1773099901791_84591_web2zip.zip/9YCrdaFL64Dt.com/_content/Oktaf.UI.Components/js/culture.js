window.setCultureCookie = (culture) => {
    document.cookie = `WebCulture=${culture}; path=/; max-age=31536000`;
};

window.getCultureCookie = () => {
    let cookies = document.cookie.split('; ');
    for (let i = 0; i < cookies.length; i++) {
        let parts = cookies[i].split('=');
        if (parts[0] === "WebCulture") {
            return parts[1]; // Directly return "id" or "en"
        }
    }
    return 'id'; // Default to 'en' if not found
};

window.getCultureFromUrl = () => {
    let pathSegments = window.location.pathname.split('/');
    return pathSegments.length > 1 ? pathSegments[1] : 'id'; // Default to 'en' if not found
};

// Automatically set cookie on URL change
window.detectAndSetCulture = () => {
    let culture = window.getCultureFromUrl();
    if (culture === "en" || culture === "id") {
        window.setCultureCookie(culture);
    }
};