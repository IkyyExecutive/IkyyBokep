document.addEventListener('DOMContentLoaded', async () => {
    const loadingScreen = document.getElementById("loadingScreen");
    const body = document.body;
    body.classList.add("no-scroll");

    async function loadGlobalStats() {
        try {
            const response = await fetch('/global-stats');
            const stats = await response.json();
            document.getElementById('totalRequests').textContent = stats.totalRequests.toLocaleString();
            document.getElementById('todayRequests').textContent = stats.todayRequests.toLocaleString();
        } catch (error) {
            console.error('Error loading global stats:', error);
            document.getElementById('totalRequests').textContent = '0';
            document.getElementById('todayRequests').textContent = '0';
        }
    }

    loadGlobalStats();

    try {
        const settings = await fetch('/src/settings.json').then(res => res.json());

        const setContent = (id, property, value) => {
            const element = document.getElementById(id);
            if (element) element[property] = value;
        };

        const randomImageSrc =
            Array.isArray(settings.header.imageSrc) && settings.header.imageSrc.length > 0
                ? settings.header.imageSrc[Math.floor(Math.random() * settings.header.imageSrc.length)]
                : "";

        const dynamicImage = document.getElementById('dynamicImage');
        if (dynamicImage) {
            const isVideo = randomImageSrc.toLowerCase().endsWith('.mp4') || randomImageSrc.toLowerCase().endsWith('.webm');
            if (isVideo) {
                const videoElement = document.createElement('video');
                videoElement.src = randomImageSrc;
                videoElement.autoplay = true;
                videoElement.muted = true;
                videoElement.loop = true;
                videoElement.playsInline = true;
                videoElement.style.borderRadius = '8px';
                videoElement.style.width = '100%';
                videoElement.style.height = 'auto';
                dynamicImage.replaceWith(videoElement);
            } else {
                dynamicImage.src = randomImageSrc;
            }
        }

        setContent('page', 'textContent', settings.name || "Savant UI");
        setContent('header', 'textContent', settings.name || "Savant UI");
        setContent('name', 'textContent', settings.name || "Savant UI");
        setContent('version', 'textContent', settings.version || "v2.0 Beta");
        setContent('versionHeader', 'textContent', settings.header.status || "Online!");
        setContent('description', 'textContent', settings.description || "Simple API's");

        const apiLinksContainer = document.getElementById('apiLinks');
        if (apiLinksContainer && settings.links?.length) {
            settings.links.forEach(({ url, name }) => {
                const link = Object.assign(document.createElement('a'), {
                    href: url,
                    textContent: name,
                    target: '_blank',
                    className: 'lead'
                });
                apiLinksContainer.appendChild(link);
            });
        }

        let totalEndpoints = 0;
        let totalCategories = settings.categories.length;
        settings.categories.forEach(category => totalEndpoints += category.items.length);

        document.getElementById('totalEndpoints').textContent = totalEndpoints;
        document.getElementById('totalCategories').textContent = totalCategories;

        const apiContent = document.getElementById('apiContent');
        settings.categories.forEach((category) => {
            const sortedItems = category.items.sort((a, b) => a.name.localeCompare(b.name));
            const categoryContent = sortedItems.map((item, index, array) => {
                const isLastItem = index === array.length - 1;
                const itemClass = `col-md-6 col-lg-4 api-item ${isLastItem ? 'mb-4' : 'mb-2'}`;
                return `
                    <div class="${itemClass}" data-name="${item.name}" data-desc="${item.desc}">
                        <div class="hero-section d-flex align-items-center justify-content-between" style="height: 70px;">
                            <div style="flex: 1; min-width: 0; margin-right: 15px;">
                                <h5 class="mb-0" style="font-size: 18px;">${item.name}</h5>
                                <p class="text-muted mb-0" style="font-size: 0.8rem;">${item.desc}</p>
                            </div>
                            <button class="btn btn-primary btn-sm get-api-btn try-btn" 
                                    data-api-path="${item.path}" 
                                    data-api-name="${item.name}" 
                                    data-api-desc="${item.desc}">
                                TRY
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
            apiContent.insertAdjacentHTML('beforeend', `<h3 class="mb-3 category-header" style="font-size: 22px;">${category.name}</h3><div class="row">${categoryContent}</div>`);
        });

        const searchInput = document.getElementById('searchInput');
        function performSearch(searchTerm) {
            const apiItems = document.querySelectorAll('.api-item');
            const categoryHeaders = document.querySelectorAll('.category-header');
            apiItems.forEach(item => {
                const name = item.getAttribute('data-name').toLowerCase();
                const desc = item.getAttribute('data-desc').toLowerCase();
                item.style.display = (name.includes(searchTerm) || desc.includes(searchTerm)) ? '' : 'none';
            });
            categoryHeaders.forEach(header => {
                const categoryRow = header.nextElementSibling;
                const visibleItems = categoryRow.querySelectorAll('.api-item:not([style*="display: none"])');
                header.style.display = visibleItems.length ? '' : 'none';
            });
        }
        searchInput.addEventListener('input', () => performSearch(searchInput.value.toLowerCase()));

        document.addEventListener('click', event => {
            if (!event.target.classList.contains('get-api-btn')) return;

            const { apiPath, apiName, apiDesc } = event.target.dataset;
            const modal = new bootstrap.Modal(document.getElementById('apiResponseModal'));
            const modalRefs = {
                label: document.getElementById('apiResponseModalLabel'),
                desc: document.getElementById('apiResponseModalDesc'),
                content: document.getElementById('apiResponseContent'),
                endpoint: document.getElementById('apiEndpoint'),
                spinner: document.getElementById('apiResponseLoading'),
                queryInputContainer: document.getElementById('apiQueryInputContainer'),
                submitBtn: document.getElementById('submitQueryBtn')
            };

            modalRefs.label.textContent = apiName;
            modalRefs.desc.textContent = apiDesc;
            modalRefs.content.innerHTML = '';
            modalRefs.endpoint.textContent = '';
            modalRefs.spinner.classList.add('d-none');
            modalRefs.content.classList.add('d-none');
            modalRefs.endpoint.classList.add('d-none');
            modalRefs.queryInputContainer.innerHTML = '';
            modalRefs.submitBtn.classList.add('d-none');

            let baseApiUrl = `${window.location.origin}${apiPath}`;
            let params = new URLSearchParams(apiPath.split('?')[1]);
            let hasParams = params.toString().length > 0;

            if (hasParams) {
                const paramContainer = document.createElement('div');
                paramContainer.className = 'param-container';
                Array.from(params.keys()).forEach((param, index) => {
                    const paramGroup = document.createElement('div');
                    paramGroup.className = index < params.keys().length - 1 ? 'mb-2' : '';
                    const inputField = document.createElement('input');
                    inputField.type = 'text';
                    inputField.className = 'form-control';
                    inputField.placeholder = `Enter ${param}...`;
                    inputField.dataset.param = param;
                    inputField.required = true;
                    inputField.addEventListener('input', validateInputs);
                    inputField.addEventListener('keypress', (e) => {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            const submitBtn = document.getElementById('submitQueryBtn');
                            if (!submitBtn.disabled && !submitBtn.classList.contains('d-none')) submitBtn.click();
                        }
                    });
                    paramGroup.appendChild(inputField);
                    paramContainer.appendChild(paramGroup);
                });

                modalRefs.queryInputContainer.appendChild(paramContainer);
                modalRefs.submitBtn.classList.remove('d-none');

                modalRefs.submitBtn.onclick = () => {
                    const inputs = modalRefs.queryInputContainer.querySelectorAll('input');
                    const newParams = new URLSearchParams();
                    let isValid = true;
                    inputs.forEach(input => {
                        if (!input.value.trim()) isValid = false;
                        else newParams.append(input.dataset.param, input.value.trim());
                    });
                    if (!isValid) {
                        modalRefs.content.textContent = 'Please fill in all required fields.';
                        modalRefs.content.classList.remove('d-none');
                        return;
                    }
                    modalRefs.queryInputContainer.innerHTML = '';
                    modalRefs.submitBtn.classList.add('d-none');
                    handleApiRequest(`${window.location.origin}${apiPath.split('?')[0]}?${newParams.toString()}`, modalRefs, apiName);
                };
            } else {
                handleApiRequest(baseApiUrl, modalRefs, apiName);
            }

            modal.show();
        });

        function validateInputs() {
            const submitBtn = document.getElementById('submitQueryBtn');
            const inputs = document.querySelectorAll('.param-container input');
            submitBtn.disabled = !Array.from(inputs).every(input => input.value.trim() !== '');
        }
async function handleApiRequest(apiUrl, modalRefs, apiName) {
    modalRefs.spinner.classList.remove('d-none');
    modalRefs.content.classList.add('d-none');
    modalRefs.content.innerHTML = '';

    try {
        const res = await fetch(apiUrl);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        // 🔥 PAKSA SEMUA JADI BLOB
        const blob = await res.blob();
        const type = blob.type || '';

        // ===== VIDEO =====
        if (type.startsWith('video/') || apiUrl.includes('/random/asupan')) {
            const url = URL.createObjectURL(blob);

            const video = document.createElement('video');
            video.src = url;
            video.controls = true;
            video.autoplay = true;
            video.loop = true;
            video.muted = true;
            video.playsInline = true;
            video.style.width = '100%';
            video.style.borderRadius = '10px';

            modalRefs.content.appendChild(video);
        }

        // ===== IMAGE =====
        else if (type.startsWith('image/')) {
            const url = URL.createObjectURL(blob);

            const img = document.createElement('img');
            img.src = url;
            img.style.maxWidth = '100%';
            img.style.borderRadius = '8px';

            modalRefs.content.appendChild(img);
        }

        // ===== TEXT / JSON (NO PARSE) =====
        else {
            const text = await blob.text();
            modalRefs.content.textContent = text;
        }

        modalRefs.endpoint.textContent = apiUrl;
        modalRefs.endpoint.classList.remove('d-none');

    } catch (err) {
        modalRefs.content.textContent = `Error: ${err.message}`;
    } finally {
        modalRefs.spinner.classList.add('d-none');
        modalRefs.content.classList.remove('d-none');
    }
}
    } catch (error) {
        console.error('Error loading settings:', error);
    } finally {
        setTimeout(() => {
            loadingScreen.style.display = "none";
            body.classList.remove("no-scroll");
        }, 2500);
    }
});

window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    const navbarBrand = document.querySelector('.navbar-brand');
    if (window.scrollY > 0) {
        navbarBrand.classList.add('visible');
        navbar.classList.add('scrolled');
    } else {
        navbarBrand.classList.remove('visible');
        navbar.classList.remove('scrolled');
    }
});